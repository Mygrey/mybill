package com.zcreate.job.admin;

import com.zcreate.job.common.File2Hdfs;
import com.zcreate.job.dao.AppJobDao;
import com.zcreate.job.model.AppJob;
import com.zcreate.job.param.OozieParam;
import org.apache.oozie.client.OozieClient;
import org.apache.oozie.client.OozieClientException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
public class JobDelete {

    @Resource
    private AppJobDao appJob;

    @Autowired
    private OozieParam param;

    @Autowired
    private File2Hdfs fileHdfs;

    private static final Logger logger=LoggerFactory.getLogger(JobDelete.class);
    /**
     * 任务删除的步骤如下：
     * -前端传入要删除的appId
     * -检测该appId对应的任务状态，并停止该任务
     * -删除hdfs上对应的任务文件
     * -删除appId和jobId对应关系
     * -删除相关表的数据
     *
     */
    public void delete(String appId){

        //获取id映射关系
        List<AppJob> list=appJob.findByJobId(appId);
        String jobId="";
        if(list.isEmpty()){
           logger.error("在删除时无法找到对应的oozie任务，请核查后重试！");

        }else {
           jobId = list.get(0).getJobId();
        }

        //停止对应的任务
        OozieClient client=new MyOozieClient(param.getClientAddress()).getClient();
        try {
            client.kill(jobId);
        } catch (OozieClientException e) {
            e.printStackTrace();
        }

        //删除hdfs上对应的文件
        String appPath=param.getAppPath();
        String filePath=(appPath.endsWith("/") ? appPath : appPath+"/")+appId;

        fileHdfs.deleteDir(filePath);

    }
}
