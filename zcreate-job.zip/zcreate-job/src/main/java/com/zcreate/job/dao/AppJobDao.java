package com.zcreate.job.dao;


import com.zcreate.job.model.ActionInfo;
import com.zcreate.job.model.AppJob;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AppJobDao  extends JobMapper{


    public List<AppJob> findByJobId(@Param("appId") String appId);


    public int save(AppJob appJob);

}
