package com.zcreate.job.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class JobScheduleModel {
    String appId;
    String appName;
    String appType;
    String projectName;

    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    Date startTime;

    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    Date endTime;

    String appDesc;
    String appStatus;
    String operator;
    String oozieId;



}
