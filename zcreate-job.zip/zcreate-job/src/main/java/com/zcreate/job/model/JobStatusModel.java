package com.zcreate.job.model;

import lombok.Data;

@Data
public class JobStatusModel {
//    int sucJob;
//    int failJob;
//    int waitJob;
//    int runJob;
    float sucRate;
    float failRate;
    float waitRate;
    float runRate;

    String updateTime;

}
