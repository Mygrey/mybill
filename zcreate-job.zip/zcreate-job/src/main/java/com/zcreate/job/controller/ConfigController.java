package com.zcreate.job.controller;

import com.alibaba.nacos.api.config.annotation.NacosValue;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import static org.springframework.web.bind.annotation.RequestMethod.GET;

@Controller
@RequestMapping("config")
public class ConfigController {
//
//    @NacosInjected
//    private ConfigService configService;

      @NacosValue(value = "${oozie.client.address:xixi}")
      private String prop;

    @RequestMapping(value = "/get", method = GET)
    @ResponseBody
    public String get() {
        String content=prop;

//        try {
//            content=configService.getConfig("idb-task","hadoop",5000);
//        } catch (NacosException e) {
//            e.printStackTrace();
//        }
        return content;
    }
}