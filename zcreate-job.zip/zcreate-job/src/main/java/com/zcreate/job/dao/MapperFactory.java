package com.zcreate.job.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.cglib.proxy.InvocationHandler;
import org.springframework.cglib.proxy.Proxy;

import java.lang.reflect.Method;

public final class MapperFactory {
    /**
     * Mapper Factory
     * @author boyce
     * @version 2014-3-28
     */
        private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(MapperFactory.class);
        /**
         * Create a mapper of environment by Mapper class
         * @param clazz Mapper class
         * @param environment A datasource environment
         * @return a Mapper instance
         */
        @SuppressWarnings("unchecked")
        public static <T> T createMapper(Class<? extends JobMapper> clazz, JobSqlSessionFactory.DataSourceEnvironment environment) {
            SqlSessionFactory sqlSessionFactory = getSqlSessionFactory(environment);
            SqlSession sqlSession = sqlSessionFactory.openSession();
            JobMapper mapper = sqlSession.getMapper(clazz);
            return (T)MapperProxy.bind(mapper, sqlSession);
        }

        /**
         * Mapper Proxy
         * executing mapper method and close sqlsession
         * @author boyce
         * @version 2014-4-9
         */
        private static class MapperProxy implements InvocationHandler {
            private JobMapper mapper;
            private SqlSession sqlSession;

            private MapperProxy(JobMapper mapper, SqlSession sqlSession) {
                this.mapper = mapper;
                this.sqlSession = sqlSession;
            }

            @SuppressWarnings("unchecked")
            private static JobMapper bind(JobMapper mapper, SqlSession sqlSession) {
                return (JobMapper) Proxy.newProxyInstance(mapper.getClass().getClassLoader(),
                        mapper.getClass().getInterfaces(), new MapperProxy(mapper, sqlSession));
            }

            /**
             * execute mapper method and finally close sqlSession
             */
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                Object object = null;
                try {
                    object = method.invoke(mapper, args);
                } catch(Exception e) {
                    e.printStackTrace();
                    logger.error(e.getMessage(), e);
                } finally {
                   // sqlSession.close();
                }
                return object;
            }
        }

        //Get a SqlSessionFactory of environment
        private static SqlSessionFactory getSqlSessionFactory(JobSqlSessionFactory.DataSourceEnvironment environment) {
            return JobSqlSessionFactory.getSqlSessionFactory(environment);
        }


    }
