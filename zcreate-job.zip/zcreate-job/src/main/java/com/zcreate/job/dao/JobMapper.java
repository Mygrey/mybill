package com.zcreate.job.dao;

public interface JobMapper {
}
