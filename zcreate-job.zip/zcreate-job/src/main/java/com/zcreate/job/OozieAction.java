package com.zcreate.job;

import com.zcreator.bigdata.aggregation.hdfs.HdfsBusiOps;
import com.zcreator.bigdata.aggregation.hdfs.impl.HdfsBusiOpsImpl;
import com.zcreator.bigdata.aggregation.hdfs.impl.HdfsOpsImpl;
import com.zcreator.bigdata.aggregation.hdfs.utils.HadoopClient;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.oozie.client.*;
import org.junit.jupiter.api.Test;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class OozieAction {



    @Test
    public void oozieTest() {
        OozieClient oc=new OozieClient("http://10.1.80.6:11000/oozie");
        String input="/home/hdfs";
        String output="/home/hdfs";

        Properties conf = oc.createConfiguration();
        //conf.setProperty(OozieClient.APP_PATH,"hdfs://10.1.80.5:8020/home/hdfs/apps/workflow.xml");
//        conf.setProperty("nameNode", "hdfs://10.1.80.5:8020");
//        conf.setProperty("user.name","hdfs");
//        conf.setProperty("appName","hahatest");
//        conf.setProperty("queueName", "default");
//        conf.setProperty("examplesRoot", "examples");
//        conf.setProperty("oozie.use.system.libpath","true");
//        conf.setProperty("oozie.wf.application.path", "hdfs://nameserviceBackup/home/hdfs/apps");
      //  conf.setProperty("outputDir", "map-reduce");
//        conf.setProperty("jobTracker", "yarnRM");
//        conf.setProperty("inputDir", input);
//        conf.setProperty("outputDir", output);

        String jobId="0001011-190222143954763-oozie-oozi-C";


        String jobId2="0007060-190302151456678-oozie-oozi-W";
        try {
//            CoordinatorAction minfo=oc.getCoordActionInfo(jobId);
//
//            CoordinatorJob jobs=oc.getCoordJobInfo(jobId);
            WorkflowJob info =oc.getJobInfo(jobId2);
            WorkflowAction actions=oc.getWorkflowActionInfo(jobId2);



            System.out.println(info);

            //0007089-190318140643396-oozie-oozi-W

            String mylog=oc.getJobLog("0007089-190318140643396-oozie-oozi-W");




            System.out.println("=====================");

            System.out.println(mylog);

            System.out.println("=====================");

//            jobs.getActions().forEach(ele->{
//               System.out.println(ele.getActionNumber()+"--"+ele.getCreatedTime()+"--"+ele.getExternalId()+"----"+ele.getStatus());
//            });





        } catch (OozieClientException e) {

        }



//        System.out.println("======="+jobId);

    }


    @Test
    public void saveXml(){

        System.setProperty("hadoop.home.dir","C:\\Program Files\\hadoop-common-2.2.0-bin-master" );
        HadoopClient client = new HadoopClient();
        client.setDefaultFS("hdfs://10.1.80.5:8020");
       // client.setDefaultFS("hdfs://nameserviceBackup");
//        client.setNameNodes("hdfs://nameserviceBackup");
//        client.setNameServices("hdfs://nameserviceBackup");

        client.setUserName("hdfs");
        client.init();



       String rest="kasjhdsajdwqlewq6165464664646qw8e42445ad";

        String partitionPath = "/home/hdfs/apps/device_2019-03-19";


        HdfsBusiOps hdfsBusiOps=new HdfsBusiOpsImpl();


        byte[] temp=rest.getBytes();

        try {
            HdfsOpsImpl hoi=new HdfsOpsImpl(client);
            hoi.createFile(partitionPath,temp);

            if(hoi.checkFileExist("/dqcp/mark/deviceInfo/device")){
                System.out.println("----------");
            }else {
                System.out.println("===================");
            }

//            hoi.createFile(partitionPath,temp);
//            hoi.createFile(partitionPath);
            /**
             * 下面这种方式写入hdfs文件，会在每行开始位置出现乱码。其中res是List<String>类型
             */
//            hdfsBusiOps.appendHdfs(client.getConf(), partitionPath,res);
            System.out.println("写入成功！");

        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }

    }

    @Test
    public void hdfsTest() throws Exception{
    System.setProperty("hadoop.home.dir","C:\\Program Files\\hadoop-common-2.6.0-bin-master" );
    HadoopClient client = new HadoopClient();
    client.setDefaultFS("hdfs://10.1.80.5:8020");
    // client.setDefaultFS("hdfs://nameserviceBackup");
//        client.setNameNodes("hdfs://nameserviceBackup");
//        client.setNameServices("hdfs://nameserviceBackup");

    client.setUserName("hdfs");
    client.init();

        String filePath="/home/hdfs/apps/pi.py";
    FileSystem fs = null;
    URI uri = new URI(filePath);
    fs = FileSystem.get(uri,client.getConf());
    Path srcPath = new Path(filePath);
    InputStream in = fs.open(srcPath);

   fs.listStatus(srcPath);


    StringBuffer txtContent = new StringBuffer();
//        String line=null;
//        BufferedReader reader=new BufferedReader(new InputStreamReader(in));
//        while((line=reader.readLine())!=null){
//            txtContent.append(line+"\n");
//        }

    byte[] buf = new byte[1];
    while(in.read(buf)>0){
        txtContent.append(new String(buf));
    }

    in.close();

    if(fs!=null){
        fs.close();
    }

    String fileContent=txtContent.toString();
        System.out.println("----");
    System.out.println(fileContent);
        System.out.println("-----");
}


    @Test
    public void listDir() throws Exception{
    System.setProperty("hadoop.home.dir","C:\\Program Files\\hadoop-common-2.6.0-bin-master" );
    HadoopClient client = new HadoopClient();
    client.setDefaultFS("hdfs://10.1.80.5:8020");
    // client.setDefaultFS("hdfs://nameserviceBackup");
//        client.setNameNodes("hdfs://nameserviceBackup");
//        client.setNameServices("hdfs://nameserviceBackup");

    client.setUserName("hdfs");
    client.init();

    String filePath="/home/hdfs/apps/";
    FileSystem fs = null;
    URI uri = new URI(filePath);
    fs = FileSystem.get(uri,client.getConf());
    Path srcPath = new Path(filePath);


    FileStatus[] haha=fs.listStatus(srcPath);
    Map<String,String> result=new HashMap<>();
    for(FileStatus ss:haha){
        String flag=ss.isDirectory() ? "dir" : "file";
        result.put(ss.getPath().getName(),flag);
    }

    result.forEach((key,value)->{
        System.out.println("key="+key+"----value="+value);
    });

}

    public static void main(String[] args) {
   Map<String,String> map=new HashMap<>();
   map.put("test","haha");
        System.out.println(map.get("xixi"));



    }
}
