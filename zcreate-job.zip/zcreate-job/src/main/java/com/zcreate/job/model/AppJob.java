package com.zcreate.job.model;

public class AppJob {
   private String appId;
   private String jobId;

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getAppId() {
        return appId;
    }

    public String getJobId() {
        return jobId;
    }
}
