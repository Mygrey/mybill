package com.zcreate.job.dao;

import com.zcreate.job.model.JobScheduleModel;
import org.apache.ibatis.annotations.Mapper;

import java.util.ArrayList;
import java.util.List;

@Mapper
public interface JobDispatchDao extends JobMapper {


    public List<JobScheduleModel> findByDate();

}
