package com.zcreate.job.controller;


import com.alibaba.fastjson.JSONObject;
import com.zcreate.job.common.JobLogMessage;
import com.zcreate.job.dao.JobIndexDao;
import com.zcreate.job.dao.JobSqlSessionFactory;
import com.zcreate.job.dao.MapperFactory;
import com.zcreate.job.model.FailJobModel;
import com.zcreate.job.model.JobProjectModel;
import com.zcreate.job.model.JobStatusModel;
import com.zcreate.job.model.RateHourModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

@Controller
@RequestMapping(value = "/idb")
public class JobIndexController {

    private static final Logger logger=LoggerFactory.getLogger(JobIndexController.class);
    //private  JobIndexDao jobIndex=MapperFactory.createMapper(JobIndexDao.class,JobSqlSessionFactory.DataSourceEnvironment.oozie);

    @RequestMapping(value = "/index",method = RequestMethod.GET)
    @ResponseBody
    public Map<String, List<?>> index(){
        // JSONObject json = JSONObject.fromObject(stu);

       // Map<String,String> responseMap=new HashMap<>();
        Map<String,List<?>> responseM=new HashMap<>();
        //获取各个状态的任务数量
        JobIndexDao jobIndex=MapperFactory.createMapper(JobIndexDao.class,JobSqlSessionFactory.DataSourceEnvironment.oozie);
        //        List<JobStatusModel> jobs=jobIndex.findByDate();

        //获取五天饼状图数据
        List<JobStatusModel> jobStatus=jobIndex.findFiveDay();

        //list被转化为对象[]外会有双引号："[]"
        //responseMap.put("pie-chart",JSONObject.toJSONString(jobStatus));
        responseM.put("pie-chart",jobStatus);



        //获取24小时折线图数据
        List<RateHourModel> rateList=jobIndex.findRateHour();

//        responseMap.put("line-chart",JSONObject.toJSONString(rateList));

        responseM.put("line-chart",rateList);

        //获取条数不满足，日志报错
        if(jobStatus.size()!=5){
            logger.error(JobLogMessage.PIE_CHART_DATA_LOST);
        }else if(rateList.size()!=24){
            logger.error(JobLogMessage.LINE_CHART_DATA_LOST);
        }



        //所属项目统计，需要判断当前统计的项目数
        List<JobProjectModel> projects=jobIndex.countProjectJob();
        List<JobProjectModel> result=new ArrayList<>();

        if(projects.size()==0){
            logger.error(JobLogMessage.BAR_CHART_DATA_LOST);
        }else {

            Map<String, Long> map = new TreeMap<String, Long>();
            for (Object ele : projects) {
                JobProjectModel model = (JobProjectModel) ele;
                map.put(model.getProjectName(), model.getJobNum());
            }

            List<Map.Entry<String, Long>> projectList = new ArrayList<>(map.entrySet());
            Collections.sort(projectList, new Comparator<Map.Entry<String, Long>>() {
                @Override
                public int compare(Map.Entry<String, Long> o1, Map.Entry<String, Long> o2) {
                    return o2.getValue().compareTo(o1.getValue());
                }
            });

            int item=projectList.size()>=6 ? 6:projectList.size();

            List<Map.Entry<String, Long>> projectResult = projectList.subList(0, item);
            for(Map.Entry<String, Long> ele:projectResult){
                result.add(new JobProjectModel(ele.getKey(),ele.getValue()));
            }

        }

//        responseMap.put("bar-chart",JSONObject.toJSONString(result));
        responseM.put("bar-chart",result);


        List<FailJobModel> failJobs=jobIndex.findFailJob();

//        responseMap.put("fail-job",JSONObject.toJSONString(failJobs));
        responseM.put("fail-job",failJobs);

        return responseM;
    }
}
