package com.zcreate.job.dao;

import com.zcreate.job.model.ActionInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;


import java.util.List;


@Mapper
public interface ActionInfoDao extends JobMapper {

    public List<ActionInfo> findAll();

    public List<ActionInfo> findByAppId(@Param("appId") String appId);

}
