package com.zcreate.job.dao;

import com.zcreate.job.model.FailJobModel;
import com.zcreate.job.model.JobProjectModel;
import com.zcreate.job.model.JobStatusModel;
import com.zcreate.job.model.RateHourModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface JobIndexDao extends JobMapper {

    //饼状图数据查询
    public List<JobStatusModel> findByDate();

    public List<JobStatusModel> findFiveDay();

    //折线图数据查询
    public List<RateHourModel> findRateHour();

    //项目展示柱状图数据查询
    public List<JobProjectModel> countProjectJob();

    //查询失败任务
    public List<FailJobModel> findFailJob();

}
