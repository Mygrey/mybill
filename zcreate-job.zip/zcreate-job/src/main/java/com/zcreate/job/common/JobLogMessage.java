package com.zcreate.job.common;

public final class JobLogMessage {

    public final static String BAR_CHART_DATA_LOST="柱图数据不全或丢失，请检查数据库";

    public final static String PIE_CHART_DATA_LOST="饼状图数据不全或丢失，请检查数据库";

    public final static String LINE_CHART_DATA_LOST="折线图数据不全或丢失，请检查数据库";

    public final static String ACTION_NOT_FOUND="无法获取到相关action信息，请检查任务配置!";

    public final static String ACTION_TYPE_NOT_MATCH="无法匹配到正确的Action类型，请检查任务配置!";
}
