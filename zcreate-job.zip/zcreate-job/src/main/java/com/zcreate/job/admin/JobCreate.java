package com.zcreate.job.admin;


import com.zcreate.job.common.File2Hdfs;
import com.zcreate.job.common.FileUtil;
import com.zcreate.job.dao.AppJobDao;
import com.zcreate.job.model.AppJob;
import com.zcreate.job.param.OozieParam;
import com.zcreate.job.workflow.WorkflowBuild;
import org.apache.oozie.client.OozieClient;
import org.apache.oozie.client.OozieClientException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.Properties;

@Component
public class JobCreate {

    @Autowired
    private WorkflowBuild workflow;

    @Autowired
    private File2Hdfs hdfsFile;

    @Autowired
    private OozieParam oozie;

    @Resource
    private AppJobDao appJobDao;

    /**
     * -获得需要创建的appId
     * -创建相关应用程序的目录
     * -关于lib目录的创建，统一进行创建，没有则为空
     * -通过WorkflowBuild类进行workflow的创建
     * -将workflow上传至指定目录：path/${appId}/workflow.xml
     * -创建job.properties文件，上传上述目录
     * -创建运行计划coordinate文件，上传上述目录
     * -构建oozie client，配置传入与job.properties中的配置重复
     * -oozie client submit任务
     * -获取oozie任务信息，关联调度系统对应的相关信息，回填mysql
     * -回填任务状态信息到mysql
     *
     */


    public void  create(String appId) {
        //初始化hdfs上的文件夹
        String appPath=initFolder(appId);

        //构建workflow.xml
        String xmlStr="";
        try {
            xmlStr=workflow.buildXMLInfo(appId);
        } catch (Exception e) {
            e.printStackTrace();
        }


        String xmlPath=appPath+"workflow.xml";
        String jobPath=appPath+"job.properties";

        hdfsFile.saveWorkflow(xmlPath,xmlStr);

        //构建job.properties文件
        String propStr="";
        try {
            propStr=new FileUtil().getFileString("classpath:job.properties");
        } catch (IOException e) {
            e.printStackTrace();
        }

        hdfsFile.saveWorkflow(jobPath,propStr);

        //todo: time schedule

        //连接oozie提交项目
        MyOozieClient client=new MyOozieClient(oozie.getClientAddress());
        String jobId=client.oozieSubmit(oozie.getNameNode()+appPath);

        //更新appid与oozie jobId对应关系，此处为插入
        AppJob appJob=new AppJob();
        appJob.setAppId(appId);
        appJob.setJobId(jobId);
        appJobDao.save(appJob);

    }

    public String initFolder(String appId){
        String appPath=oozie.getAppPath();
        String filePath="";

        if(appPath.endsWith("/")){
            hdfsFile.createDir(appPath+appId);
            filePath=appPath+appId+"/";

        }else{
            hdfsFile.createDir(appPath+"/"+appId);
            filePath=appPath+"/"+appId+"/";
        }
        String libPath=filePath+"/lib";
        hdfsFile.createDir(libPath);
        return filePath;
    }



}
