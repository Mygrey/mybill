package com.zcreate.job.workflow;

import com.zcreate.job.param.WorkflowParam;
import com.zcreate.job.param.OozieParam;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.StringWriter;
import java.util.Map;

@Component
public class FreemarkerBuild {

    @Autowired
    public WorkflowParam workflowParam;

    @Autowired
    public OozieParam ozParam;

    public String templateBuild(String templateName,Map<String,String> map) throws Exception{
        String templateString="";

        Configuration cfg=new Configuration(Configuration.VERSION_2_3_20);

        cfg.setDirectoryForTemplateLoading(new File(workflowParam.getTemplatePath()));
        cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
        Template temp = cfg.getTemplate(templateName);
//            Writer out = new OutputStreamWriter(System.out);
        StringWriter stringWriter = new StringWriter();
//            BufferedWriter writer = new BufferedWriter(stringWriter);

        temp.process(map, stringWriter);
//            StringReader reader = new StringReader(stringWriter.toString());
        templateString=stringWriter.getBuffer().toString();

        stringWriter.flush();
        stringWriter.close();

        return templateString+"\n";

    }
}
