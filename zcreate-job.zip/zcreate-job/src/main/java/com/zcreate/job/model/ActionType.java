package com.zcreate.job.model;

public enum ActionType {

    SHELL("shell"),JAVA("java"),PYTHON("python"),JOIN("join"),FORK("fork"),
    SPARK("spark"),HIVE("hive"),SQOOP("sqoop"),MAPREDUCE("mapreduce"),EMAIL("email");

    private String name;

    private ActionType(String name){
        this.name=name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
