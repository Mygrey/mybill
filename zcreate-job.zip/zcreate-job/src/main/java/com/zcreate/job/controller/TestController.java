package com.zcreate.job.controller;


import com.zcreate.job.admin.JobUpdate;
import com.zcreate.job.common.File2Hdfs;
import com.zcreate.job.dao.ActionInfoDao;
import com.zcreate.job.dao.AppJobDao;
import com.zcreate.job.dao.MapperFactory;
import com.zcreate.job.param.HadoopParam;
import org.apache.oozie.client.*;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@Component
@MapperScan("com.zcreate.job.model")
@ComponentScan("com.zcreate.job.dao")
public class TestController {


    @Autowired
    private HadoopParam param;

//    @Resource
//    private ActionInfoDao actionInfo;
//
//    @Resource
//    private AppJobDao appJob;

    @Autowired
    private JobUpdate update;

    @Autowired
    private File2Hdfs file;



    @RequestMapping(value = "hello",method = RequestMethod.GET)
    public String sayHello() throws Exception{

        //this.jsonParam.sayN();

//        FileUtil file=new FileUtil();
//        String jsonStr="";

//        String result= build.parseCommonJson(jsonStr);
//
//        System.out.println(result);
        String temp="sdssf";
//        List<ActionInfo> list=this.actionInfo.findAll();
//        for (ActionInfo map:list){
//           temp=map.getActionName()+" "+map.getInputFile()+" "+map.getInsert_time()+" "+map.getStartAction();
//            System.out.println(temp);
//        }


//        String path="/home/hdfs/apps/mm.xml";
//        String rpc1=String.format("dfs.namenode.rpc-address.%s.%s",param.getNameService(),param.getNode1());
//        String rpc2=String.format("dfs.namenode.rpc-address.%s.%s",param.getNameService(),param.getNode2());
//        temp=param.getDefaultFs()+"******"+param.getNameNode1()+rpc1+rpc2;
//
//
//        file.saveWorkflow(path,temp);





        return temp;
    }
}


