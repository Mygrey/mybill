package com.zcreate.job.common;

import com.zcreate.job.param.HadoopParam;
import com.zcreator.bigdata.aggregation.hdfs.impl.HdfsOpsImpl;
import com.zcreator.bigdata.aggregation.hdfs.utils.HadoopClient;
import org.apache.commons.io.FileExistsException;
import org.apache.hadoop.HadoopIllegalArgumentException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.InputStream;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;


@Component
public class File2Hdfs {

    /**
     * 注意构造函数先于Autowired注解
     * 如果init改为构造函数的话param还没有初始化，会报空指针异常
     */

    private HdfsOpsImpl hoi;

    private Configuration hdfsConf;

    @Autowired
    public HadoopParam param;


    /**
     * 初始化HadoopClient
     * 连接HA模式下的hdfs，不能直接使用某个namenode的ip地址
     * 需要以nameservice来配置，所有的namenode写入配置
     */


    @PostConstruct
    public void init(){
        HadoopClient hadoopClient=new HadoopClient();
//        hadoopClient.setDefaultFS("hdfs://10.1.80.5:8020");
//        hadoopClient.setNameServices(this.param.getNameService());
//       hadoopClient.setNameNodes(this.param.getNode1()+","+this.param.getNode2());
//        hadoopClient.setRpcAddressNN1(this.param.getNameNode1());
//        hadoopClient.setRpcAddressNN2(this.param.getNameNode2());
//        hadoopClient.setUserName(this.param.getHdfsUser());
//        hadoopClient.setDefaultFS("hdfs://10.1.80.5:8020");
        Configuration conf =new Configuration();
        conf.set("fs.defaultFS", param.getDefaultFs());
        conf.set("dfs.nameservices", this.param.getNameService());
        conf.set("dfs.ha.namenodes."+this.param.getNameService(),param.getNode1()+","+param.getNode2());
        String rpc1=String.format("dfs.namenode.rpc-address.%s.%s",param.getNameService(),param.getNode1());
        String rpc2=String.format("dfs.namenode.rpc-address.%s.%s",param.getNameService(),param.getNode2());
        conf.set(rpc1,param.getNameNode1());
        conf.set(rpc2, param.getNameNode2());
        conf.set("dfs.client.failover.proxy.provider."+param.getNameService(), "org.apache.hadoop.hdfs.server.namenode.ha.ConfiguredFailoverProxyProvider");
        hadoopClient.setConf(conf);
        hadoopClient.setUserName(param.getHdfsUser());


        this.hoi=new HdfsOpsImpl(hadoopClient);
        this.hdfsConf=hadoopClient.getConf();
    }



    //保存到hdfs
    public void saveWorkflow(String workflowPath,String workflow){

        try {
            if (hoi.checkFileExist(workflowPath)){
                //文件已存在，默认删除后再创建
                hoi.deleteFile(workflowPath);
                hoi.createFile(workflowPath,workflow.getBytes());
//                throw new FileExistsException("file exists!");
            }else{
            hoi.createFile(workflowPath,workflow.getBytes());
            //todo:loginfo:create success

            }
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }

    }

    /**
     * 创建目录
     * @param path
     * @return
     */
    public boolean createDir(String path){
        boolean result=false;
        try {
            result=hoi.mkdir(path);
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }

        return result;
    }

    /**
     * 删除目录
     * @param path
     * @return
     */
    public boolean deleteDir(String path){
        boolean result=false;
        try {
            result=hoi.removeDir(path);
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }

        return result;
    }


    /**
     * 拷贝文件
     * @param srcPath
     * @param destPath
     * @return
     */
    public boolean copyFile(String srcPath,String destPath){
        boolean result=false;
        try {
            result=hoi.copyFile(srcPath,destPath);
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }

        return result;

    }



    /**
     * 获取hdfs上的文件内容
     * @param filePath
     * @return
     * @throws Exception
     */
    public String getFile(String filePath) throws Exception{
//            String filePath="/home/hdfs/apps/pi.py";
        FileSystem fs = null;
        URI uri = new URI(filePath);
        fs = FileSystem.get(uri,hdfsConf);
        Path srcPath = new Path(filePath);
        InputStream in = fs.open(srcPath);

        StringBuffer txtContent = new StringBuffer();
        byte[] buf = new byte[1];
        while(in.read(buf)!=-1){
            txtContent.append(new String(buf));
        }

        in.close();

        if(fs!=null){
            fs.close();
        }

        String fileContent=txtContent.toString();
        return fileContent;

    }


    /**
     * 获取目标路径下所有文件和文件夹
     * Map的key为文件名，value为类型：dir/file
     * @param dirPath
     * @return
     * @throws Exception
     */
    public Map<String,String> listFile(String dirPath) throws Exception{
        FileSystem fs = null;
        URI uri = new URI(dirPath);
        fs = FileSystem.get(uri,hdfsConf);
        Path srcPath = new Path(dirPath);

        FileStatus[] fileArr=fs.listStatus(srcPath);
        Map<String,String> typeMap=new HashMap<>();
        for(FileStatus ss:fileArr){
            String flag=ss.isDirectory() ? "dir" : "file";
            typeMap.put(ss.getPath().getName(),flag);
        }

        fs.close();
        return typeMap;
    }


}
