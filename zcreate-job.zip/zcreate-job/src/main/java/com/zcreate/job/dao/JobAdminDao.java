package com.zcreate.job.dao;


import com.zcreate.job.model.JobInfoModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface JobAdminDao extends JobMapper {

    //全量查询
    public List<JobInfoModel> findAll();

    //按照日期查询
    public List<JobInfoModel> findByDate(@Param("jobDate") String jobDate);

    //按照appId查询
    public List<JobInfoModel> findByAppId(@Param("appId") String appId);

    //新建保存操作
    public int saveJob(@Param("jobInfo") JobInfoModel jobInfo);

    //修改任务信息
    public int updateJob(@Param("jobInfo") JobInfoModel jobInfo);

    //删除任务
    public int deleteJob(@Param("appId") String appId);




}
