package com.zcreate.job.controller;


import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.zcreate.job.common.ReturnT;
import com.zcreate.job.dao.JobDispatchDao;
import com.zcreate.job.dao.JobIndexDao;
import com.zcreate.job.dao.JobSqlSessionFactory;
import com.zcreate.job.dao.MapperFactory;
import com.zcreate.job.model.JobScheduleModel;
import com.zcreate.job.param.OozieParam;
import org.apache.oozie.client.OozieClient;
import org.apache.oozie.client.OozieClientException;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/idb/job/dispatch")
public class JobDispatchController {

    @Autowired
    private OozieParam ozParam;

    private static final Logger logger=LoggerFactory.getLogger(JobDispatchController.class);

    @RequestMapping(value = "/index",method = RequestMethod.GET)
    @ResponseBody
    public List<JobScheduleModel> dispatchIndex(){
        JobDispatchDao jobDispatch= MapperFactory.createMapper(JobDispatchDao.class,JobSqlSessionFactory.DataSourceEnvironment.oozie);
        List<JobScheduleModel> list=jobDispatch.findByDate();
        return  list;
    }

    @RequestMapping(value = "/detail",method = RequestMethod.POST)
    @ResponseBody
    public String actionDetail(@RequestBody String oozieId){

        return "";
    }

    @RequestMapping(value = "/detail/log",method = RequestMethod.POST)
    @ResponseBody
    public String actionLog(@RequestBody String jobId){
        OozieClient client=new OozieClient(ozParam.getClientAddress());
        String jobLog="";
            try {
                jobLog=client.getJobLog(jobId);
            } catch (OozieClientException e) {
                e.printStackTrace();
            }

        return jobLog;
    }

    @RequestMapping(value = "/start",method = RequestMethod.POST)
    @ResponseBody
    public ReturnT<String> startJob(@RequestBody String oozieId){
        OozieClient client=new OozieClient(ozParam.getClientAddress());
        try {
            client.start(oozieId);
            return ReturnT.SUCCESS;
        } catch (OozieClientException e) {
            e.printStackTrace();
            return ReturnT.FAIL;
        }
    }


    @RequestMapping(value = "/stop",method = RequestMethod.POST)
    @ResponseBody
    public ReturnT<String> stopJob(@RequestBody String oozieId){
        OozieClient client=new OozieClient(ozParam.getClientAddress());
        try {
            client.kill(oozieId);
            return ReturnT.SUCCESS;
        } catch (OozieClientException e) {
            e.printStackTrace();
            return ReturnT.FAIL;
        }

    }

    @Test
    public void mytest(){
        new ReturnT<String>();
    }

    @RequestMapping(value = "/search/date",method = RequestMethod.POST)
    @ResponseBody
    public List<JobScheduleModel> searchByTime(@RequestBody String jobTime){

        List<JobScheduleModel> list=new ArrayList<>();
        return  list;
    }


    @RequestMapping(value = "/search/id",method = RequestMethod.POST)
    @ResponseBody
    public List<JobScheduleModel> searchById(@RequestBody String appId){
        List<JobScheduleModel> list=new ArrayList<>();
        return  list;

    }
}
