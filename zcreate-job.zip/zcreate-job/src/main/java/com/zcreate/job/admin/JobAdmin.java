package com.zcreate.job.admin;

import com.zcreate.job.dao.JobAdminDao;
import com.zcreate.job.dao.JobSqlSessionFactory;
import com.zcreate.job.dao.MapperFactory;

public class JobAdmin {

   private JobAdminDao jobAdmin=MapperFactory.createMapper(JobAdminDao.class,JobSqlSessionFactory.DataSourceEnvironment.oozie);






}
