package com.zcreate.job.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Date;

public class JobInfoModel {

    String appId;
    String appName;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String appDesc;

    String projectName;

    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    Date insertTime;

    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    Date updateTime;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String operator;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String permissId;

}
