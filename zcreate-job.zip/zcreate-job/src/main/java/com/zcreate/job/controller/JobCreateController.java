package com.zcreate.job.controller;



import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Component
public class JobCreateController {



    @RequestMapping(value = "hellos",method = RequestMethod.GET)
    public String createJob() throws Exception{
        //this.jsonParam.sayN();

/**
 * 0、接收前端传来的参数，解析、入库
 * 1、创建worflow.xml
 * 2、创建properties文件
 * 3、拷贝程序到指定目录；
 */



        return "";
    }
}
