package com.zcreate.job.model;

public class ActionInfo {

    String appId;
    String appName;
    String startAction;
    String actionName;
    String actionType;
    String nextAction;
    String exec;
    String inputFile;
    String arguments;
    String mainClass;
    String sparkOptions;
    String emailTo;
    String emailCc;
    String emailSubject;
    String insert_time;


    public String getEmailTo() {
        return emailTo;
    }

    public String getEmailCc() {
        return emailCc;
    }

    public String getEmailSubject() {
        return emailSubject;
    }

    public String getSparkOptions() {
        return sparkOptions;
    }

    public String getStartAction() {
        return startAction;
    }

    public String getAppId() {
        return appId;
    }

    public String getAppName() {
        return appName;
    }

    public String getActionName() {
        return actionName;
    }

    public String getActionType() {
        return actionType;
    }

    public String getNextAction() {
        return nextAction;
    }

    public String getExec() {
        return exec;
    }

    public String getInputFile() {
        return inputFile;
    }

    public String getArguments() {
        return arguments;
    }

    public String getMainClass() {
        return mainClass;
    }

    public String getInsert_time() {
        return insert_time;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public void setNextAction(String nextAction) {
        this.nextAction = nextAction;
    }

    public void setExec(String exec) {
        this.exec = exec;
    }

    public void setInputFile(String inputFile) {
        this.inputFile = inputFile;
    }

    public void setArguments(String arguments) {
        this.arguments = arguments;
    }

    public void setMainClass(String mainClass) {
        this.mainClass = mainClass;
    }

    public void setInsert_time(String insert_time) {
        this.insert_time = insert_time;
    }
}
