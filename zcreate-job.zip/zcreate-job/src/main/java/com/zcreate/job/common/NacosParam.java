package com.zcreate.job.common;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Data
@Component
@PropertySource("classpath:application.properties")
@EnableConfigurationProperties
public class NacosParam {

    @Value("${nacos.ip}")
    private String nacosIp;

    @Value("${nacos.namespace.idb_platform}")
    private String namespaceIdb;
}
