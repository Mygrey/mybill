package com.zcreate.job.model;

import lombok.Data;

@Data
public class JobProjectModel {

    String projectName;
    Long jobNum;

    public JobProjectModel(String name,Long num){
        this.projectName=name;
        this.jobNum=num;
    }

}
