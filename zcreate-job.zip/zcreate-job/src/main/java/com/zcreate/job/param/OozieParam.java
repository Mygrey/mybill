package com.zcreate.job.param;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("file:config/system-config.properties")
@EnableConfigurationProperties
public class OozieParam {

    @Value("${jobTracker}")
    private String jobTracker;

    @Value("fs.defaultFS")
    private String nameNode;

    @Value("${oozie.app.path}")
    private String appPath;

    @Value("${oozie.client.address}")
    private String ClientAddress;

    public String getClientAddress() {
        return ClientAddress;
    }

    public String getAppPath() {
        return appPath;
    }

    public String getJobTracker() {
        return jobTracker;
    }

    public String getNameNode() {
        return nameNode;
    }
}
