package com.zcreate.job.common;

import com.alibaba.nacos.api.NacosFactory;
import com.alibaba.nacos.api.PropertyKeyConst;
import com.alibaba.nacos.api.config.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.StringReader;
import java.util.Properties;

@Component
public class NacosServer {

    @Autowired
    private NacosParam nacosParam;



    public Properties getConfData(String dataId,String groupId) throws Exception{

        Properties properties = new Properties();
        properties.put(PropertyKeyConst.SERVER_ADDR, nacosParam.getNacosIp());
        properties.put(PropertyKeyConst.NAMESPACE, nacosParam.getNamespaceIdb());


        ConfigService configService = NacosFactory.createConfigService(properties);
        String content = configService.getConfig(dataId, groupId, 5000);

        System.out.println(content);

        Properties resultProp=new Properties();
        resultProp.load(new StringReader(content));


        return resultProp;

    }



}
