package com.zcreate.job.common;

import java.io.*;

public class FileUtil {

    public String getFileString(String path) throws IOException {
        // 读
        File file = new File(path);
        FileReader in = new FileReader(file);
        BufferedReader bufIn = new BufferedReader(in);
        // 内存流, 作为临时流
        CharArrayWriter tempStream = new CharArrayWriter();

        // 替换
        String line = null;
        while ( (line = bufIn.readLine()) != null) {
            // 替换每行中, 符合条件的字符串
//            line = line.replaceAll(srcStr, replaceStr).trim()+"\n";
            // 将该行写入内存
            line=line+"\n";
            tempStream.write(line);
            // 添加换行符
//            tempStream.append("\n");

        }
        // 关闭 输入流
       bufIn.close();
       String result= tempStream.toString();
       return result;
        // 将内存中的流 写入 文件
//        FileWriter out = new FileWriter(file);
//        tempStream.writeTo(out);
//        out.close();

    }

}
