package com.zcreate.job.admin;



import org.apache.oozie.client.OozieClient;
import org.apache.oozie.client.OozieClientException;


import java.util.Properties;


public class MyOozieClient {

    private OozieClient client;

    public OozieClient getClient() {
        return client;
    }

    public MyOozieClient(String oozieAddress){
        this.client=new OozieClient(oozieAddress);
    }


    public String oozieSubmit(String hdfsAppPath){

        Properties prop=client.createConfiguration();
        prop.setProperty("oozie.wf.application.path", hdfsAppPath);
        String jobId="";

        try {
            jobId=client.submit(prop);
        } catch (OozieClientException e) {
            e.printStackTrace();
        }

        return jobId;
    }





}
