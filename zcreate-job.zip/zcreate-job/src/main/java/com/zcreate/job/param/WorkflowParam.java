package com.zcreate.job.param;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * ftl模板中的参数应该是json字符串参数的子集
 * ftl模板的中，shell、java等不同模板的参数单独提取出来进行封装
 * 通用的、或参数变动较小，不单独进行封装，统一放在这里
 */

@Component
@PropertySource("classpath:jsonparam.properties")
@EnableConfigurationProperties
public class WorkflowParam {

  //common模板中对应的参数
  @Value("${AppName}")
  private String appName;

  @Value("${StartAction}")
  private String startAction;

  @Value("${ActionList}")
  private String actionList;

  @Value("${ForkList}")
  private String forkList;

  @Value("${JoinList}")
  private String joinList;


  //json字符串中，有关Action的参数名称，包含ftl模板中的参数
  @Value("${ActionTag}")
  private String actionTag;

  @Value("${ActionType}")
  private String actionType;

  @Value("${JobTracker}")
  private String jobTracker;

  @Value("${NameNode}")
  private String nameNode;

  @Value("${ActionName}")
  private String actionName;

  @Value("${FileList}")
  private String fileList;

  @Value("${ArgumentList}")
  private String argumentList;

  @Value("${NextAction}")
  private String nextAction;


  //fork参数，包含json中所有参数，含
  @Value("${Fork}")
  private String fork;

  @Value("${ForkName}")
  private String forkName;

  @Value("${ForkAction}")
  private String forkAction;

  //join参数
  @Value("${JoinTag}")
  private String joinTag;

  @Value("${JoinName}")
  private String joinName;

  //java参数
  @Value("${MainClass}")
  private String mainClass;

  //shell和hive参数
  @Value("${Exec}")
  private String exec;

  //hive参数
  @Value("${HiveParam}")
  private String hiveParam;

  @Value("${HiveFtl}")
  private String hiveFtl;

  @Value("${HiveJdbc}")
  private String hiveJdbc;

  //spark
  @Value("${SparkOptions}")
  private String sparkOptions;

  //email
  @Value("${EmailTo}")
  private String emailTo;

  @Value("${EmailCc}")
  private String emailCc;

  @Value("${EmailSubject}")
  private String emailSubject;

  @Value("${EmailBody}")
  private String emailBody;

  @Value("${Attachment}")
  private String attachment;

  //通用配置参数
  @Value("${ArgString}")
  private String argString;

  @Value("${FileString}")
  private String fileString;

  @Value("${TemplatePath}")
  private String templatePath;

  @Value("${CommonFtl}")
  private String commonFtl;

  @Value("${ShellFtl}")
  private String shellFtl;

  @Value("${JavaFtl}")
  private String javaFtl;

  @Value("${ForkString}")
  private String forkString;

  @Value("${ForkFtl}")
  private String forkFtl;

  @Value("${JoinString}")
  private String joinString;

  @Value("${SparkFtl}")
  private String sparkFtl;

  @Value("${EmailFtl}")
  private String emailFtl;

  @Value("${SqoopFtl}")
  private String sqoopFtl;

  public String getSqoopFtl() {
    return sqoopFtl;
  }

  public String getEmailFtl() {
    return emailFtl;
  }

  public String getEmailTo() {
    return emailTo;
  }

  public String getEmailCc() {
    return emailCc;
  }

  public String getEmailSubject() {
    return emailSubject;
  }

  public String getEmailBody() {
    return emailBody;
  }

  public String getAttachment() {
    return attachment;
  }

  public String getSparkOptions() {
    return sparkOptions;
  }

  public String getSparkFtl() {
    return sparkFtl;
  }

  public String getHiveParam() {
    return hiveParam;
  }

  public String getHiveFtl() {
    return hiveFtl;
  }

  public String getHiveJdbc() {
    return hiveJdbc;
  }

  public String getMainClass() {
    return mainClass;
  }

  public String getExec() {
    return exec;
  }

  public String getJoinString() {
    return joinString;
  }

  public String getForkFtl() {
    return forkFtl;
  }

  public String getForkString() {
    return forkString;
  }

  public String getShellFtl() {
    return shellFtl;
  }

  public String getJavaFtl() {
    return javaFtl;
  }

  public String getAppName() {
    return appName;
  }

  public String getStartAction() {
    return startAction;
  }

  public String getActionList() {
    return actionList;
  }

  public String getForkList() {
    return forkList;
  }

  public String getJoinList() {
    return joinList;
  }

  public String getJobTracker() {
    return jobTracker;
  }

  public String getNameNode() {
    return nameNode;
  }

  public String getActionName() {
    return actionName;
  }

  public String getFileList() {
    return fileList;
  }

  public String getArgumentList() {
    return argumentList;
  }

  public String getNextAction() {
    return nextAction;
  }

  public String getTemplatePath() {
    return templatePath;
  }

  public String getCommonFtl() {
    return commonFtl;
  }



  public String getArgString() {
    return argString;
  }

  public String getFileString() {
    return fileString;
  }


  public String getFork() {
    return fork;
  }

  public String getForkName() {
    return forkName;
  }

  public String getForkAction() {
    return forkAction;
  }

  public String getActionTag() {
    return actionTag;
  }



  public String getActionType() {
    return actionType;
  }

  public String getJoinTag() {
    return joinTag;
  }

  public String getJoinName() {
    return joinName;
  }
}
