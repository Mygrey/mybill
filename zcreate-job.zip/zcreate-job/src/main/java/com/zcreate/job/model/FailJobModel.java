package com.zcreate.job.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class FailJobModel {
    String appId;
    String projectName;

    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    Date endTime;

}
