package com.zcreate.job.param;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("file:config/system-config.properties")
@EnableConfigurationProperties
public class HadoopParam {

    //todo:高可用集群中namenode切换之后，按理来说不应写死ip

    @Value("${fs.defaultFS}")
    private String defaultFs;

    @Value("${hdfs.user}")
    private String hdfsUser;

    @Value("${dfs.nameservices}")
    private String nameService;

    @Value("${fs.namenode1.name}")
    private String node1;

    @Value("${fs.namenode2.name}")
    private String node2;

    @Value("${fs.namenode1.address}")
    private String nameNode1;

    @Value("${fs.namenode2.address}")
    private String nameNode2;

    @Value("${hive.jdbc.url}")
    private String hiveJdbcUrl;


    public String getHiveJdbc() {
        return hiveJdbcUrl;
    }

    public String getDefaultFs() {
        return defaultFs;
    }

    public String getHdfsUser() {
        return hdfsUser;
    }

    public String getNameService() {
        return nameService;
    }

    public String getNode1() {
        return node1;
    }

    public String getNode2() {
        return node2;
    }

    public String getNameNode1() {
        return nameNode1;
    }

    public String getNameNode2() {
        return nameNode2;
    }
}
