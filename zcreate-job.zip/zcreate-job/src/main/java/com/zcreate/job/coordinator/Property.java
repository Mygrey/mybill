package com.zcreate.job.coordinator;

import javax.xml.bind.annotation.*;

/**
 * Created by QXQ on 2019/3/12.
 */
@XmlType(name = "property",propOrder={"name","value"})
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "property")
public class Property {

    private String name;

    private String value;

    public Property() {}

    public Property(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
