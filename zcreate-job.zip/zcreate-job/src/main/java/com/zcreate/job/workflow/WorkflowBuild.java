package com.zcreate.job.workflow;

import com.zcreate.job.common.File2Hdfs;
import com.zcreate.job.common.JobLogMessage;
import com.zcreate.job.dao.ActionInfoDao;
import com.zcreate.job.model.ActionInfo;
import com.zcreate.job.model.ActionType;
import com.zcreate.job.param.HadoopParam;
import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@MapperScan("com.zcreate.job.model")
@ComponentScan("com.zcreate.job.dao")
public class WorkflowBuild extends FreemarkerBuild{


    @Resource
    private ActionInfoDao actionInfo;

    @Autowired
    private File2Hdfs dfs;

    @Autowired
    private HadoopParam hadoopParam;

    private static final Logger logger=LoggerFactory.getLogger(WorkflowBuild.class);


    /**
     * xml通用部分构建，结合action部分，完成整体构建。
     * @param appId
     * @return
     * @throws Exception
     */
    public String buildXMLInfo(String appId) throws Exception{
        List<ActionInfo> actionList=this.actionInfo.findByAppId(appId);
        //action信息获取，非空判断
        if(actionList.size()==0){
            logger.warn(JobLogMessage.ACTION_NOT_FOUND);
        }

        Map<String,String> map=new HashMap<>();
        String actionStr=buildActionInfo(actionList);
        ActionInfo action=actionList.get(0);
        String appName=action.getAppName();
        String startAction=action.getStartAction();
        map.put(this.workflowParam.getAppName(),appName);
        map.put(this.workflowParam.getStartAction(),startAction);
        map.put(this.workflowParam.getActionList(),actionStr);

        String result=templateBuild(this.workflowParam.getCommonFtl(),map);


        return result;
    }

    /**
     * 构建Action部分的xml
     * @param actionList
     * @return
     * @throws Exception
     */
    public String buildActionInfo(List<ActionInfo> actionList) throws Exception{
        String actionStr="";
        Map<String,String> actionMap=new HashMap<>();

        //构建应用程序的lib目录
        String appPath=this.ozParam.getAppPath();
        String libPath=(appPath.endsWith("/") ? appPath : appPath+"/")+actionList.get(0).getAppId()+"lib";

        for(ActionInfo eachAction: actionList){
            String actionType=eachAction.getActionType();

//            Map<String,String> actionMap=commonAction(eachAction);
            if(actionType.equals(ActionType.SHELL.getName())){
                //添加shell类型的action

                actionMap.putAll(commonAction(eachAction));
                actionMap.put(this.workflowParam.getExec(),eachAction.getExec());
                actionStr=actionStr+templateBuild(this.workflowParam.getShellFtl(),actionMap);

            }else if(actionType.equals(ActionType.JAVA.getName())){

                //添加java类型action
                /**
                 * jar包拷贝
                 */

                this.dfs.copyFile(eachAction.getExec(),libPath);

                actionMap.putAll(commonAction(eachAction));
                actionMap.put(this.workflowParam.getMainClass(),eachAction.getMainClass());
                actionStr=actionStr+templateBuild(this.workflowParam.getJavaFtl(),actionMap);

            }else if(actionType.equals(ActionType.JOIN.getName())){
                //添加join类型的xml字符串
                 actionStr=actionStr+buildJoinAction(eachAction);

            }else if(actionType.equals(ActionType.FORK.getName())){
                //添加fork类型的xml字符串
                 actionStr=actionStr+buildForkAction(eachAction);

            }else if(actionType.equals(ActionType.HIVE.getName())){
                //添加hive类型的action
                actionMap.putAll(commonAction(eachAction));
                actionMap.put(this.workflowParam.getExec(),eachAction.getExec());
                actionMap.put(this.workflowParam.getHiveJdbc(),hadoopParam.getHiveJdbc());
                actionStr=actionStr+templateBuild(this.workflowParam.getHiveFtl(),actionMap);

            }else if(actionType.equals(ActionType.SPARK.getName())){
                //添加spark类型的action
                actionMap.putAll(commonAction(eachAction));
                this.dfs.copyFile(eachAction.getExec(),libPath);
                //todo: copy hdfs-site.xml to lib path
                actionMap.put(this.workflowParam.getMainClass(),eachAction.getMainClass());
                String jarExec=eachAction.getExec().substring(eachAction.getExec().lastIndexOf("/") + 1);
                actionMap.put(this.workflowParam.getExec(),jarExec);
                actionMap.put(this.workflowParam.getSparkOptions(),isNull(eachAction.getSparkOptions()));
                actionStr=actionStr+templateBuild(this.workflowParam.getSparkFtl(),actionMap);

            }else if(actionType.equals(ActionType.EMAIL.getName())){

                //构建email类型的action
                actionStr=actionStr+buildEmailAction(eachAction);

            }else if(actionType.equals(ActionType.SQOOP.getName())){
                //构建sqopp类型的action
                actionStr=actionStr+buildSqoopAction(eachAction);
            }
            else{
                logger.warn(JobLogMessage.ACTION_TYPE_NOT_MATCH);
            }

            actionMap.clear();
        }

        return actionStr;
    }


    /**
     * 以从数据库读取并封装好的数据进行创建
     * @param actionInfo
     * @return
     */
    public Map<String,String> commonAction(ActionInfo actionInfo){
        Map<String,String> map=new HashMap<>();
        String argList=actionInfo.getArguments();
        //hive的xml文件中，argument标签使用的是<param>,需要在此处进行替换
        boolean hiveAction=actionInfo.getActionType().equals(ActionType.HIVE.getName());
        boolean shellAction=actionInfo.getActionType().equals(ActionType.SHELL.getName());

        String argreplace="";
        if (hiveAction){
            argreplace=this.workflowParam.getHiveParam();
        }else{
            argreplace=this.workflowParam.getArgString();
        }

        //处理参数字符串
        String argString="";
        if(argList!=null && argList.length()!=0) {
            for (String arg : argList.split(",")) {
                argString = argString + String.format(argreplace, arg) + "\n";
            }
        }
        //处理文件参数字符串
        String fileList=actionInfo.getInputFile();
        String fileString="";

        //如果是shell类型的action，必须将shell路径配置到<file>参数当中
        if(shellAction){
            fileList=fileList+","+actionInfo.getExec();
        }

        if(fileList!=null && fileList.length()!=0){
            for(String file:fileList.split(",")){
                String fileName = file.substring(file.lastIndexOf("/") + 1);
                fileString = fileString + String.format(workflowParam.getFileString(), file, fileName) + "\n";
            }
        }

        //生成map

        map.put(this.workflowParam.getActionName(),isNull(actionInfo.getActionName()));
        map.put(this.workflowParam.getFileList(),fileString);
        map.put(this.workflowParam.getArgumentList(),argString);
        map.put(this.workflowParam.getNextAction(),isNull(actionInfo.getNextAction()));

        //jobTracker和NameNode固定不变
        map.put(this.workflowParam.getJobTracker(),this.ozParam.getJobTracker());
        map.put(this.workflowParam.getNameNode(),this.ozParam.getNameNode());

        return map;
    }


    public String buildEmailAction(ActionInfo action) throws Exception{
        Map<String,String> actionMap=new HashMap<>();
        actionMap.put(this.workflowParam.getActionName(),action.getActionName());
        actionMap.put(this.workflowParam.getNextAction(),action.getNextAction());
        actionMap.put(this.workflowParam.getEmailTo(),action.getEmailTo());
        actionMap.put(this.workflowParam.getEmailCc(),action.getEmailCc());
        actionMap.put(this.workflowParam.getEmailSubject(),action.getEmailSubject());
        //todo: set email body and attachment
        actionMap.put(this.workflowParam.getEmailBody(),"");
        actionMap.put(this.workflowParam.getAttachment(),"");

        return templateBuild(this.workflowParam.getEmailFtl(),actionMap);

    }

    public String buildSqoopAction(ActionInfo action) throws Exception{
        Map<String,String> map=new HashMap<>();
        map.put(this.workflowParam.getActionName(),action.getActionName());
        map.put(this.workflowParam.getJobTracker(),this.ozParam.getJobTracker());
        map.put(this.workflowParam.getNameNode(),this.ozParam.getNameNode());
        map.put(this.workflowParam.getExec(),action.getExec());
        map.put(this.workflowParam.getNextAction(),action.getNextAction());

        return templateBuild(this.workflowParam.getSqoopFtl(),map);
    }

    //构建join字符串
    public String buildJoinAction(ActionInfo action){
        String joinName=action.getActionName();
        String nextAction=action.getNextAction();
        String joinStr="";
        joinStr=joinStr+String.format(this.workflowParam.getJoinString(),joinName,nextAction)+"\n";
        return joinStr;
    }

    //构建fork字符串
    public String buildForkAction(ActionInfo action) throws Exception{
        String forkName=action.getActionName();
        String nextAction=action.getNextAction();
        Map<String,String> map=new HashMap<>();
        String forkStr="";
        for (String next:nextAction.split(",")){
            forkStr=forkStr+String.format(this.workflowParam.getForkString(),next)+"\n";
        }
        map.put(this.workflowParam.getForkName(),forkName);
        map.put(this.workflowParam.getForkAction(),forkStr);

        String result=templateBuild(this.workflowParam.getForkFtl(),map);
        return result;
    }



    public String isNull(String str){
        if(str==null || str.length()==0){
            return "";
        }else{
            return str;
        }
    }


}
