package com.zcreate.job.controller;


import com.zcreate.job.dao.JobAdminDao;
import com.zcreate.job.dao.JobSqlSessionFactory;
import com.zcreate.job.dao.MapperFactory;
import com.zcreate.job.model.JobInfoModel;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping(value = "/idb/admin")
public class JobAdminController {
//
//    private JobAdminDao jobAdmin=MapperFactory.createMapper(JobAdminDao.class,JobSqlSessionFactory.DataSourceEnvironment.oozie);
//
//    @RequestMapping(value = "/index",method = RequestMethod.GET)
//    @ResponseBody
//    public List<JobInfoModel> index(){
//
//        List<JobInfoModel> jobs =jobAdmin.findAll();
//        return jobs;
//    }
//
//    @RequestMapping(value = "/create",method = RequestMethod.GET)
//    public String createJob(){
//
//        return "";
//    }
//
//    @RequestMapping(value = "/search",method = RequestMethod.POST)
//    public String search(){
//
//        return "";
//    }
//
//    @RequestMapping(value = "/delete",method = RequestMethod.POST)
//    public String deleteJob(){
//
//        return "";
//    }
//
//    @RequestMapping(value = "/detail",method = RequestMethod.POST)
//    public String getDetail(){
//
//        return "";
//    }
//
//
//    @RequestMapping(value = "/update",method = RequestMethod.POST)
//    public String updateJob(){
//
//        return "";
//    }
//
//
//    @RequestMapping(value = "/deploy",method = RequestMethod.POST)
//    public String deployJob(){
//
//        return "";
//    }


}
