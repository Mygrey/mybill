package com.zcreate.job.coordinator;

import javax.xml.bind.annotation.*;
import java.util.Set;

/**
 * Created by QXQ on 2019/3/11.
 */
@XmlType(name = "workflow",propOrder={"appPath","configuration"})
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "workflow")
public class Workflow {

    //@XmlElement
    private String appPath;
    @XmlElementWrapper(name = "configuration")
    @XmlElement(name = "property")
    private Set<Property> configuration;

    public Workflow() {}

    public Workflow(String appPath, Set<Property> configuration) {
        this.appPath = appPath;
        this.configuration = configuration;
    }

    public String getAppPath() {
        return appPath;
    }

    public void setAppPath(String appPath) {
        this.appPath = appPath;
    }

    public Set<Property> getConfiguration() {
        return configuration;
    }

    public void setConfiguration(Set<Property> configuration) {
        this.configuration = configuration;
    }
}
