package com.ljj.job.admin.action;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ljj.job.admin.coord.Coordinator;
import com.ljj.job.admin.coord.Property;
import com.ljj.job.admin.coord.Workflow;
import com.ljj.job.admin.entity.TaskRule;
import com.ljj.job.admin.param.OozieParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.util.HashSet;
import java.util.Set;

/**
 * 构建定时任务配置文件
 */
@Component
public class ScheduleBuild {

    @Autowired
    private OozieParam oozie;

    /**
     * coordinator运行配置生成xml文件，返回一个xml文件字符串
     * @param taskRule
     * @return
     */
    public String buildCoordinator(TaskRule taskRule){
        //workFlow的相关配置处理
        //设置调度workflow的相关配置
        Set<Property> configuration = new HashSet<Property>();
        configuration = jsonToPropertys("{\"data\":" + taskRule.getParaId()+ "}");
        configuration.add(new Property("nameNode",oozie.getNameNode()));
        configuration.add(new Property("jobTracker",oozie.getJobTracker()));
        configuration.add(new Property("queueName",oozie.getQueueName()));

        Workflow workflow = new Workflow(oozie.getAppPath() + "/" + taskRule.getAppId() + "/",configuration);
        Set<Workflow> orders = new HashSet<Workflow>();
        orders.add(workflow);

        //coordinator构建
        Coordinator coordXml = new Coordinator(taskRule.getAppName(), taskRule.getCroon(), taskRule.getEffetiveTime().toString()
                , taskRule.getExpiryTime().toString(), oozie.getTimezone(), oozie.getXmlns(),orders);

/*        //datasets部分初始化
        Set<Dataset> dataset = new HashSet<Dataset>();
        dataset.add(new Dataset("name1","frequency1","initialInstance1","timezone1","uriTemplate1","doneFlag1"));
        dataset.add(new Dataset("name2","frequency2","initialInstance2","timezone2","uriTemplate2"));
        coordXml.setDatasets(new Datasets("include",dataset));

        //inputEvents部分初始化
        Set<Data> inputEvents = new HashSet<Data>();
        inputEvents.add(new Data("123","456","789"));
        inputEvents.add(new Data("321","345","000","12","0001"));
        coordXml.setInputEvents(inputEvents);

        //outputEvents部分初始化
        Set<Data> outputEvents = new HashSet<Data>();
        outputEvents.add(new Data("123","456","789"));
        outputEvents.add(new Data("321","345","000","12","0001"));
        coordXml.setOutputEvents(outputEvents);*/

        StringWriter stringWriter = new StringWriter();

        try {
            JAXBContext context = JAXBContext.newInstance(Coordinator.class);
            Marshaller marshal = context.createMarshaller();
            marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            //取消头声明信息
            marshal.setProperty(Marshaller.JAXB_FRAGMENT, true);
            marshal.marshal(coordXml, stringWriter);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return stringWriter.toString();
    }

    /**
     * 把json参数组合转换成Property的Set集合
     * @param para
     * @return
     */
    public static Set<Property> jsonToPropertys(String para) {
        Set<Property> pro = new HashSet<Property>();

        JsonParser parser=new JsonParser();
        JsonObject object=(JsonObject) parser.parse(para);
        JsonArray array=object.get("data").getAsJsonArray();

        for (int i=0; i < array.size(); i++) {
            JsonObject subObject=array.get(i).getAsJsonObject();
            pro.add(new Property(subObject.get("key").toString(),subObject.get("value").toString()));
        }
        return pro;
    }

    public static void main(String[] args) {
        String st = "{\"data\":[\n" +
                " {\"key\": \"011\",\"value\": \"qxq\",\"desc\": \"0\"},\n" +
                " {\"key\": \"011\",\"value\": \"qxq\",\"desc\": \"0\"}]\n" +
                "}";

        //jsonToObject(st);
    }

}
