package com.ljj.job.admin.entity.modulue;

import lombok.Data;

import java.util.Map;

/**
 * 存储每个action的数据
 * map存放相应的参数，目前已有参数名称统一为：
 * Exec,MainClass,SparkOptions,Arguments,InputFile
 */
@Data
public class ActionParamModel {
    String actionId;
    String actionName;
    String actionType;
    String actionScene;
    String nextAction;

    //action参数
    Map<String,String> paramMap;
}
