package com.ljj.job.admin.workflow;



import com.ljj.job.admin.entity.TaskRule;
import com.ljj.job.admin.entity.modulue.ActionParamModel;
import com.ljj.job.admin.entity.modulue.ActionType;
import com.ljj.job.admin.entity.modulue.TaskParamModel;
import com.ljj.job.admin.param.HadoopParam;
import com.ljj.job.admin.tools.File2Hdfs;
import com.ljj.job.admin.tools.JobLogMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

@Component
public class WorkflowBuild extends FreemarkerBuild{


    @Autowired
    private File2Hdfs dfs;

    @Autowired
    private HadoopParam hadoopParam;


    private static final Logger logger=LoggerFactory.getLogger(WorkflowBuild.class);


    public String buildXMLInfo( TaskParamModel taskParam) throws Exception{
        TaskRule schedule=taskParam.getTaskRule();
        List<ActionParamModel> actionList=taskParam.getActionList();

        //构建action
        Map<String,String> map=new HashMap<>();
        String actionStr=buildActionInfo(schedule,actionList);

        //以ID作为name进行传入
        map.put(this.workflowParam.getAppName(),taskParam.getAppId());
        map.put(this.workflowParam.getStartAction(),taskParam.getStartAction());
        map.put(this.workflowParam.getActionList(),actionStr);
        map.put("ErrorMessage","[${wf:errorMessage(wf:lastErrorNode())}]");

        String result=templateBuild(this.workflowParam.getCommonFtl(),map);


        return result;
    }

    /**
     * 构建Action部分的xml
     * @param schedule
     * @param actionList
     * @return
     * @throws Exception
     */
    public String buildActionInfo(TaskRule schedule,List<ActionParamModel> actionList) throws Exception{
        String actionStr="";
        Map<String,String> actionMap=new HashMap<>();


        String emailString="";
        String errorTo="Kill";
        int emailFlag=schedule.getEmailNotification();
        if (emailFlag==1){
            int randomNum=new Random().nextInt(1000);
            String emailId="email-"+randomNum;
            emailString=buildEmailAction(emailId,schedule.getRecipient(),schedule.getCarbonCopy(),schedule.getEmailTitle());
            errorTo=emailId;
        }



        //构建应用程序的lib目录
        String appPath=this.ozParam.getAppPath();
        String filePath=(appPath.endsWith("/")  ? appPath : appPath+"/")+schedule.getAppId();
        String libPath=(appPath.endsWith("/")  ? appPath : appPath+"/")+schedule.getAppId()+"/lib/";

        for(ActionParamModel eachAction: actionList){

            actionMap.put("KillOrEmail",errorTo);

            String actionType=eachAction.getActionType();

            if(actionType.equals(ActionType.SHELL.getName())){
                //添加shell类型的action

                actionMap.putAll(commonAction(eachAction));
                actionMap.put(this.workflowParam.getExec(),eachAction.getParamMap().get("Exec"));
                actionStr=actionStr+templateBuild(this.workflowParam.getShellFtl(),actionMap);

            }else if(actionType.equals(ActionType.JAVA.getName())){

                //添加java类型action
                /**
                 * jar包拷贝
                 */

                String execPath=eachAction.getParamMap().get("Exec");
                String jarName=execPath.substring(execPath.lastIndexOf("/") + 1);
                this.dfs.copyHdfsFile(eachAction.getParamMap().get("Exec"),libPath+jarName);

                actionMap.putAll(commonAction(eachAction));
                actionMap.put(this.workflowParam.getMainClass(),eachAction.getParamMap().get("MainClass"));
                actionStr=actionStr+templateBuild(this.workflowParam.getJavaFtl(),actionMap);

            }else if(actionType.equals(ActionType.JOIN.getName())){
                //添加join类型的xml字符串
                 actionStr=actionStr+buildJoinAction(eachAction);

            }else if(actionType.equals(ActionType.FORK.getName())){
                //添加fork类型的xml字符串
                 actionStr=actionStr+buildForkAction(eachAction);

            }else if(actionType.equals(ActionType.HIVE.getName())){
                //添加hive类型的action

                actionMap.putAll(commonAction(eachAction));
                actionMap.put(this.workflowParam.getExec(),eachAction.getParamMap().get("Exec"));
                actionMap.put(this.workflowParam.getHiveJdbc(),hadoopParam.getHiveJdbcUrl());
                actionStr=actionStr+templateBuild(this.workflowParam.getHiveFtl(),actionMap);

            }else if(actionType.equals(ActionType.SPARK.getName())){

                //添加spark类型的action
                actionMap.putAll(commonAction(eachAction));
                String execPath=eachAction.getParamMap().get("Exec");
                String jarName=execPath.substring(execPath.lastIndexOf("/") + 1);
                this.dfs.copyHdfsFile(execPath,libPath+jarName);
                //todo: copy hdfs-site.xml to lib path
                actionMap.put(this.workflowParam.getMainClass(),eachAction.getParamMap().get("MainClass"));
                String jarExec=execPath.substring(execPath.lastIndexOf("/") + 1);
                actionMap.put(this.workflowParam.getExec(),jarExec);
                actionMap.put(this.workflowParam.getSparkOptions(),isNull(eachAction.getParamMap().get("SparkOptions")));
                actionStr=actionStr+templateBuild(this.workflowParam.getSparkFtl(),actionMap);

            }else if(actionType.equals(ActionType.SQOOP.getName())){
                //构建sqopp类型的action
                actionStr=actionStr+buildSqoopAction(eachAction,errorTo);

            }else if(actionType.equals(ActionType.DATAX.getName())){

                //构建datax类型action
                String shellFile=buildSSH(eachAction,filePath);
                //设置文件参数
                Map<String,String> paramMap=eachAction.getParamMap();
                paramMap.put("InputFile",shellFile);
                eachAction.setParamMap(paramMap);

                actionMap.putAll(commonAction(eachAction));
                actionMap.put(this.workflowParam.getExec(),shellFile);
                actionStr=actionStr+templateBuild(this.workflowParam.getShellFtl(),actionMap);


            }else if(actionType.equals(ActionType.FLUME.getName())){
                //构建flume类型action
                String shellPath=buildSSH(eachAction,filePath);
                //设置文件参数
                Map<String,String> paramMap=eachAction.getParamMap();
                paramMap.put("InputFile",shellPath);
                eachAction.setParamMap(paramMap);

                actionMap.put(this.workflowParam.getExec(),shellPath);
                actionMap.putAll(commonAction(eachAction));

                actionStr=actionStr+templateBuild(this.workflowParam.getShellFtl(),actionMap);

            }
            else{
                logger.warn(JobLogMessage.ACTION_TYPE_NOT_MATCH);
            }

            actionMap.clear();
        }

        actionStr=actionStr+emailString;

        return actionStr;
    }


    /**
     * 以从数据库读取并封装好的数据进行创建
     * @param actionInfo
     * @return
     */
    public Map<String,String> commonAction(ActionParamModel actionInfo){
        Map<String,String> map=new HashMap<>();
        Map<String,String> paramMap=actionInfo.getParamMap();

        String argList=paramMap.get("Arguments");
        //spark或java的xml文件中，argument标签使用的是<arg>,需要在此处进行替换
        /**
         * shell:<argument></argument>,<file></file>
         * hive2:<argument></argument>,<file></file>
         * spark:<arg></arg>,<file></file>
         * java:<arg></arg>,<file></file>
         *
         */
        boolean hiveAction=actionInfo.getActionType().equals(ActionType.HIVE.getName());
        boolean shellAction=actionInfo.getActionType().equals(ActionType.SHELL.getName());
        String argreplace="";
        if (hiveAction || shellAction){
            argreplace=this.workflowParam.getHiveParam();
        }else{
            argreplace=this.workflowParam.getArgString();
        }

        //处理参数字符串
        String argString="";
        if(argList!=null && argList.length()!=0) {
            for (String arg : argList.split(",")) {
                argString = argString + String.format(argreplace, arg) + "\n";
            }
        }
        //处理文件参数字符串
        String fileList=paramMap.get("InputFile");
        String fileString="";

        //如果是shell类型的action，必须将exec路径配置到<file>参数当中

        if(fileList!=null && fileList.length()!=0){
            for(String file:fileList.split(",")){
                String fileName = file.substring(file.lastIndexOf("/") + 1);
                fileString = fileString + String.format(workflowParam.getFileString(), file, fileName) + "\n";
            }
        }

        //生成map

        map.put(this.workflowParam.getActionName(),isNull(actionInfo.getActionId()));
        map.put(this.workflowParam.getFileList(),fileString);
        map.put(this.workflowParam.getArgumentList(),argString);
        map.put(this.workflowParam.getNextAction(),isNull(actionInfo.getNextAction()));

        //jobTracker和NameNode固定不变
        map.put(this.workflowParam.getJobTracker(),this.ozParam.getJobTracker());
        map.put(this.workflowParam.getNameNode(),this.ozParam.getNameNode());


        return map;
    }

    public String buildSSH(ActionParamModel  actionInfo,String filePath) throws Exception{
        Map<String,String> map=new HashMap<>();
        map.put("IpAddress",hadoopParam.getJarNodeIp());
        map.put("NodePass",hadoopParam.getJarNodePass());
        map.put("ActionId",actionInfo.getActionId());
        map.put("ActionScene",actionInfo.getActionScene());
        if(actionInfo.getActionType().equals(ActionType.DATAX.getName())){
            map.put("JarPath",hadoopParam.getDataxPath());
        }else{
            map.put("JarPath",hadoopParam.getFlumePath());
        }
        String shellStr=templateBuild("ssh.ftl",map).replace("\r\n","\n");
        String shellFile=filePath+"/shell.sh";
        this.dfs.saveWorkflow(shellFile,shellStr);


        return shellFile;
    }


    public String buildEmailAction(String emailId,String emailTo,String emailCc,String emailTitle) throws Exception {
        Map<String,String> actionMap=new HashMap<>();
        actionMap.put(this.workflowParam.getActionName(),emailId);
        actionMap.put(this.workflowParam.getEmailTo(),emailTo);
        actionMap.put(this.workflowParam.getEmailCc(),isNull(emailCc));
        actionMap.put(this.workflowParam.getEmailSubject(),emailTitle+"-${wf:id()}");
        actionMap.put(this.workflowParam.getEmailBody(),"[${wf:errorMessage(wf:lastErrorNode())}]");
//        actionMap.put(this.workflowParam.getAttachment(),"");
        return templateBuild(this.workflowParam.getEmailFtl(),actionMap);

    }

    public String buildSqoopAction(ActionParamModel action,String errorTo) throws Exception{
        Map<String,String> map=new HashMap<>();
        map.put(this.workflowParam.getActionName(),action.getActionId());
        map.put(this.workflowParam.getJobTracker(),this.ozParam.getJobTracker());
        map.put(this.workflowParam.getNameNode(),this.ozParam.getNameNode());
        map.put(this.workflowParam.getExec(),action.getParamMap().get("Exec"));
        map.put(this.workflowParam.getNextAction(),action.getNextAction());
        map.put("KillOrEmail",errorTo);

        return templateBuild(this.workflowParam.getSqoopFtl(),map);
    }

    //构建join字符串
    public String buildJoinAction(ActionParamModel action){
        String joinName=action.getActionName();
        String nextAction=action.getNextAction();
        String joinStr="";
        joinStr=joinStr+String.format(this.workflowParam.getJoinString(),joinName,nextAction)+"\n";
        return joinStr;
    }

    //构建fork字符串
    public String buildForkAction(ActionParamModel action) throws Exception{
        String forkName=action.getActionName();
        String nextAction=action.getNextAction();
        Map<String,String> map=new HashMap<>();
        String forkStr="";
        for (String next:nextAction.split(",")){
            forkStr=forkStr+String.format(this.workflowParam.getForkString(),next)+"\n";
        }
        map.put(this.workflowParam.getForkName(),forkName);
        map.put(this.workflowParam.getForkAction(),forkStr);

        String result=templateBuild(this.workflowParam.getForkFtl(),map);
        return result;
    }



    public String isNull(String str){
        if(str==null || str.length()==0){
            return "";
        }else{
            return str;
        }
    }


}
