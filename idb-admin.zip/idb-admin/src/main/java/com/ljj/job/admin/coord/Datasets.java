package com.ljj.job.admin.coord;

import javax.xml.bind.annotation.*;
import java.util.Set;

/**
 * Created by QXQ on 2019/3/12.
 */
@XmlType(name = "datasets",propOrder={"include","dataset"})
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "datasets")
public class Datasets {

    private String include;
    private Set<Dataset> dataset;

    public Datasets() {}

    public Datasets(String include, Set<Dataset> dataset) {
        this.include = include;
        this.dataset = dataset;
    }

    public String getInclude() {
        return include;
    }

    public void setInclude(String include) {
        this.include = include;
    }

    public Set<Dataset> getDataset() {
        return dataset;
    }

    public void setDataset(Set<Dataset> dataset) {
        this.dataset = dataset;
    }

}
