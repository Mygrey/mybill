package com.ljj.job.admin.coord;

import javax.xml.bind.annotation.*;

/**
 * Created by QXQ on 2019/3/12.
 */
@XmlType(name = "dataset",propOrder={"name","frequency","initialInstance","timezone","uriTemplate","doneFlag"})
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "dataset")
public class Dataset {
    @XmlAttribute
    private String name;
    @XmlAttribute
    private String frequency;
    @XmlAttribute(name = "initial-instance")
    private String initialInstance;
    @XmlAttribute
    private String timezone;
    @XmlElement(name = "uri-template")
    private String uriTemplate;
    @XmlElement(name = "done-flag")
    private String doneFlag;

    public Dataset() {}

    public Dataset(String name, String frequency, String initialInstance, String timezone, String uriTemplate) {
        this.name = name;
        this.frequency = frequency;
        this.initialInstance = initialInstance;
        this.timezone = timezone;
        this.uriTemplate = uriTemplate;
    }

    public Dataset(String name, String frequency, String initialInstance, String timezone, String uriTemplate, String doneFlag) {
        this(name, frequency, initialInstance, timezone, uriTemplate);
        this.doneFlag = doneFlag;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getInitialInstance() {
        return initialInstance;
    }

    public void setInitialInstance(String initialInstance) {
        this.initialInstance = initialInstance;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public String getUriTemplate() {
        return uriTemplate;
    }

    public void setUriTemplate(String uriTemplate) {
        this.uriTemplate = uriTemplate;
    }

    public String getDoneFlag() {
        return doneFlag;
    }

    public void setDoneFlag(String doneFlag) {
        this.doneFlag = doneFlag;
    }
}
