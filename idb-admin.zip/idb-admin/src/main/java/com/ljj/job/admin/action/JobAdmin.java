package com.ljj.job.admin.action;


import com.ljj.job.admin.entity.TaskRule;
import com.ljj.job.admin.entity.modulue.TaskParamModel;
import com.ljj.job.admin.param.OozieParam;
import com.ljj.job.admin.tools.File2Hdfs;
import com.ljj.job.admin.tools.FileUtil;
import com.ljj.job.admin.workflow.WorkflowBuild;
import org.apache.oozie.client.OozieClient;
import org.apache.oozie.client.OozieClientException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

@Component
public class JobAdmin {

    @Autowired
    private WorkflowBuild workflow;

    @Autowired
    private ScheduleBuild scheduleBuild;

    @Autowired
    private File2Hdfs hdfsFile;

    @Autowired
    private OozieParam oozie;


    /**
     * -获得需要创建的appId
     * -创建相关应用程序的目录
     * -关于lib目录的创建，统一进行创建，没有则为空
     * -通过WorkflowBuild类进行workflow的创建
     * -将workflow上传至指定目录：path/${appId}/workflow.xml
     * -创建job.properties文件，上传上述目录
     * -创建运行计划coordinate文件，上传上述目录
     * -构建oozie client，配置传入与job.properties中的配置可能重复
     * -oozie client submit任务
     * -获取oozie任务信息
     *
     *
     */

    /**
     * 任务创建接口
     * @param taskParam
     * @return
     */
    public String createJob(TaskParamModel taskParam){
        TaskRule schedule=taskParam.getTaskRule();
        String appId=schedule.getAppId();
        int coordFlag=schedule.getJobType();
        String filePath=initFolder(appId);
        String xmlPath=filePath+"/workflow.xml";
        String jobPath=filePath+"/job.properties";
        String coordPath=filePath+"/coordinator.xml";

        //构建workflow.xml
        String xmlStr="";
        try {
            xmlStr=workflow.buildXMLInfo(taskParam);
        } catch (Exception e) {
            e.printStackTrace();
        }
        hdfsFile.saveWorkflow(xmlPath,xmlStr);

        //构建job.properties文件
        String propStr="";
        try {
            propStr=new FileUtil().getFileString("classpath:job.properties");
        } catch (IOException e) {
            e.printStackTrace();
        }

        hdfsFile.saveWorkflow(jobPath,propStr);

        //生成定时任务的xml配置文件
        if(coordFlag==1){
            String coordXML=this.scheduleBuild.buildCoordinator(schedule);
            hdfsFile.saveWorkflow(coordPath,coordXML);
        }


        //连接oozie提交项目
        String jobId= coordFlag==1 ? coordSubmit(oozie.getNameNode()+filePath) : wfSubmit(oozie.getNameNode()+filePath);


        return jobId;
    }


    /**
     * 停止任务接口
     * 传入参数为oozie的jobId
     * @param jobId
     * @return 1/0 success/failed
     */
    public int killJob(String jobId){
        OozieClient client = new OozieClient(oozie.getClientAddress());
        try {
           client.kill(jobId);
           return 1;
        } catch (OozieClientException e) {
            e.printStackTrace();
            return 0;
        }

    }

    /**
     * 任务启动接口
     * 传入参数为oozie的jobId
     * @param jobId
     * @return 1/0 success/failed
     */
    public int startJob(String jobId){
        OozieClient client = new OozieClient(oozie.getClientAddress());
        try {
            client.start(jobId);
            return 1;
        } catch (OozieClientException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 初始化应用程序文件夹
     * @param appId
     * @return
     */
    public String initFolder(String appId){
        String appPath=oozie.getAppPath();
        String filePath="";

        if(appPath.endsWith("/")){
            filePath=appPath+appId;

        }else{
            filePath=appPath+"/"+appId;
        }
        String libPath=filePath+"/lib";

        if(!hdfsFile.checkFile(filePath)){
            hdfsFile.createDir(filePath);
        }

        if(!hdfsFile.checkFile(libPath)){
            hdfsFile.createDir(libPath);
        }

        return filePath;
    }


    /**
     * 普通workflow任务提交
     * @param hdfsAppPath
     * @return
     */
    public String wfSubmit(String hdfsAppPath){
        OozieClient client=new OozieClient(this.oozie.getClientAddress());
        Properties prop=client.createConfiguration();
        FileReader in = null;

        try {
            in = new FileReader(ResourceUtils.getFile("classpath:job.properties"));
            prop.load(in);
        } catch (Exception e) {
            e.printStackTrace();
        }
        prop.setProperty("oozie.wf.application.path", hdfsAppPath);
        String jobId="";

        try {
            jobId=client.submit(prop);
        } catch (OozieClientException e) {
            e.printStackTrace();
        }

        return jobId;
    }

    /**
     * 定时任务提交
     * @param hdfsAppPath
     * @return
     */
    public String coordSubmit(String hdfsAppPath){
        OozieClient client=new OozieClient(this.oozie.getClientAddress());
        Properties prop=client.createConfiguration();
//        prop.setProperty("oozie.wf.application.path", hdfsAppPath);

        FileReader in = null;

        try {
            in = new FileReader(ResourceUtils.getFile("classpath:job.properties"));
            prop.load(in);
        } catch (Exception e) {
            e.printStackTrace();
        }
        prop.setProperty("oozie.coord.application.path",hdfsAppPath);
        prop.setProperty("workflowAppUri",hdfsAppPath);

        String jobId="";

        try {
            jobId=client.submit(prop);
        } catch (OozieClientException e) {
            e.printStackTrace();
        }

        return jobId;
    }




}
