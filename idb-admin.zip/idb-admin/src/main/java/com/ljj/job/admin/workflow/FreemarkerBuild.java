package com.ljj.job.admin.workflow;


import com.ljj.job.admin.param.OozieParam;
import com.ljj.job.admin.param.WorkflowParam;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.StringWriter;
import java.util.Map;


@Component
public class FreemarkerBuild {

    @Autowired
    public WorkflowParam workflowParam;

    @Autowired
    public OozieParam ozParam;

    /**
     * 通过ftl模板，生成对应的xml文件模块
     * 前者为模板路径，后者为模板中需要替换的参数Map
     * @param templateName
     * @param map
     * @return
     * @throws Exception
     */
    public String templateBuild(String templateName,Map<String,String> map) throws Exception{
        String templateString="";

        Configuration cfg=new Configuration(Configuration.VERSION_2_3_20);

        cfg.setDirectoryForTemplateLoading(new File(workflowParam.getTemplatePath()));
        cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
        Template temp = cfg.getTemplate(templateName);
//            Writer out = new OutputStreamWriter(System.out);
        StringWriter stringWriter = new StringWriter();
//            BufferedWriter writer = new BufferedWriter(stringWriter);

        temp.process(map, stringWriter);
//            StringReader reader = new StringReader(stringWriter.toString());
        templateString=stringWriter.getBuffer().toString();

        stringWriter.flush();
        stringWriter.close();

        return templateString+"\n";

    }
}
