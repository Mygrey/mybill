package com.ljj.job.admin.entity.modulue;

public enum ActionType {

    SHELL("shell"),JAVA("java"),JOIN("join"),FORK("fork"),
    SPARK("spark"),HIVE("hive"),SQOOP("sqoop"),DATAX("datax"),FLUME("flume");

    private String name;

    private ActionType(String name){
        this.name=name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
