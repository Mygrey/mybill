package com.ljj.job.admin.coord;

import javax.xml.bind.annotation.*;
import java.util.Set;

/**
 * Created by QXQ on 2019/3/11.
 */
@XmlRootElement(name = "coordinator-app")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlAccessorOrder(XmlAccessOrder.UNDEFINED)
@XmlType(name = "name",propOrder = { "name", "frequency", "start", "end", "timezone", "xmlns", "controls", "datasets", "inputEvents", "outputEvents", "action" })
public class Coordinator {

    @XmlAttribute
    private String name;

    @XmlAttribute
    private String frequency;

    @XmlAttribute
    private String start;

    @XmlAttribute
    private String end;

    @XmlAttribute
    private String timezone;

    @XmlAttribute
    private String xmlns;

    @XmlElement(name = "controls")
    private Controls controls;

    @XmlElement(name = "datasets")
    private Datasets datasets;

    @XmlElementWrapper(name = "input-events")
    @XmlElement(name = "data-in")
    private Set<Data> inputEvents;

    @XmlElementWrapper(name = "output-events")
    @XmlElement(name = "data-out")
    private Set<Data> outputEvents;

    @XmlElementWrapper(name = "action")
    @XmlElement(name = "workflow")
    private Set<Workflow> action;

    public Coordinator() {}

    public Coordinator(String name, String frequency, String start, String end, String timezone, String xmlns, Set<Workflow> action) {
        this.name = name;
        this.frequency = frequency;
        this.start = start;
        this.end = end;
        this.timezone = timezone;
        this.xmlns = xmlns;
        this.action = action;
    }

    public Coordinator(String name, String frequency, String start, String end, String timezone, String xmlns, Controls controls, Set<Workflow> action) {
        this(name, frequency, start, end, timezone, xmlns, action);
        this.controls = controls;
    }

    public Coordinator(String name, String frequency, String start, String end, String timezone, String xmlns, Controls controls, Datasets datasets, Set<Workflow> action) {
        this(name, frequency, start, end, timezone, xmlns, controls, action);
        this.datasets = datasets;
    }
    public Coordinator(String name, String frequency, String start, String end, String timezone, String xmlns, Controls controls, Datasets datasets,
                       Set<Data> inputEvents, Set<Workflow> action) {
        this(name, frequency, start, end, timezone, xmlns, controls, datasets, action);
        this.inputEvents = inputEvents;
    }

    public Coordinator(String name, String frequency, String start, String end, String timezone, String xmlns, Controls controls, Datasets datasets,
                       Set<Data> inputEvents, Set<Data> outputEvents, Set<Workflow> action) {
        this(name, frequency, start, end, timezone, xmlns, controls, datasets, inputEvents, action);
        this.outputEvents = outputEvents;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Controls getControls() {
        return controls;
    }

    public void setControls(Controls controls) {
        this.controls = controls;
    }

    public Datasets getDatasets() {
        return datasets;
    }

    public void setDatasets(Datasets datasets) {
        this.datasets = datasets;
    }

    public Set<Data> getInputEvents() {
        return inputEvents;
    }

    public void setInputEvents(Set<Data> inputEvents) {
        this.inputEvents = inputEvents;
    }

    public Set<Data> getOutputEvents() {
        return outputEvents;
    }

    public void setOutputEvents(Set<Data> outputEvents) {
        this.outputEvents = outputEvents;
    }


    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public String getXmlns() {
        return xmlns;
    }

    public void setXmlns(String xmlns) {
        this.xmlns = xmlns;
    }

    public Set<Workflow> getAction() {
        return action;
    }

    public void setAction(Set<Workflow> workflow) {
        this.action = workflow;
    }

}
