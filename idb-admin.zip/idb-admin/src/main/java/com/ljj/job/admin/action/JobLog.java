package com.ljj.job.admin.action;



import com.ljj.job.admin.param.HadoopParam;
import com.ljj.job.admin.param.OozieParam;
import com.ljj.job.admin.tools.File2Hdfs;
import org.apache.oozie.client.OozieClient;
import org.apache.oozie.client.OozieClientException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JobLog {

    @Autowired
    private OozieParam oozieParam;

    @Autowired
    private File2Hdfs hdfsClient;

    @Autowired
    private HadoopParam hadoopParam;

    /**
     * 获取jobId对应的系统日志
     * @param jobId
     * @return
     */
    public String getSysLog(String jobId){

        OozieClient client=new OozieClient(oozieParam.getClientAddress());
        String jobLog="";
        try {
            jobLog=client.getJobLog(jobId);
        } catch (OozieClientException e) {
            e.printStackTrace();
        }

        return jobLog;
    }


    /**
     * 获取日志查询的日期和actionId，读取对应的hdfs上的日志文件内容进行返回
     * @param logDate
     * @param actionId
     * @return
     */
    public String getActionLog(String logDate,String actionId){
        String temp=this.hadoopParam.getLogPath();
        String logPath=(temp.endsWith("/") ? temp : temp+"/")+logDate+"/"+actionId+".log";

        String fileContent="";
        try {
            if(hdfsClient.checkFile(logPath)) {
                fileContent = hdfsClient.getFile(logPath);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return fileContent;
    }

}
