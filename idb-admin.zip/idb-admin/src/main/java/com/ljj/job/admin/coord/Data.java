package com.ljj.job.admin.coord;

import javax.xml.bind.annotation.*;

/**
 * Created by QXQ on 2019/3/12.
 */
@XmlType(name = "data",propOrder={"name","dataset","instance","startInstance","endInstance"})
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "data")
public class Data {
    @XmlAttribute
    private String name;
    @XmlAttribute
    private String dataset;
    @XmlElement
    private String instance;
    @XmlElement(name = "start-instance")
    private String startInstance;
    @XmlElement(name = "end-instance")
    private String endInstance;

    public Data() {}

    public Data(String name, String dataset, String instance) {
        this.name = name;
        this.dataset = dataset;
        this.instance = instance;
    }

    public Data(String name, String dataset, String instance, String startInstance, String endInstance) {
        this.name = name;
        this.dataset = dataset;
        this.instance = instance;
        this.startInstance = startInstance;
        this.endInstance = endInstance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDataset() {
        return dataset;
    }

    public void setDataset(String dataset) {
        this.dataset = dataset;
    }


    public String getInstance() {
        return instance;
    }

    public void setInstance(String instance) {
        this.instance = instance;
    }

    public String getStartInstance() {
        return startInstance;
    }

    public void setStartInstance(String startInstance) {
        this.startInstance = startInstance;
    }

    public String getEndInstance() {
        return endInstance;
    }

    public void setEndInstance(String endInstance) {
        this.endInstance = endInstance;
    }
}
