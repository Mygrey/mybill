package com.ljj.job.admin.entity;


import lombok.Data;

import java.util.Date;

/**
 * Created by QXQ on 2019/3/26.
 */
@Data
public class TaskRule  {

    private String appId;

    private String appName;


    private int jobType;


    private String croon;


    private String effetiveTime;


    private String expiryTime;


    private int rerunTimes;


    private int rerunInterval;


    private String project;


    private String paraId;

/*    @ApiModelProperty(value = "其它参数")
    private String otherPara;*/


    private String description;

/*    @ApiModelProperty(name = "project", value = "任务所述项目", required = false)
    private String project;*/


    private int emailNotification;


    private String emailTitle;


    private String recipient;


    private String carbonCopy;


    private int clusterId;


    private Date insertTime;


    private Date updateTime;


    private String operator;


    private Long premissId;
}
