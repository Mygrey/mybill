package com.ljj.job.admin.coord;

import javax.xml.bind.annotation.*;

/**
 * Created by QXQ on 2019/3/12.
 */
@XmlType(name = "controls",propOrder={"timeout","concurrency","execution"})
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "controls")
public class Controls {

    private String timeout;

    private String concurrency;

    private String execution;

    public Controls() {}

    public Controls(String timeout, String concurrency, String execution) {
        this.timeout = timeout;
        this.concurrency = concurrency;
        this.execution = execution;
    }

    public String getExecution() {
        return execution;
    }

    public void setExecution(String execution) {
        this.execution = execution;
    }

    public String getConcurrency() {
        return concurrency;
    }

    public void setConcurrency(String concurrency) {
        this.concurrency = concurrency;
    }

    public String getTimeout() {
        return timeout;
    }

    public void setTimeout(String timeout) {
        this.timeout = timeout;
    }

}
