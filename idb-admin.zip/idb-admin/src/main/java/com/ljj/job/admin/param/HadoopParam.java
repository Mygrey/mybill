package com.ljj.job.admin.param;


import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Data
@Component
@PropertySource("classpath:config/system-config.properties")
@EnableConfigurationProperties
public class HadoopParam {

    //todo:高可用集群中namenode切换之后，按理来说不应写死ip

    @Value("${fs.defaultFS}")
    private String defaultFs;

    @Value("${hdfs.user}")
    private String hdfsUser;

    @Value("${dfs.nameservices}")
    private String nameService;

    @Value("${fs.namenode1.name}")
    private String node1;

    @Value("${fs.namenode2.name}")
    private String node2;

    @Value("${fs.namenode1.address}")
    private String nameNode1;

    @Value("${fs.namenode2.address}")
    private String nameNode2;

    @Value("${hive.jdbc.url}")
    private String hiveJdbcUrl;

    @Value("${jar.node.ip}")
    private String jarNodeIp;

    @Value("${jar.node.pass}")
    private String jarNodePass;

    @Value("${datax.jar.path}")
    private String dataxPath;

    @Value("${flume.jar.path}")
    private String flumePath;

    @Value("${oozie.log.path}")
    private String logPath;

}
