package com.ljj.job.admin.entity.modulue;


import com.ljj.job.admin.entity.TaskRule;
import lombok.Data;

import java.util.List;

/**
 * 任务所有参数汇总，包含任务参数，schedule参数和action参数
 */

@Data
public class TaskParamModel {
    String appId;
    String appName;
    String startAction;

    //schedule表数据封装,对应 t_job_schedule_rule
    TaskRule taskRule;

    //action数据封装
    List<ActionParamModel> actionList;
}
