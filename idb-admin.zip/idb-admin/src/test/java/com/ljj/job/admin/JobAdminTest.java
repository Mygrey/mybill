package com.ljj.job.admin;


import com.ljj.job.admin.action.JobAdmin;
import com.ljj.job.admin.action.JobLog;
import com.ljj.job.admin.entity.TaskRule;
import com.ljj.job.admin.entity.modulue.ActionParamModel;
import com.ljj.job.admin.entity.modulue.TaskParamModel;
import com.ljj.job.admin.tools.File2Hdfs;
import com.ljj.job.admin.tools.FileUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
public class JobAdminTest {

    @Autowired
    private JobAdmin admin;

    @Autowired
    private JobLog jobLog;

    @Autowired
    private File2Hdfs myHdfs;

    @Test
    public void dataxTest(){


        TaskParamModel taskParam=buildSqoopModel();
        String  jobId=admin.createJob(taskParam);
        System.out.println("============="+jobId);
        admin.startJob(jobId);
//          admin.killJob("0007834-190412140033123-oozie-oozi-C");
//        admin.killJob(jobId);

//        System.out.println(jobLog.getSysLog("0007787-190411142818045-oozie-oozi-W"));

//        FileUtil file=new FileUtil();
//        System.out.println(this.getClass().getResource("job.properties"));
//        try {
//            String result=file.getFileString("src/main/resources/job.properties");
//            System.out.println(result);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

    }

    //测试datax & flume运行情况
    public TaskParamModel buildModel(){
        TaskParamModel taskParam=new TaskParamModel();
        TaskRule schedule=new TaskRule();
        ActionParamModel actions=new ActionParamModel();
        schedule.setAppId("idb-20190409-test");
        schedule.setAppName("IDB App Test");
        schedule.setJobType(0);
        schedule.setProject("IDB Project");
        schedule.setEmailNotification(0);

        actions.setActionId("datax-1");
        actions.setActionName("Datax Test");
        actions.setActionType("datax");
        actions.setActionScene("dbreader-kafkawriter");
        actions.setNextAction("End");

        List<ActionParamModel> arr=new ArrayList<>();

        Map<String,String> paramMap=new HashMap<>();
//        paramMap.put("Exec","/home/hdfs/apps/1/shell.sh");
//        paramMap.put("InputFile","/home/hdfs/apps/1/shell.sh");
        actions.setParamMap(paramMap);

        arr.add(actions);
        taskParam.setAppId("idb-20190409-test");
        taskParam.setAppName("IDB App Test");
        taskParam.setStartAction("datax-1");
        taskParam.setTaskRule(schedule);
        taskParam.setActionList(arr);
        return taskParam;

    }

    //测试shell脚本运行情况,同时设定失败发邮件
    public TaskParamModel buildShellModel(){
        TaskParamModel taskParam=new TaskParamModel();
        TaskRule schedule=new TaskRule();
        ActionParamModel actions=new ActionParamModel();
        schedule.setAppId("idb-shell-20190412-test");
        schedule.setAppName("IDB App Shell Test");
        schedule.setJobType(1);
        schedule.setProject("IDB Project");
        schedule.setEmailNotification(1);
        schedule.setRecipient("liujijun@zcreate.com.cn");
        schedule.setEmailTitle("my shell test");
        schedule.setParaId("[{\"key\": \"011\",\"value\": \"qxq\",\"desc\": \"0\"},{\"key\": \"011\",\"value\": \"qxq\",\"desc\": \"0\"}]");
        schedule.setEffetiveTime("2019-04-14T10:00+0800");
        schedule.setExpiryTime("2029-04-01T10:00+0800");
        schedule.setCroon("* 0/10 * * ?");

        actions.setActionId("shell-7h7s");
        actions.setActionName("Shell Coord Test");
        actions.setActionType("shell");
//        actions.setActionScene("dbreader-kafkawriter");
        actions.setNextAction("End");

        List<ActionParamModel> arr=new ArrayList<>();

        Map<String,String> paramMap=new HashMap<>();
        paramMap.put("Exec","/home/hdfs/apps/haha.sh");
        paramMap.put("InputFile","/home/hdfs/apps/haha.sh");
        actions.setParamMap(paramMap);

        arr.add(actions);
        taskParam.setAppId("idb-shell-20190412-test");
        taskParam.setAppName("IDB App Shell Test");
        taskParam.setStartAction("shell-7h7s");
        taskParam.setTaskRule(schedule);
        taskParam.setActionList(arr);

        return taskParam;
    }

    //测试java程序运行情况
    public TaskParamModel buildJavaModel(){
        TaskParamModel taskParam=new TaskParamModel();
        TaskRule schedule=new TaskRule();
        ActionParamModel actions=new ActionParamModel();
        schedule.setAppId("idb-java-20190415-test");
        schedule.setAppName("IDB Java Test");
        schedule.setJobType(0);
        schedule.setProject("IDB Java");
        schedule.setEmailNotification(0);

        actions.setActionId("java-9h8s");
        actions.setActionName("Java Test");
        actions.setActionType("java");
//        actions.setActionScene("dbreader-kafkawriter");
        actions.setNextAction("End");

        List<ActionParamModel> arr=new ArrayList<>();

        Map<String,String> paramMap=new HashMap<>();
        paramMap.put("Exec","/home/hdfs/apps/hadoop-examples.jar");
        paramMap.put("MainClass","org.apache.hadoop.examples.terasort.TeraGen");
        //每次测试记得改目录
        paramMap.put("Arguments","10000,output_dir/teragen_test");
        actions.setParamMap(paramMap);

        arr.add(actions);
        taskParam.setAppId("idb-java-20190415-test");
        taskParam.setAppName("IDB java Test");
        taskParam.setStartAction("java-9h8s");
        taskParam.setTaskRule(schedule);
        taskParam.setActionList(arr);
        return taskParam;

    }

    //构建sqoop测试用例
    public TaskParamModel buildSqoopModel(){
        TaskParamModel taskParam=new TaskParamModel();
        TaskRule schedule=new TaskRule();
        ActionParamModel actions=new ActionParamModel();
        schedule.setAppId("idb-sqoop-20190416-test");
        schedule.setAppName("IDB Sqoop Test");
        schedule.setJobType(0);
        schedule.setProject("IDB Sqoop");
        schedule.setEmailNotification(0);

        actions.setActionId("sqoop-0f4t");
        actions.setActionName("Sqoop Test");
        actions.setActionType("sqoop");
//        actions.setActionScene("dbreader-kafkawriter");
        actions.setNextAction("End");

        List<ActionParamModel> arr=new ArrayList<>();

        Map<String,String> paramMap=new HashMap<>();
        paramMap.put("Exec","import --connect jdbc:mysql://10.1.80.6:3306/oozie?characterEncoding=utf-8 --username root --password bigDataTeam --table t_job_rate_hour --num-mappers 1 --target-dir /home/hdfs/apps/job_rate --delete-target-dir --fields-terminated-by ',' ");
//        paramMap.put("InputFile","/home/hdfs/apps/1/shell.sh");
        actions.setParamMap(paramMap);

        arr.add(actions);
        taskParam.setAppId("idb-sqoop-20190416-test");
        taskParam.setAppName("IDB Sqoop Test");
        taskParam.setStartAction("sqoop-0f4t");
        taskParam.setTaskRule(schedule);
        taskParam.setActionList(arr);
        return taskParam;
    }



}
