package com.zcreator.bigdata.aggregation.ws;

import com.zcreator.bigdata.aggregation.ws.client.EntranceGuardService_ServiceLocator;
import com.zcreator.bigdata.aggregation.ws.client.ResponseResult;
import org.junit.Test;
import org.springframework.util.Assert;

/**
 * Copyright (C) 20016-2066 贵州易速云信息技术有限公司
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.ws
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/13
 * http://www.yisutech.com
 **/
public class TestEntranceGuardService_PortType {

    @Test
    public void testEntranceGuardStatus() {

        try {
            EntranceGuardService_ServiceLocator serviceServiceLocator = new EntranceGuardService_ServiceLocator();

            // String xtlb, String jkxlh, String jkid, String writeXmlDoc
            ResponseResult responseResult = serviceServiceLocator.getEntranceGuardImplPort().entranceGuardStatus("system", "system", "01", "kskkskks");
//            Assert.notNull(responseResult, "ResponseResult is null");

            System.out.println(responseResult.getMessage());

        } catch(Throwable e) {
            e.printStackTrace();
        }
    }

    @Test
    public void studentFace() {

    }

    @Test
    public void equipmentStatus() {

    }

}
