/**
 * EntranceGuardService_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zcreator.bigdata.aggregation.ws.client;

public interface EntranceGuardService_Service extends javax.xml.rpc.Service {
    public String getEntranceGuardImplPortAddress();

    public EntranceGuardService_PortType getEntranceGuardImplPort() throws javax.xml.rpc.ServiceException;

    public EntranceGuardService_PortType getEntranceGuardImplPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
