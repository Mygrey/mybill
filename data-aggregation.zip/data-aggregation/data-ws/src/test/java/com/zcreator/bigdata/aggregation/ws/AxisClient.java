package com.zcreator.bigdata.aggregation.ws;

/**
 * Copyright (C) 20016-2066 贵州易速云信息技术有限公司
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.ws
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/13
 * http://www.yisutech.com
 **/

import com.alibaba.fastjson.JSON;
import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;

import javax.xml.namespace.QName;

/**
 * @author created by Pjc
 * @version 1.0
 * @date 2017年7月18日
 * @problem
 * @answer
 * @action
 */
public class AxisClient {

    public static void main(String[] args) {
        axis();
    }

    //通过axis方式调用webservice接口
    public static void axis() {
        try {
            // 指出service所在完整的URL
            // com.zcreator.bigdata.aggregation.ws.demo.UserService
            String endpoint = "http://localhost:8000/soap/userService?wsdl";
            //调用接口的targetNamespace
            String targetNamespace = "http://demo.ws.aggregation.bigdata.zcreator.com/";

            //所调用接口的方法method
            String method = "getUser";

            // 创建一个服务(service)调用(call)
            Service service = new Service();
            Call call = (Call) service.createCall();// 通过service创建call对象

            // 设置service所在URL
            call.setTargetEndpointAddress(new java.net.URL(endpoint));
            call.setOperationName(new QName(targetNamespace, method));
            call.setUseSOAPAction(true);

            //变量最好只是用String类型，其他类型会报错
            String localPart = "userI";
            String methodTargetNamespace = "http://com.zcreator.bigdata.aggregation.ws.demo.UserService";
            call.addParameter(new QName(methodTargetNamespace, localPart), org.apache.axis.encoding.XMLType.XSD_STRING, javax.xml.rpc.ParameterMode.IN);//设置参数名 state  第二个参数表示String类型,第三个参数表示入参
            call.setReturnType(XMLType.XSD_STRING);// 设置返回类型

            // String path = targetNamespace + method;
            // call.setSOAPActionURI(path);
            Object jsonString = (Object) call.invoke(new Object[]{"411001"});//此处为数组，有几个变量传几个变量

            //将json字符串转换为JSON对象
            //将接送对象转为java对象,此处用object代替，用的时候转换为你需要是用的对象就行了
            System.out.println(JSON.toJSONString(jsonString));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
