/**
 * EntranceGuardService_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.zcreator.bigdata.aggregation.ws.client;

public interface EntranceGuardService_PortType extends java.rmi.Remote {
    public ResponseResult entranceGuardStatus(String arg0, String arg1, String arg2, String arg3) throws java.rmi.RemoteException;
    public ResponseResult studentFace(String arg0, String arg1, String arg2, String arg3) throws java.rmi.RemoteException;
    public ResponseResult equipmentStatus(String arg0, String arg1, String arg2, String arg3) throws java.rmi.RemoteException;
}
