package com.zcreator.bigdata.aggregation.ws;

import org.apache.axis.wsdl.Java2WSDL;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Unit test for simple App.
 */
public class AppTest {
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue() {
        assertTrue(true);
    }

    @Test
    public void generator() {

        // org.apache.axis.wsdl.Java2WSDL -oD:/workspace-java/axis1/src/test/wp.wsdl -nurn:test -ptest urn:test -lhttp://localhost:8080/axis/services/WidgetPrice test.WidgetPrice
        String[] args = new String[]{"-o/Users/guangzhong.wgz/IdeaProjects/data-aggregation/data-ws/demoService.wsdl",
                "-nurn:test",
                "-ptest",
                "urn:test",
                "-lhttp://localhost:8080/axis/services/WidgetPrice",
                "com.zcreator.bigdata.aggregation.ws.demo.DemoService"};
        Java2WSDL.main(args);

    }

    @Test
    public void generatorJava() {

        // org.apache.axis.wsdl.Java2WSDL -oD:/workspace-java/axis1/src/test/wp.wsdl -nurn:test -ptest urn:test -lhttp://localhost:8080/axis/services/WidgetPrice test.WidgetPrice
        String[] args = new String[]{};
        Java2WSDL.main(args);

    }
}
