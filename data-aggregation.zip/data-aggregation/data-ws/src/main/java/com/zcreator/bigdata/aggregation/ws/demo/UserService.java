package com.zcreator.bigdata.aggregation.ws.demo;

import com.zcreator.bigdata.aggregation.ws.demo.dto.User;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.ArrayList;

@WebService
public interface UserService {

    final String targetNamespace = "http://com.zcreator.bigdata.aggregation.ws.demo.UserService";

    @WebMethod
    String getName(@WebParam(name = "userId", targetNamespace = targetNamespace) String userId);

    @WebMethod

    User getUser(@WebParam(name = "userI", targetNamespace = targetNamespace) String userI);

    @WebMethod
    ArrayList<User> getAlLUser();
}