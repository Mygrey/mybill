package com.zcreator.bigdata.aggregation.ws.supervise;

import com.zcreator.bigdata.aggregation.ws.supervise.dto.ResponseResult;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * 门禁刷卡记录和门禁状态接口
 */
@WebService
public interface EntranceGuardService {

    /**
     * 提交门禁状态和考生通过门禁刷卡记录信息
     *
     * @param xtlb        系统类别	接口提供者的业务类别代码，默认为“17”
     * @param jkxlh       接口序列号	由服务平台授权生成下发
     * @param jkid        接口标识	5位，由系统类别＋一位级别代码＋两位接口顺序号组成，用于唯一表示一个接口。
     * @param writeXmlDoc 门禁状态和刷卡记录值
     */
    @WebMethod
    ResponseResult entranceGuardStatus(String xtlb, String jkxlh, String jkid, String writeXmlDoc);

    /**
     * 考试中抓拍人脸信息接口
     *
     * @param xtlb        系统类别	接口提供者的业务类别代码，默认为“17”
     * @param jkxlh       接口序列号	由服务平台授权生成下发
     * @param jkid        接口标识	5位，由系统类别＋一位级别代码＋两位接口顺序号组成，用于唯一表示一个接口。
     * @param writeXmlDoc 考生人脸信息
     */
    @WebMethod
    ResponseResult studentFace(String xtlb, String jkxlh, String jkid, String writeXmlDoc);

    /**
     * 防作弊设备状态接口
     *
     * @param xtlb        系统类别	接口提供者的业务类别代码，默认为“17”
     * @param jkxlh       接口序列号	由服务平台授权生成下发
     * @param jkid        接口标识	5位，由系统类别＋一位级别代码＋两位接口顺序号组成，用于唯一表示一个接口。
     * @param writeXmlDoc 设备状态信息值
     */
    @WebMethod
    ResponseResult equipmentStatus(String xtlb, String jkxlh, String jkid, String writeXmlDoc);
}

