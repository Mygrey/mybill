package com.zcreator.bigdata.aggregation.ws.supervise.impl;

import com.zcreator.bigdata.aggregation.ws.supervise.EntranceGuardService;
import com.zcreator.bigdata.aggregation.ws.supervise.dto.ResponseResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.jws.WebService;

/**
 * @ClassName: EntranceGuardImpl
 * @Author: majun
 * @CreateDate: 2018/11/9 13:30
 * @Version: 1.0
 * @Description: 门禁状态和考生刷卡记录接口实现类
 */

@Component
@WebService(serviceName = "EntranceGuardService",
        targetNamespace = "http://service.bigdata.zcreator.com/",
        endpointInterface = "com.zcreator.bigdata.aggregation.ws.supervise.EntranceGuardService")
public class EntranceGuardImpl implements EntranceGuardService {

   private static Logger LOG = LoggerFactory.getLogger("mengjing_log");

    @Override
    public ResponseResult entranceGuardStatus(String xtlb, String jkxlh, String jkid, String writeXmlDoc) {

        LOG.info("门禁状态和刷卡记录：" + writeXmlDoc);
        return new ResponseResult("200", "操作成功");
    }

    @Override
    public ResponseResult studentFace(String xtlb, String jkxlh, String jkid, String writeXmlDoc) {
        LOG.info("考试抓拍人脸信息：" + writeXmlDoc);
        return new ResponseResult("200", "操作成功");
    }

    @Override
    public ResponseResult equipmentStatus(String xtlb, String jkxlh, String jkid, String writeXmlDoc) {
        LOG.info("防作弊设备：" + writeXmlDoc);
        return new ResponseResult("200", "操作成功");
    }
}
