package com.zcreator.bigdata.aggregation.ws.supervise.dto;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * @ClassName: ResponseResult
 * @Author: majun
 * @CreateDate: 2018/11/9 14:13
 * @Version: 1.0
 * @Description: 接口调用返回结果类
 */

public class ResponseResult {

    private String statusCode;
    private String message;

    public ResponseResult() {
    }

    public ResponseResult(String statusCode, String message) {
        this.statusCode = statusCode;
        this.message = message;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
