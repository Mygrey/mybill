package com.zcreator.bigdata.aggregation.ws.config;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class WebConfig {

    @Bean
    public FilterRegistrationBean getCommonFilter() {

        CommonFilter commonFilter = new CommonFilter();
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();

        registrationBean.setFilter(commonFilter);

        List<String> urlPatterns = new ArrayList<>();
        urlPatterns.add("/*");
        registrationBean.setUrlPatterns(urlPatterns);
        registrationBean.setOrder(1);

        return registrationBean;
    }
}


