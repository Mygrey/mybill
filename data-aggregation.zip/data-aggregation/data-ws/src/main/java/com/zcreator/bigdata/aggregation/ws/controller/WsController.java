package com.zcreator.bigdata.aggregation.ws.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Copyright
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.ws.controller
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/9
 * http://www.yisutech.com
 **/
@Controller
@RequestMapping("/ws")
public class WsController {

    @RequestMapping("/getMessage")
    @ResponseBody
    public String getMessage() {
        return "Hellow World!";
    }

}
