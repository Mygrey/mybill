package com.zcreator.bigdata.aggregation.ws.config;

import com.zcreator.bigdata.aggregation.ws.demo.UserService;
import com.zcreator.bigdata.aggregation.ws.supervise.EntranceGuardService;
import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.xml.ws.Endpoint;

@Configuration
public class SoapConfig {

    @Autowired
    private UserService userService;

    @Autowired
    private EntranceGuardService entranceGuardService;

    @Autowired
    @Qualifier(Bus.DEFAULT_BUS_ID)
    private SpringBus bus;

    @Bean
    public Endpoint endpoint() {
        EndpointImpl endpoint = new EndpointImpl(bus, userService);
        endpoint.publish("/userService");
        return endpoint;
    }

    @Bean
    public Endpoint endpointForentranceGuardService() {
        EndpointImpl endpoint = new EndpointImpl(bus, entranceGuardService);
        endpoint.publish("/entranceGuardService");
        return endpoint;
    }
}