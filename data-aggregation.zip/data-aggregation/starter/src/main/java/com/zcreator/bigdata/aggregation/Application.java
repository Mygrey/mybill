package com.zcreator.bigdata.aggregation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootConfiguration
@EnableAutoConfiguration
@ServletComponentScan
@ComponentScan(value = {"com.zcreator.bigdata.aggregation"})
public class Application {

    public static void main(String args[]) {
        SpringApplication.run(Application.class, args);
    }
}
