package com.zcreator.bigdata.aggregation.hbase;

import com.zcreator.bigdata.aggregation.hbase.config.HbaseConfig;
import com.zcreator.bigdata.aggregation.hbase.impl.HbaseManagerOpsImpl;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Copyright (C) 20016-2066 贵州易速云信息技术有限公司
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hbase
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/15
 * http://www.yisutech.com
 **/
public class HbaseManagerOpsTest {

    @Test
    public void createTable() {

    }


    @Test
    public void truncateTable() {

    }

    @Test
    public void deleteTable() {

    }

    @Test
    public void listTables() {

        HbaseConfig hbaseConfig = new HbaseConfig();
        hbaseConfig.setHbaseZkQuorum("cdh1,cdh3,cdh8,cdh6,cdh7");
        hbaseConfig.setHbaseZkClientPort("2181");
        HbaseManagerOps hbaseManagerOps = new HbaseManagerOpsImpl(hbaseConfig);

        List<String> tables = hbaseManagerOps.listTables();

        assertNotNull(tables);
    }
}