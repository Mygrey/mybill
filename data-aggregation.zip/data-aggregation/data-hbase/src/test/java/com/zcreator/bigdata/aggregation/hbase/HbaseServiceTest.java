package com.zcreator.bigdata.aggregation.hbase;

import com.alibaba.fastjson.JSON;
import com.zcreator.bigdata.aggregation.hbase.config.HbaseConfig;
import com.zcreator.bigdata.aggregation.hbase.impl.HbaseServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Copyright (C) 20016-2066 贵州易速云信息技术有限公司
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hbase
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/15
 * http://www.yisutech.com
 **/
public class HbaseServiceTest {

    private static Logger LOG = LoggerFactory.getLogger(HbaseServiceTest.class);

    HbaseConfig hbaseConfig = new HbaseConfig();

    @Before
    public void init() {
        hbaseConfig.setHbaseZkQuorum("cdh1,cdh3,cdh8,cdh6,cdh7");
        hbaseConfig.setHbaseZkClientPort("2181");
    }

    @Test
    public void queryByRowKeyFamily() {

        HbaseService hbaseService = new HbaseServiceImpl(hbaseConfig);

        String tableName = "vehicle";
        List<Map<String, Object>> result = hbaseService.findByRowRange(tableName, 0);

        System.out.println(JSON.toJSONString(result));
        assertNotNull(result);

        Map<String, Object> obj = hbaseService.queryByRowKey("2000", tableName);
        System.out.println(JSON.toJSONString(obj));
        assertNotNull(obj);
    }

    @Test
    public void findByRowRange() {

        HbaseService hbaseService = new HbaseServiceImpl(hbaseConfig);

        String tableName = "vehicle";
        List<Map<String, Object>> result = hbaseService.findByRowRange(tableName, "200", "300");

        System.out.println(JSON.toJSONString(result));
        assertNotNull(result);
    }

    @Test
    public void queryAll() {
        queryByRowKeyFamily();
        findByRowRange();
    }
}