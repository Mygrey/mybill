package com.zcreator.bigdata.aggregation.hbase;

import com.google.common.collect.Lists;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * Unit test for simple App.
 */
public class AppTest {
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue() {
        List<String> str = Lists.newArrayList();
        assertTrue(str.size() == 0);
        assertTrue(true);
    }
}
