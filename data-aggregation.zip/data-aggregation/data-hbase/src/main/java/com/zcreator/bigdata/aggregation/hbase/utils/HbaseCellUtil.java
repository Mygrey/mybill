package com.zcreator.bigdata.aggregation.hbase.utils;

import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;

/**
 * Copyright
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hbase.utils
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/15
 **/
public class HbaseCellUtil {

    public static String getCellFamily(Cell cell) {
        return new String(CellUtil.cloneFamily(cell));
    }

    public static String getCellQualifier(Cell cell) {
        return new String(CellUtil.cloneQualifier(cell));
    }

    public static String getCellValue(Cell cell) {
        return new String(CellUtil.cloneValue(cell));
    }

    public static String getCellRow(Cell cell) {
        return new String(CellUtil.cloneRow(cell));
    }

    public static String getCellFQ(Cell cell) {
        return getCellFamily(cell) + "_" + getCellQualifier(cell);
    }
}
