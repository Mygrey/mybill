package com.zcreator.bigdata.aggregation.hbase;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hbase
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
public interface HbaseService {

    /**
     * 根据rowKey查询信息
     *
     * @param tableName 表名
     * @param rowKey    rowKey
     * @param families  字段列表
     * @return {@link Map<String, Object>}
     */
    Map<String, Object> queryByRowKeyFamily(String tableName, String rowKey, List<String> families);

    /**
     * 查询开始row和结束row之间的数据
     *
     * @param tableName   表名
     * @param startRowKey 开始row
     * @param endRowKey   结束row
     * @return {@link List<Map<String, Object>>}
     */
    List<Map<String, Object>> findByRowRange(String tableName, String startRowKey, String endRowKey);

    /**
     * 根据正则表达式匹配rowKey
     *
     * @param tableName 表名
     * @param families  聚簇列表
     * @param regex
     * @param size
     * @return
     */
    List<Map<String, Object>> findByRowRangeByRegex(String tableName, List<String> families, String regex, int size);

    /**
     * 查询指定条记录数
     *
     * @param tableName 表名
     * @param size      开始row
     * @return {@link List<Map<String, Object>>}
     */
    List<Map<String, Object>> findByRowRange(String tableName, int size);

    /**
     * 根据rowKey查询包含字符串的记录
     *
     * @param tableName 表名
     * @param size      开始row
     * @return {@link List<Map<String, Object>>}
     */
    /**
     * 根据rowKey查询包含字符串的记录
     *
     * @param tableName 表名
     * @param families  聚簇列表
     * @param inString  rowKey包含字符串
     * @param size      指定记录数
     * @return {@link List<Map<String, Object>>}
     */
    List<Map<String, Object>> findByRowRange(String tableName, List<String> families, String inString, int size);

    /**
     * 插入单行单列簇单列修饰符数据
     *
     * @param tableName
     * @param rowKey
     * @param family
     * @param col
     * @param val
     */
    void addOneRecord(String tableName, String rowKey, String family, String col, String val);

    /**
     * 删除指定行
     *
     * @param rowKey
     * @param tableName
     */
    void deleteRow(String rowKey, String tableName);

    /**
     * 根据rowkey查询单行
     *
     * @param rowKey
     * @param tableName
     */
    Map<String, Object> queryByRowKey(String rowKey, String tableName);

    /**
     * 根据 condition 查询信息
     *
     * @param tableName
     * @param familyName
     * @param columns
     * @param condition
     * @return {@link List<Map<String, Object>>}
     */
    List<Map<String, Object>> queryColumns(String tableName, String familyName, List<String> columns, String condition);

    /**
     * 删除列
     *
     * @param tableName
     * @param rowKey
     * @param family
     * @param qualifier
     * @throws IOException
     */
    void deleteColumn(String tableName, String rowKey, byte[] family, byte[] qualifier) throws IOException;

    /**
     * 关闭连接
     */
    void destroy();
}
