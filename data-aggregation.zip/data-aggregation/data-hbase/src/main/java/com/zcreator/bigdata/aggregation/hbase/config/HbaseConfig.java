package com.zcreator.bigdata.aggregation.hbase.config;

import lombok.Data;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hbase.config
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
@Data
public class HbaseConfig {

    /**
     * Hbase zk集群
     * <p>
     * ex:
     * 192.168.1.95, 192.168.1.96
     */
    private String hbaseZkQuorum;

    public void setHbaseZkQuorum(String hbaseZkQuorum) {
        this.hbaseZkQuorum = hbaseZkQuorum;
    }

    public void setHbaseZkClientPort(String hbaseZkClientPort) {
        this.hbaseZkClientPort = hbaseZkClientPort;
    }

    /**
     * Hbase Thrift 端口
     */
    private String hbaseZkClientPort;

    private Object lock = new Object();

    public Connection getConnection() {

        try {
            synchronized (lock) {
                Configuration config = HBaseConfiguration.create();
                config.set("hbase.zookeeper.quorum", this.hbaseZkQuorum);
                config.set("hbase.zookeeper.property.clientPort", this.hbaseZkClientPort);
                return ConnectionFactory.createConnection(config);
            }

        } catch (Throwable e) {
            e.printStackTrace();
        }
        return null;
    }
}
