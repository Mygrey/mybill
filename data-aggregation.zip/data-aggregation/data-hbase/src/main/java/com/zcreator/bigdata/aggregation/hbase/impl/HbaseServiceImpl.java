package com.zcreator.bigdata.aggregation.hbase.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.zcreator.bigdata.aggregation.hbase.HbaseService;
import com.zcreator.bigdata.aggregation.hbase.config.HbaseConfig;
import com.zcreator.bigdata.aggregation.hbase.utils.HbaseCellUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.filter.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hbase.impl
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
public class HbaseServiceImpl implements HbaseService {

    /**
     * hbase配置
     */
    private HbaseConfig hbaseConfig;
    /**
     * 连接
     */
    private Connection connection;

    private static Logger LOG = LoggerFactory.getLogger(HbaseServiceImpl.class);

    public HbaseServiceImpl() {
    }

    public HbaseServiceImpl(HbaseConfig hbaseConfig) {
        this.hbaseConfig = hbaseConfig;
    }

    /**
     * 删除列
     *
     * @param tableName
     * @param rowKey
     * @param family
     * @param qualifier
     * @throws IOException
     */
    public void deleteColumn(String tableName, String rowKey, byte[] family, byte[] qualifier) throws IOException {
        HTable table = (HTable) getConnection().getTable(TableName.valueOf(tableName));
        Delete delete = new Delete(Bytes.toBytes(rowKey));
        // 删除指定列
        delete.addColumn(family, qualifier);
        table.delete(delete);
    }

    public List<Map<String, Object>> queryColumns(String tableName, String family, List<String> columns, String condition) {

        List<Map<String, Object>> resultMaps = Lists.newArrayList();

        try {
            // 获取hbase表
            Table table = getConnection().getTable(TableName.valueOf(tableName));

            // 建立过滤扫描器
            Scan scan = new Scan();

            //设置缓存
            scan.setCacheBlocks(true);

            if (columns != null && columns.size() > 0) {
                columns.forEach(column -> {
                    scan.addColumn(Bytes.toBytes(family), Bytes.toBytes(column));
                });
            }

            // 根据条件过滤
            Filter filter = new RowFilter(CompareFilter.CompareOp.LESS_OR_EQUAL, new BinaryComparator(Bytes.toBytes(condition)));
            scan.setFilter(filter);

            ResultScanner resultScanner = table.getScanner(scan);
            while (resultScanner.iterator().hasNext()) {

                Map<String, Object> objectMap = Maps.newHashMap();

                Result rs = resultScanner.iterator().next();
                for (Cell cell : rs.listCells()) {
                    objectMap.put(new String(cell.getFamilyArray()), new String(cell.getValueArray()));
                }

                resultMaps.add(objectMap);
            }

        } catch (
                Throwable e) {
            throw new RuntimeException(e);
        }
        return resultMaps;
    }

    public Map<String, Object> queryByRowKeyFamily(String tableName, String rowKey, List<String> families) {

        Map<String, Object> objectMap = Maps.newHashMap();

        try {
            // 获取hbase表
            Table table = getConnection().getTable(TableName.valueOf(tableName));

            Get get = new Get(rowKey.getBytes());
            if (families != null && families.size() > 0) {
                families.forEach(family -> {
                    get.addFamily(Bytes.toBytes(family));
                });
            }

            Result rs = table.get(get);
            for (Cell cell : rs.listCells()) {
                objectMap.put(new String(cell.getFamilyArray()), new String(cell.getValueArray()));
            }

            return objectMap;

        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public List<Map<String, Object>> findByRowRange(String tableName, String startRow, String endRow) {

        List<Map<String, Object>> objectMaps = Lists.newArrayList();

        try {
            // 获取hbase表
            Table table = getConnection().getTable(TableName.valueOf(tableName));

            Scan scan = new Scan();

            //设置缓存
            scan.setCacheBlocks(true);

            // 设置范围查询
            if (StringUtils.isNotBlank(startRow) && StringUtils.isNotBlank(endRow)) {
                scan.setStartRow(startRow.getBytes());
                scan.setStopRow(endRow.getBytes());
            }

            ResultScanner resultScanner = table.getScanner(scan);
            while (resultScanner.iterator().hasNext()) {

                Map<String, Object> objectMap = Maps.newHashMap();

                Result rs = resultScanner.iterator().next();
                for (Cell cell : rs.listCells()) {
                    objectMap.put(HbaseCellUtil.getCellFQ(cell), HbaseCellUtil.getCellValue(cell));
                }

                objectMaps.add(objectMap);
            }

            return objectMaps;

        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Map<String, Object>> findByRowRange(String tableName, int size) {

        HTable hTable = null;
        ResultScanner resultScanner = null;
        List<Map<String, Object>> resultList = Lists.newArrayList();

        try {
            hTable = (HTable) getConnection().getTable(TableName.valueOf(tableName));

            // 设置查询记录数
            if (size <= 0) {
                size = 10;
            }

            FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ALL);

            PageFilter pageFilter = new PageFilter(size);
            filterList.addFilter(pageFilter);

            Scan scan = new Scan();

            //设置缓存
            scan.setCacheBlocks(true);
            scan.setFilter(filterList);

            resultScanner = hTable.getScanner(scan);
            Iterator<Result> iterator = resultScanner.iterator();

            int rowCount = 0;
            while (iterator.hasNext()) {

                //按cell进行循环
                Map<String, Object> objectMap = Maps.newHashMap();

                Result result = iterator.next();
                result.listCells().forEach(cell -> {
                    objectMap.put(HbaseCellUtil.getCellFQ(cell), HbaseCellUtil.getCellValue(cell));
                });

                resultList.add(objectMap);

                rowCount++;
                if (rowCount >= size) {  //退出读取表数据的条件
                    break;
                }

            }

            return resultList;

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            if (resultScanner != null) {
                resultScanner.close();
            }
            if (hTable != null) {
                try {
                    hTable.close();
                } catch (IOException e) {
                    LOG.error("hTable.close error", e);
                }
            }
        }
    }

    @Override
    public List<Map<String, Object>> findByRowRange(String tableName, List<String> families, String inString, int size) {

        HTable hTable = null;
        ResultScanner resultScanner = null;
        List<Map<String, Object>> resultList = Lists.newArrayList();

        try {
            hTable = (HTable) getConnection().getTable(TableName.valueOf(tableName));

            // 设置查询记录数
            if (size <= 0) {
                size = 10;
            }

            FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ALL);

            // regionServer记录数据限制
            PageFilter pageFilter = new PageFilter(size);
            filterList.addFilter(pageFilter);

            // rowkey包含字串
            RowFilter rowFilter = new RowFilter(CompareFilter.CompareOp.EQUAL, new SubstringComparator(inString));
            filterList.addFilter(rowFilter);

            Scan scan = new Scan();

            //设置缓存
            scan.setCacheBlocks(true);
            scan.setFilter(filterList);

            resultScanner = hTable.getScanner(scan);
            Iterator<Result> iterator = resultScanner.iterator();

            int rowCount = 0;
            while (iterator.hasNext()) {

                //按cell进行循环
                Map<String, Object> objectMap = Maps.newHashMap();

                Result result = iterator.next();
                result.listCells().forEach(cell -> {
                    objectMap.put(HbaseCellUtil.getCellFQ(cell), HbaseCellUtil.getCellValue(cell));
                });

                resultList.add(objectMap);

                rowCount++;
                if (rowCount >= size) {  //退出读取表数据的条件
                    break;
                }

            }

            return resultList;

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            if (resultScanner != null) {
                resultScanner.close();
            }
            if (hTable != null) {
                try {
                    hTable.close();
                } catch (IOException e) {
                    LOG.error("hTable.close error", e);
                }
            }
        }
    }

    @Override
    public List<Map<String, Object>> findByRowRangeByRegex(String tableName, List<String> families, String regex, int size) {

        HTable hTable = null;
        ResultScanner resultScanner = null;
        List<Map<String, Object>> resultList = Lists.newArrayList();

        try {
            hTable = (HTable) getConnection().getTable(TableName.valueOf(tableName));

            // 设置查询记录数
            if (size <= 0) {
                size = 10;
            }

            FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ALL);

            // regionServer记录数据限制
            PageFilter pageFilter = new PageFilter(size);
            filterList.addFilter(pageFilter);

            // rowkey包含字串
            RowFilter rowFilter = new RowFilter(CompareFilter.CompareOp.EQUAL, new RegexStringComparator(regex));
            filterList.addFilter(rowFilter);

            Scan scan = new Scan();

            //设置缓存
            scan.setCacheBlocks(true);
            scan.setFilter(filterList);

            resultScanner = hTable.getScanner(scan);
            Iterator<Result> iterator = resultScanner.iterator();

            int rowCount = 0;
            while (iterator.hasNext()) {

                //按cell进行循环
                Map<String, Object> objectMap = Maps.newHashMap();

                Result result = iterator.next();
                result.listCells().forEach(cell -> {
                    objectMap.put(HbaseCellUtil.getCellFQ(cell), HbaseCellUtil.getCellValue(cell));
                });

                resultList.add(objectMap);

                rowCount++;
                if (rowCount >= size) {  //退出读取表数据的条件
                    break;
                }

            }

            return resultList;

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            if (resultScanner != null) {
                resultScanner.close();
            }
            if (hTable != null) {
                try {
                    hTable.close();
                } catch (IOException e) {
                    LOG.error("hTable.close error", e);
                }
            }
        }
    }

    /**
     * 插入单行单列簇单列修饰符数据
     *
     * @param tableName
     * @param key
     * @param family
     * @param col
     * @param val
     */
    public void addOneRecord(String tableName, String key, String family, String col, String val) {

        HTable hTable = null;

        try {

            hTable = (HTable) getConnection().getTable(TableName.valueOf(tableName));

            Put p = new Put(Bytes.toBytes(key));
            p.addColumn(Bytes.toBytes(family), Bytes.toBytes(col), Bytes.toBytes(val));

            if (p.isEmpty()) {
                throw new RuntimeException("data error");

            } else {
                hTable.put(p);

            }

        } catch (IOException e) {
            throw new RuntimeException(e);

        } finally {
            if (hTable != null) {
                try {
                    hTable.close();
                } catch (IOException e) {
                    LOG.error("hTable.close error", e);
                }
            }
        }
    }

    /**
     *  插入单行单列簇多列修饰符数据
     *
     * <p>
     *
     * @param tableName
     * @param key        
     * @param family
     * @param colVal    Map集合（列名:列值）
     */
    public void addMoreRecord(String tableName, String key, String family, Map<String, String> colVal) {

        HTable hTable = null;

        try {

            hTable = (HTable) getConnection().getTable(TableName.valueOf(tableName));

            Put p = new Put(Bytes.toBytes(key));
            for (String col : colVal.keySet()) {

                String val = colVal.get(col);
                if (StringUtils.isNotBlank(val)) {
                    p.addColumn(Bytes.toBytes(family), Bytes.toBytes(col), Bytes.toBytes(val));
                }
            }

            // 当put对象没有成功插入数据时，此时调用hTable.put(p)方法会报错：java.lang.IllegalArgumentException:No columns to insert
            if (p.isEmpty()) {
                throw new RuntimeException("data error");

            } else {
                hTable.put(p);
            }
        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            if (hTable != null) {
                try {
                    hTable.close();
                } catch (IOException e) {
                    LOG.error("hTable.close", e);
                }
            }
        }
    }

    /**
     * 删除指定行
     *
     * @param key
     * @param tableName
     */
    public void deleteRow(String key, String tableName) {

        HTable hTable = null;

        try {
            hTable = (HTable) getConnection().getTable(TableName.valueOf(tableName));
            hTable.delete(new Delete(Bytes.toBytes(key)));

        } catch (IOException e) {
            throw new RuntimeException(e);

        } finally {
            if (hTable != null) {
                try {
                    hTable.close();
                } catch (IOException e) {
                    LOG.error("hTable.close error", e);
                }
            }
        }
    }

    @Override
    public Map<String, Object> queryByRowKey(String key, String tableName) {

        HTable hTable = null;
        Map<String, Object> resultMap = Maps.newHashMap();

        try {
            hTable = (HTable) getConnection().getTable(TableName.valueOf(tableName));
            Result rs = hTable.get(new Get(Bytes.toBytes(key)));

            for (Cell cell : rs.rawCells()) {
                resultMap.put(HbaseCellUtil.getCellFQ(cell), HbaseCellUtil.getCellValue(cell));
            }

            return resultMap;

        } catch (IOException e) {
            throw new RuntimeException(e);

        } finally {
            if (hTable != null) {
                try {
                    hTable.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //关闭连接
    public void destroy() {
        if (connection != null) {
            try {
                connection.close();

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * 获得链接
     *
     * @return
     */
    private synchronized Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = hbaseConfig.getConnection();
            }
        } catch (Throwable e) {
            LOG.error("HBase 建立链接失败 ", e);
        }
        return connection;

    }

}
