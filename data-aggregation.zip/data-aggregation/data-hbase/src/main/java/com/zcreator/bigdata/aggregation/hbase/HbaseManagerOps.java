package com.zcreator.bigdata.aggregation.hbase;

import org.apache.hadoop.hbase.filter.SingleColumnValueFilter;

import java.util.List;

/**
 * Copyright
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hbase
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
public interface HbaseManagerOps {

    /**
     * 在HBase上面创建表
     *
     * @param tableName 表名
     * @param families  列族名(可以同时传入多个列族名)
     * @return
     */
    boolean createTable(String tableName, List<String> families);

    /**
     * 修改表结构-替换该表的所有列，相当于重建表
     *
     * @param tableName
     * @param family
     * @param key
     * @param value
     * @throws Exception
     */
    void modifyTableAddFamily(String tableName, String family, String key, String value);

    /**
     * @param tableName
     * @param family
     */
    void addFamily(String tableName, String family);

    /**
     * 删除指定名称的列簇
     *
     * @param family
     * @param tableName
     */
    public void deleteFamily(String family, String tableName);

    /**
     * @param tableName
     * @return
     */
    boolean truncateTable(String tableName);

    /**
     * 删除表
     *
     * @param tableName
     * @return
     */
    boolean deleteTable(String tableName);

    /**
     * @return
     */
    List<String> listTables();
}
