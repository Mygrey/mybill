package com.zcreator.bigdata.aggregation.hbase.impl;

import com.google.common.collect.Lists;
import com.zcreator.bigdata.aggregation.hbase.HbaseManagerOps;
import com.zcreator.bigdata.aggregation.hbase.config.HbaseConfig;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;
import java.util.stream.Stream;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hbase.impl
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
public class HbaseManagerOpsImpl implements HbaseManagerOps {

    /**
     * hbase管理接口
     */
    private Connection connection;
    /**
     * hbase配置
     */
    private HbaseConfig hbaseConfig;

    private static Logger LOG = LoggerFactory.getLogger(HbaseManagerOpsImpl.class);

    public HbaseManagerOpsImpl() {
    }

    public HbaseManagerOpsImpl(HbaseConfig hbaseConfig) {

        try {

            this.hbaseConfig = hbaseConfig;

        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean createTable(String tableName, List<String> families) {
        try {

            TableName opTable = TableName.valueOf(tableName);

            if (getAdmin().tableExists(opTable)) {// 如果存在要创建的表，那么先删除，再创建
                getAdmin().disableTable(opTable);
                getAdmin().deleteTable(opTable);
            }

            HTableDescriptor tableDescriptor = new HTableDescriptor(opTable);// 代表表的 schema
            for (String familyName : families) {
                tableDescriptor.addFamily(new HColumnDescriptor(familyName));
            }

            getAdmin().createTable(tableDescriptor);

            return true;

        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 修改表结构-替换该表的所有列，相当于重建表
     *
     * @param tableName
     * @param family
     * @param key
     * @param value
     * @throws Exception
     */
    public void modifyTableAddFamily(String tableName, String family, String key, String value) {

        if (StringUtils.isEmpty(tableName) || StringUtils.isEmpty(family) || StringUtils.isEmpty(key)) {
            return;
        }
        try {
            TableName tbName = TableName.valueOf(tableName);

            HTableDescriptor desc = new HTableDescriptor(tbName);
            desc.addFamily(new HColumnDescriptor(family));
            desc.setValue(key, value);

            // 要先disable
            getAdmin().disableTable(tbName);
            getAdmin().modifyTable(tbName, desc);

            // 再enable
            getAdmin().enableTable(tbName);
            getAdmin().close();

        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public void addFamily(String tableName, String family) {

        try {

            HColumnDescriptor columnDesc = new HColumnDescriptor(family);
            getAdmin().addColumn(TableName.valueOf(tableName), columnDesc);

        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 删除指定名称的列簇
     *
     * @param family
     * @param tableName
     */
    public void deleteFamily(String family, String tableName) {
        try {
            getAdmin().deleteColumn(TableName.valueOf(tableName), Bytes.toBytes(family));
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public boolean deleteTable(String tableName) {
        try {

            TableName opTable = TableName.valueOf(tableName);

            if (!getAdmin().tableExists(opTable)) {// 如果存在要创建的表，那么先删除，再创建
                return true;
            }

            getAdmin().disableTable(opTable);
            getAdmin().deleteTable(opTable);

            return true;

        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }


    public boolean truncateTable(String tableName) {
        try {

            TableName opTable = TableName.valueOf(tableName);

            if (!getAdmin().tableExists(opTable)) {// 如果存在要创建的表，那么先删除，再创建
                return true;
            }

            getAdmin().truncateTable(opTable, true);

            return true;

        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public List<String> listTables() {

        List<String> tableNames = Lists.newArrayList();

        try {
            TableName[] tbNames = getAdmin().listTableNames();

            Stream.of(tbNames).forEach(tabName -> {
                tableNames.add(tabName.getNameAsString());
            });

            return tableNames;

        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    //关闭连接
    public void destroy() {
        try {
            if (connection.getAdmin() != null) {
                try {
                    connection.getAdmin().close();
                } catch (IOException e) {
                    LOG.error("destroy error", e);
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (IOException e) {
                    LOG.error("destroy error", e);
                }
            }
        } catch (Throwable e) {
            LOG.error("destroy error", e);
        }

    }

    /**
     * 获得链接
     *
     * @return
     */
    private synchronized Admin getAdmin() throws Throwable {
        try {
            if (connection == null || connection.isClosed()) {
                connection = hbaseConfig.getConnection();
            }
        } catch (Throwable e) {
            LOG.error("HBase 建立链接失败 ", e);
        }
        return connection.getAdmin();

    }
}
