package com.zcreator.bigdata.aggregation.hdfs;

import com.google.common.collect.Lists;
import com.zcreator.bigdata.aggregation.hdfs.impl.HdfsBusiOpsImpl;
import com.zcreator.bigdata.aggregation.hdfs.utils.HadoopClient;
import org.junit.Before;
import org.junit.Test;
import org.springframework.util.Assert;

import java.util.List;

/**
 * Copyright (C) 20016-2066 贵州易速云信息技术有限公司
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hdfs
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/13
 * http://www.yisutech.com
 **/
public class HdfsBusiOpsTest {

    HadoopClient client = null;
    HdfsBusiOps hdfsBusiOps = new HdfsBusiOpsImpl();

    @Before
    public void init() {
        client = new HadoopClient();
        client.setDefaultFS("hdfs://cdh2:8020");
        client.setUserName("hdfs");
        client.init();
    }

    @Test
    public void getAllNodeName() {
        try {

            List<String> nodesName = hdfsBusiOps.getAllNodeName(client.getConf());
            Assert.notNull(nodesName, "nodesName is null");

            nodesName.forEach(name -> {
                System.out.println(name);
            });

        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    @Test
    public void getFileModifyTime() {
    }

    @Test
    public void appendHdfs() {
        // Configuration conf, List<String> line, String partitionPath, String fileDate, String filePrefix

        try {

            List<String> lines = Lists.newArrayList();

            lines.add("01|test001|test002|test003|test004|test005");
            lines.add("02|test001|test002|test003|test004|test005");
            lines.add("03|test001|test002|test003|test004|test005");
            lines.add("04|test002|test002|test003|test004|test005");

            String partitionPath = "/test/";
            String fileDate = "20181116";
            String filePrefix = "test_log";

            hdfsBusiOps.appendHdfs(client.getConf(), lines, partitionPath, fileDate, filePrefix);

        } catch (Throwable e) {
            e.printStackTrace();
        }
    }
}