package com.zcreator.bigdata.aggregation.hdfs;

import com.zcreator.bigdata.aggregation.hdfs.impl.HdfsOpsImpl;
import com.zcreator.bigdata.aggregation.hdfs.utils.HadoopClient;
import org.junit.Test;
import org.springframework.util.Assert;

import java.util.List;

/**
 * Copyright (C) 20016-2066 贵州易速云信息技术有限公司
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hdfs
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/13
 * http://www.yisutech.com
 **/
public class HdfsOpsTest {

    @Test
    public void getFileList() {

        HadoopClient client = new HadoopClient();
        client.setDefaultFS("hdfs://cdh2:8020");
        client.setUserName("hdfs");
        client.init();

        try {

            HdfsOps hdfsOps = new HdfsOpsImpl(client);

            List<String> nodesName = hdfsOps.getFileList("/user/admin");
            Assert.notNull(nodesName, "nodesName is null");

            nodesName.forEach(name -> {
                System.out.println(name);
            });

        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testClearHdfs() throws Throwable{
        HadoopClient hadoopClient = new HadoopClient();
        hadoopClient.setDefaultFS("hdfs://10.1.80.5:8020");
        HdfsOps hdfsOps = new HdfsOpsImpl(hadoopClient);
        hdfsOps.removeDir("/user/root/test");
    }
}