package com.zcreator.bigdata.aggregation.hdfs.impl;

import com.zcreator.bigdata.aggregation.hdfs.HdfsOps;
import com.zcreator.bigdata.aggregation.hdfs.utils.HadoopClient;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.yarn.webapp.hamlet.Hamlet;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hdfs.impl
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/13
 **/
public class HdfsOpsImpl implements HdfsOps {

    /**
     * hadoopClient 工具包
     */
    private HadoopClient hadoopClient;

    private static Logger LOG = LoggerFactory.getLogger(HdfsOpsImpl.class);

    /**
     *
     */
    HdfsOpsImpl() {
    }

    /**
     * @param hadoopClient hadoop 资源库， 如: hdfs://hello110:9000/
     */
    public HdfsOpsImpl(HadoopClient hadoopClient) {
        this.hadoopClient = hadoopClient;
        this.hadoopClient.init();
    }

    /**
     * 获取hdfs路径下的文件列表
     *
     * @param srcpath
     * @return
     */
    public List<String> getFileList(String srcpath) throws Throwable {

        FileSystem fs = null;
        List<String> files = new ArrayList<>();

        try {
            Path path = new Path(srcpath);
            fs = path.getFileSystem(hadoopClient.getConf());

            if (fs.exists(path) && fs.isDirectory(path)) {
                for (FileStatus status : fs.listStatus(path)) {
                    files.add(status.getPath().toString());
                }
            }

        } finally {
            if (fs != null) {
                try {
                    fs.close();
                } catch (Throwable e) {
                }
            }
        }

        return files;
    }


    /**
     * 给定文件名和文件内容，创建hdfs文件
     *
     * @param dst
     * @param contents
     * @throws IOException
     */
    public boolean createFile(String dst, byte[] contents) throws Throwable {

        FileSystem fs = null;
        FSDataOutputStream outputStream = null;

        try {
            Path dstPath = new Path(dst);
            fs = dstPath.getFileSystem(hadoopClient.getConf());

            outputStream = fs.create(dstPath);
            outputStream.write(contents);
            outputStream.flush();

            return true;

        } finally {
            try {
                if (outputStream != null) {
                    outputStream.close();
                }
                if (fs != null) {
                    fs.close();
                }
            } catch (Throwable e) {
            }
        }
    }

    @Override
    public boolean createFile(String dst) throws Throwable {

        FileSystem fs = null;

        try {
            Path dstPath = new Path(dst);
            fs = dstPath.getFileSystem(hadoopClient.getConf());

            fs.create(dstPath);

            return true;

        } finally {
            try {
                if (fs != null) {
                    fs.close();
                }
            } catch (Throwable e) {
            }
        }
    }

    /**
     * 删除hdfs文件
     *
     * @param filePath 文件路径
     * @throws Throwable 异常
     */
    public boolean deleteFile(String filePath) throws Throwable {

        FileSystem fs = null;

        try {
            Path path = new Path(filePath);
            fs = path.getFileSystem(hadoopClient.getConf());

            return fs.deleteOnExit(path);

        } finally {
            if (fs != null) {
                try {
                    fs.close();
                } catch (Throwable e) {

                }
            }
        }
    }


    @Override
    public boolean removeDir(String dir) throws Throwable {
        FileSystem hdfs = null;
        try {
            hdfs = FileSystem.get(hadoopClient.getConf());
            return removeDir(hdfs, dir);
        } finally {
            if (hdfs != null) {
                try {
                    hdfs.close();
                } catch (Throwable e) {
                }
            }
        }
    }

    public boolean removeDir(FileSystem hdfs, String dir) throws Throwable {
        try {
            Path path = new Path(dir);

            //判断文件是否存在， 如果不存在， 直接返回true;
            if(!hdfs.exists(path)){
                return true;
            }

            //判断， 如果是文件， 直接调用文件删除方法
            if (hdfs.isFile(path)) {
                return hdfs.delete(path, true);
            } else {//如果是文件夹， 删除文件下所有文件
                ArrayList<Path> childrenPath = listFiles(hdfs, dir);
                for (Path child : childrenPath) {
                    if (hdfs.isFile(child)) {
                        hdfs.delete(child, true);
                    } else {
                        removeDir(hdfs, child.toString());
                    }
                }
                //最后删除文件夹
                return hdfs.delete(path, true);
            }
        } finally {

        }
    }

    public ArrayList<Path> listFiles(FileSystem hdfs, String fileNamePath) throws Throwable {
        try {
            Path path = new Path(fileNamePath);
            RemoteIterator<LocatedFileStatus> riter = hdfs.listFiles(path, false);

            ArrayList<Path> paths = new ArrayList<>();
            while (riter.hasNext()) {
                LocatedFileStatus lfs = riter.next();
                paths.add(lfs.getPath());
            }
            return paths;
        } finally {

        }
    }



    @Override
    public boolean mkdir(String path) throws Throwable {

        FileSystem fs = null;

        try {
            Path srcPath = new Path(path);
            fs = srcPath.getFileSystem(hadoopClient.getConf());

            return fs.mkdirs(srcPath);

        } finally {
            if (fs != null) {
                try {
                    fs.close();
                } catch (Throwable e) {

                }
            }
        }
    }

    @Override
    public boolean downloadFile(String dstPath, String srcPath) throws Throwable {

        //
        FileSystem hdfs = null;

        // 创建目标文件
        File rootFile = new File(dstPath);
        if (!rootFile.exists()) {
            rootFile.mkdirs();
        }

        try {
            // 读取原文件
            Path path = new Path(srcPath);
            hdfs = path.getFileSystem(hadoopClient.getConf());

            if (hdfs.isFile(path)) {

                //只下载非txt文件
                String fileName = path.getName();
                if (!fileName.toLowerCase().endsWith("txt")) {

                    FSDataInputStream in = null;
                    FileOutputStream out = null;

                    try {
                        in = hdfs.open(path);
                        File srcfile = new File(rootFile, path.getName());
                        if (!srcfile.exists()) {
                            srcfile.createNewFile();
                        }

                        out = new FileOutputStream(srcfile);
                        IOUtils.copyBytes(in, out, 4096, false);

                    } finally {
                        IOUtils.closeStream(in);
                        IOUtils.closeStream(out);
                    }

                    //下载完后，在hdfs上将原文件删除
                    deleteFile(path.toString());

                    return true;
                }

            } else if (hdfs.isDirectory(path)) {

                File dstDir = new File(dstPath);
                if (!dstDir.exists()) {
                    dstDir.mkdirs();
                }

                //在本地目录上加一层子目录
                String filePath = path.toString();//目录
                String subPath[] = filePath.split("/");

                if (hdfs.exists(path) && hdfs.isDirectory(path)) {
                    FileStatus[] srcFileStatus = hdfs.listStatus(path);
                    if (srcFileStatus != null) {
                        for (FileStatus status : hdfs.listStatus(path)) {
                            //下载子目录下文件
                            String newdstPath = dstPath + subPath[subPath.length - 1] + "/";
                            downloadFile(newdstPath, status.getPath().toString());
                        }
                    }
                }

                return true;
            }
        } finally {
            if (hdfs != null) {
                try {
                    hdfs.close();
                } catch (Throwable e) {
                }
            }
        }

        return false;
    }

    @Override
    public boolean uploadFile(String localSrc, String dst) throws Throwable {

        File srcFile = new File(localSrc);
        if (srcFile.isDirectory()) {
            copyDirectory(localSrc, dst);
        } else {
            copyFile(localSrc, dst);
        }

        return true;
    }

    @Override
    public boolean copyDirectory(String src, String dst) throws Throwable {

        FileSystem fs = null;

        try {

            Path path = new Path(dst);
            fs = path.getFileSystem(hadoopClient.getConf());

            if (!fs.exists(path)) {
                fs.mkdirs(path);
            }

            File file = new File(src);
            File[] files = file.listFiles();

            for (int i = 0; i < files.length; i++) {
                File f = files[i];
                if (f.isDirectory()) {
                    String fname = f.getName();
                    if (dst.endsWith("/")) {
                        copyDirectory(f.getPath(), dst + fname + "/");
                    } else {
                        copyDirectory(f.getPath(), dst + "/" + fname + "/");
                    }
                } else {
                    copyFile(f.getPath(), dst);
                }
            }

        } finally {
            if (fs != null) {
                try {
                    fs.close();
                } catch (Throwable e) {
                }
            }
        }

        return true;
    }

    @Override
    public boolean copyFile(String localSrc, String dst) throws Throwable {

        FileSystem fs = null;

        try {
            File file = new File(localSrc);
            dst = dst + file.getName();

            Path path = new Path(dst);

            fs = path.getFileSystem(hadoopClient.getConf());
            fs.exists(path);

            InputStream in = new BufferedInputStream(new FileInputStream(file));
            OutputStream out = fs.create(new Path(dst));

            IOUtils.copyBytes(in, out, 4096, true);

            return true;

        } finally {
            if (fs != null) {
                try {
                    fs.close();
                } catch (Throwable e) {
                }
            }
        }

    }

    //check if a file  exists in HDFS
    public boolean checkFileExist(String FileName) throws Throwable {

        FileSystem fs = null;
        try {

            FileSystem hdfs = FileSystem.get(hadoopClient.getConf());
            Path path = new Path(FileName);
            return hdfs.exists(path);

        } finally {
            if (fs != null) {
                try {
                    fs.close();
                } catch (Throwable e) {
                }
            }
        }
    }

    public ArrayList<Path> listFiles(String fileNamePath) throws Throwable {

        FileSystem hdfs = null;

        try {
            hdfs = FileSystem.get(hadoopClient.getConf());
            ArrayList<Path> paths = new ArrayList<>();
            paths = listFiles(hdfs, fileNamePath);

            return paths;

        } finally {
            if (hdfs != null) {
                try {
                    hdfs.close();
                } catch (Throwable e) {
                }
            }
        }
    }

    public boolean reNameFile(String srcName, String dstName) throws Throwable {

        FileSystem hdfs = null;

        try {
            hdfs = FileSystem.get(hadoopClient.getConf());
            Path fromPath = new Path(srcName);
            Path toPath = new Path(dstName);

            return hdfs.rename(fromPath, toPath);

        } finally {
            if (hdfs != null) {
                try {
                    hdfs.close();
                } catch (Throwable e) {
                }
            }
        }
    }
}
