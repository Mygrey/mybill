package com.zcreator.bigdata.aggregation.hdfs;

import org.apache.hadoop.fs.Path;

import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hdfs
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/13
 **/
public interface HdfsOps {

    /**
     * 获取文件列表
     *
     * @param srcPath 文件夹路径
     * @return
     */
    List<String> getFileList(String srcPath) throws Throwable;

    /**
     * @param dst      源文件
     * @param contents 文件内容
     * @return
     */
    boolean createFile(String dst, byte[] contents) throws Throwable;

    /**
     * 创建文件
     *
     * @param dst 源文件
     * @param dst 目标文件
     * @return
     */
    boolean createFile(String dst) throws Throwable;

    /**
     * 删出文件
     *
     * @param filePath
     * @return
     */
    boolean deleteFile(String filePath) throws Throwable;

    /**
     * 创建目录
     *
     * @param path 目录
     * @return
     * @throws Throwable
     */
    boolean mkdir(String path) throws Throwable;

    /**
     * 下载文件
     *
     * @param dstPath 目标文件或文件夹
     * @param srcPath 源文件或文件夹
     * @return
     * @throws Throwable
     */
    boolean downloadFile(String dstPath, String srcPath) throws Throwable;

    /**
     * 上传文件
     *
     * @param localSrc 本地文件路径
     * @param dst      目标文件路径
     * @return
     * @throws Throwable
     */
    boolean uploadFile(String localSrc, String dst) throws Throwable;

    /**
     * 复制文件
     *
     * @param localSrc 本地文件
     * @param dst      目标文件
     * @return
     * @throws Throwable
     */
    boolean copyFile(String localSrc, String dst) throws Throwable;

    /**
     * 复制目录
     *
     * @param src 目标目录
     * @param dst 源目录
     * @return
     * @throws Throwable
     */
    boolean copyDirectory(String src, String dst) throws Throwable;

    /**
     * @param fileNamePath
     * @return
     */
    ArrayList<Path> listFiles(String fileNamePath) throws Throwable;

    /**
     * 重命名hdfs文件
     *
     * @param srcName 源文件
     * @param dstName 目标文件
     * @return
     * @throws Throwable
     */
    boolean reNameFile(String srcName, String dstName) throws Throwable;

    /**
     *  删除目录以及目录下所有文件
     * @param dir
     * @return
     * @throws Throwable
     */
    boolean removeDir(String dir) throws Throwable;
}
