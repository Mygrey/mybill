package com.zcreator.bigdata.aggregation.hdfs;

import org.apache.hadoop.conf.Configuration;

import java.util.List;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hdfs
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/13
 **/
public interface HdfsBusiOps {

    /**
     * 获取hdfs集群节点名称
     *
     * @param conf hdfs配置
     * @return
     * @throws Throwable
     */
    List<String> getAllNodeName(Configuration conf) throws Throwable;

    /**
     * @param conf
     * @param FileName
     * @return
     * @throws Throwable
     */
    long getFileModifyTime(Configuration conf, String FileName) throws Throwable;

    /**
     * 获取文件所在块的主机列表
     *
     * @param conf
     * @param fileName
     * @return
     * @throws Throwable
     */
    List<String[]> getFileBlockHost(Configuration conf, String fileName) throws Throwable;

    /**
     * 文件追加内容
     *
     * @param line          内容
     * @param partitionPath 分区目录
     * @param fileDate      时间， 格式为: yyyMMdd
     * @param filePrefix    文件名
     * @throws Throwable
     */
    void appendHdfs(Configuration conf, List<String> line, String partitionPath, String fileDate, String filePrefix) throws Throwable;

    /**
     * 文件追加内容
     *
     * @param conf  hdfs配置
     * @param uri   资源
     * @param lines 数据
     * @throws Throwable
     */
    void appendHdfs(Configuration conf, String uri, List<String> lines) throws Throwable;

    /**
     * 读取文件
     *
     * @param filePath
     * @return
     * @throws Throwable
     */
    boolean readFile(Configuration conf, String filePath) throws Throwable;

}
