package com.zcreator.bigdata.aggregation.hdfs.utils;

import lombok.Data;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Data
public class HadoopClient {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    private String defaultFS;
    private String zKQuorum;
    private String nameServices;
    private String nameNodes;
    private String rpcAddressNN1;
    private String rpcAddressNN2;
    private String userName;
    private Configuration conf=new Configuration();

    public Configuration getConf() {
        return conf;
    }

    public void setDefaultFS(String defaultFS) {
        this.defaultFS = defaultFS;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void init() {
        try {
//            conf = new Configuration();
            // 基本参数设置
            if (StringUtils.isNotBlank(defaultFS)) {
                conf.set("fs.defaultFS", defaultFS);
            }
            if (StringUtils.isNotBlank(zKQuorum)) {
                conf.set("ha.zookeeper.quorum", zKQuorum);
            }
            if (StringUtils.isNotBlank(nameServices)) {
                conf.set("dfs.nameservice", nameServices);
            }
            if (StringUtils.isNotBlank(nameNodes)) {
                conf.set("dfs.ha.namenodes.mycluster-tj", nameNodes);
            }
            if (StringUtils.isNotBlank(rpcAddressNN1)) {
                conf.set("dfs.namenode.rpc-address.mycluster-tj.nn1", rpcAddressNN1);
            }
            if (StringUtils.isNotBlank(rpcAddressNN2)) {
                conf.set("dfs.namenode.rpc-address.mycluster-tj.nn2", rpcAddressNN2);
            }
            // 设置hdfs文件系统访问用户
            if (StringUtils.isNotBlank(userName)) {
                System.setProperty("HADOOP_USER_NAME", userName);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}