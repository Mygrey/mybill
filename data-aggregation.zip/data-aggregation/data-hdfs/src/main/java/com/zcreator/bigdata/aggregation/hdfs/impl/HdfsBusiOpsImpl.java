package com.zcreator.bigdata.aggregation.hdfs.impl;

import com.google.common.collect.Lists;
import com.zcreator.bigdata.aggregation.hdfs.HdfsBusiOps;
import com.zcreator.bigdata.aggregation.hdfs.HdfsOps;
import com.zcreator.bigdata.aggregation.hdfs.utils.HadoopClient;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.hdfs.DistributedFileSystem;
import org.apache.hadoop.hdfs.protocol.DatanodeInfo;
import org.apache.hadoop.io.IOUtils;

import java.io.InputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hdfs.impl
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/13
 **/
public class HdfsBusiOpsImpl implements HdfsBusiOps {

    public List<String> getAllNodeName(Configuration conf) throws Throwable {

        FileSystem fs = null;
        List<String> nodeNames = Lists.newArrayList();

        try {
            fs = FileSystem.get(conf);
            DistributedFileSystem hdfs = (DistributedFileSystem) fs;
            DatanodeInfo[] dataNodeStats = hdfs.getDataNodeStats();

            for (int i = 0; i < dataNodeStats.length; i++) {
                nodeNames.add(dataNodeStats[i].getHostName());
            }

            return nodeNames;

        } finally {
            if (fs != null) {
                try {
                    fs.close();
                } catch (Throwable e) {
                }
            }
        }

    }

    public List<String[]> getFileBlockHost(Configuration conf, String fileName) throws Throwable {

        FileSystem fs = null;

        try {
            List<String[]> list = new ArrayList<>();

            fs = FileSystem.get(conf);
            Path path = new Path(fileName);

            FileStatus fileStatus = fs.getFileStatus(path);
            BlockLocation[] blkLocations = fs.getFileBlockLocations(fileStatus, 0, fileStatus.getLen());

            int blkCount = blkLocations.length;
            for (int i = 0; i < blkCount; i++) {
                String[] hosts = blkLocations[i].getHosts();
                list.add(hosts);
            }

            return list;

        } finally {
            if (fs != null) {
                try {
                    fs.close();
                } catch (Throwable e) {
                }
            }
        }
    }

    public long getFileModifyTime(Configuration conf, String FileName) throws Throwable {

        FileSystem fs = null;

        try {

            fs = FileSystem.get(conf);

            Path path = new Path(FileName);
            FileStatus fileStatus = fs.getFileStatus(path);

            return fileStatus.getModificationTime();

        } finally {
            if (fs != null) {
                try {
                    fs.close();
                } catch (Throwable e) {
                }
            }
        }
    }

    public void appendHdfs(Configuration conf, List<String> lines, String partitionPath, String fileDate, String
            filePrefix) throws Throwable {

        FileSystem fs = null;
        FSDataOutputStream out = null;

        try {
            if (conf == null) {
                throw new RuntimeException("conf is null");
            }
            conf.setBoolean("dfs.support.append", true);

            HadoopClient client = new HadoopClient();
            client.setConf(conf);

            HdfsOps HdfsOps = new HdfsOpsImpl(client);

            if (!((HdfsOpsImpl) HdfsOps).checkFileExist(partitionPath)) {
                HdfsOps.mkdir(partitionPath);
            }

            String fileName = partitionPath + "/" + filePrefix + "_" + fileDate;
            if (!((HdfsOpsImpl) HdfsOps).checkFileExist(fileName)) {
                HdfsOps.createFile(fileName);
            }

            fs = FileSystem.get(URI.create(fileName), conf);
            out = fs.append(new Path(fileName));

            for (String line : lines) {
                out.writeUTF(line);
            }

        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (fs != null) {
                    fs.close();
                }
            } catch (Throwable e) {
            }
        }
    }

    @Override
    public void appendHdfs(Configuration conf, String uri, List<String> lines) throws Throwable {

        FileSystem fs = null;
        FSDataOutputStream out = null;

        try {

            if (conf == null) {
                throw new RuntimeException("conf is null");
            }
            conf.setBoolean("dfs.support.append", true);

            HadoopClient client = new HadoopClient();
            client.setConf(conf);

            HdfsOps HdfsOps = new HdfsOpsImpl(client);

            if (!((HdfsOpsImpl) HdfsOps).checkFileExist(uri)) {
                HdfsOps.mkdir(uri.substring(0, uri.lastIndexOf("/")));
            }

            if (!((HdfsOpsImpl) HdfsOps).checkFileExist(uri)) {
                HdfsOps.createFile(uri);
            }

            fs = FileSystem.get(URI.create(uri.substring(uri.lastIndexOf("/"), uri.length())), conf);
            out = fs.append(new Path(uri));

            for (String line : lines) {
                out.writeUTF(line);
            }

        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (fs != null) {
                    fs.close();
                }
            } catch (Throwable e) {
            }
        }
    }

    @Override
    public boolean readFile(Configuration conf, String filePath) throws Throwable {

        FileSystem fs = null;

        try {
            URI uri = new URI(filePath);
            fs = FileSystem.get(uri, conf);

            Path srcPath = new Path(filePath);
            InputStream in = fs.open(srcPath);
            IOUtils.copyBytes(in, System.out, 4096, false);

            return true;

        } finally {
            if (fs != null) {
                try {
                    fs.close();
                } catch (Throwable e) {
                }
            }
        }
    }
}
