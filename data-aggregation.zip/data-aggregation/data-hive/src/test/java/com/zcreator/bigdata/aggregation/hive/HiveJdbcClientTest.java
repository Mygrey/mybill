package com.zcreator.bigdata.aggregation.hive;

import com.alibaba.fastjson.JSON;
import com.zcreator.bigdata.aggregation.hive.impl.HiveJdbcClientImpl;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hive
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/20
 **/
public class HiveJdbcClientTest {

    private HiveJdbcClient client;

    @Before
    public void init() {
        client = new HiveJdbcClientImpl();
    }

    @Test
    public void countData() {
    }

    @Test
    public void selectData() {
        String tableName = "t_anopt_summary";
        List<String> columns = Lists.newArrayList();
        columns.add("wupai");
        columns.add("address");
        columns.add("ip");
        columns.add("wupai");
        columns.add("total");

        List<Map<String, Object>> dataLs = client.selectData(tableName, columns, 10);
        dataLs.forEach(data -> {
            System.out.println(JSON.toJSONString(data));
        });
    }

    @Test
    public void selectData_one() {
        String tableName = "t_anopt_summary";
        int columnTotal = 10;
        List<Map<String, Object>> dataLs = client.selectData(tableName, columnTotal);
        assertNotNull(dataLs);
    }

    @Test
    public void selectData_tow() {
        String sql = "select * from t_anopt_summary limit 50";
        List<Map<String, Object>> dataLs = client.selectData(sql);
        assertNotNull(dataLs);
    }

    @Test
    public void loadData() {
    }

    @Test
    public void createTable() {
    }

    @Test
    public void dropTable() {
    }

    @Test
    public void showTables() {
        List<String> tables = client.showTables();
        tables.forEach(tableName -> {
            System.out.println(tableName);
        });
        assertNotNull(tables);

    }

    @Test
    public void descTable() {

        String tableName = "t_anopt_summary";
        List<String> table = client.descTable(tableName);

        table.forEach(str -> {
            System.out.println(str);
        });
        assertNotNull(table);
    }

    @Test
    public void showDatabases() {
        List<String> databases = client.showDatabases();
        databases.forEach(str -> {
            System.out.println(str);
        });
        assertNotNull(databases);
    }

    @Test
    public void showTables1() {
    }
}