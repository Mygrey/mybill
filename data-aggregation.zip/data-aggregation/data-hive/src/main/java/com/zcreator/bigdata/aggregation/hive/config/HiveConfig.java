package com.zcreator.bigdata.aggregation.hive.config;

import lombok.Data;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hive.config
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/20
 **/
@Data
public class HiveConfig {
    private String driverName = "org.apache.hive.jdbc.HiveDriver";
    private String url = "jdbc:hive2://cdh2:10000/default";
    private String user = "hive";
    private String password = "hive";

    public String getDriverName() {
        return driverName;
    }

    public String getUrl() {
        return url;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }
}
