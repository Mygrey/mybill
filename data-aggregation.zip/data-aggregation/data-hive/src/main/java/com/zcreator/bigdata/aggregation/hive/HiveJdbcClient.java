package com.zcreator.bigdata.aggregation.hive;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hive
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/13
 * http://www.yisutech.com
 **/
public interface HiveJdbcClient {

    int countData(String tableName) throws SQLException;

    List<Map<String, Object>> selectData(String tableName, List<String> columns, int size);

    List<Map<String, Object>> selectData(String tableName, int size);

    List<Map<String, Object>> selectData(String sql);

    void loadData(String filepath, String tableName);

    void loadData(String loadDataSql);

    void createTable(String tableName) throws SQLException;

    void dropTable(String tableName);

    List<String> showTables(String tableName);

    List<String> descTable(String tableName);

    List<String> showDatabases();

    List<String> showTables();
}
