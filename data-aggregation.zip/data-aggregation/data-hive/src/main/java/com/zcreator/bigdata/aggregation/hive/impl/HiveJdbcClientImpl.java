package com.zcreator.bigdata.aggregation.hive.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.zcreator.bigdata.aggregation.hive.HiveJdbcClient;
import com.zcreator.bigdata.aggregation.hive.config.HiveConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.List;
import java.util.Map;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.hive.impl
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/13
 * http://www.yisutech.com
 **/
public class HiveJdbcClientImpl implements HiveJdbcClient {

    private String driverName = "org.apache.hive.jdbc.HiveDriver";
    private String url = "jdbc:hive2://cdh2:10000/default";
    private String user = "hive";
    private String password = "hive";

    private Object lock = new Object();
    private Connection connection;

    private static final Logger LOG = LoggerFactory.getLogger(HiveJdbcClientImpl.class);

    private Connection getConn() throws ClassNotFoundException, SQLException {

        Class.forName(driverName);

        if (connection == null) {
            synchronized (lock) {
                if (connection == null) {
                    connection = DriverManager.getConnection(url, user, password);
                }
            }
        }

        return connection;
    }

    public HiveJdbcClientImpl() {

    }

    public HiveJdbcClientImpl(HiveConfig config) {
        this.driverName = config.getDriverName();
        this.url = config.getUrl();
        this.user = config.getUser();
        this.password = config.getPassword();
    }

    public List<String> showTables() {

        List<String> tables = Lists.newArrayList();
        Statement st = null;

        try {
            String sql = "show tables";

            st = getConn().createStatement();
            ResultSet res = st.executeQuery(sql);

            while (res.next()) {
                tables.add(res.getString(1));
            }

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }

        return tables;
    }

    // 创建数据库
    public void createDatabase(String databaseName) {

        Statement st = null;

        try {
            st = getConn().createStatement();

            String sql = "create database " + databaseName;
            st.execute(sql);

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }
    }

    // 查询所有数据库
    public List<String> showDatabases() {

        List<String> databases = Lists.newArrayList();
        Statement st = null;

        try {
            st = getConn().createStatement();

            String sql = "show databases";
            ResultSet res = st.executeQuery(sql);

            while (res.next()) {
                databases.add(res.getString(1));
            }

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }
        return databases;
    }

    @Override
    public int countData(String tableName) {

        Statement st = null;

        try {
            st = getConn().createStatement();
            String sql = "select count(1) from " + tableName;

            ResultSet res = st.executeQuery(sql);

            while (res.next()) {
                return res.getInt(1);
            }
        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }

        return 0;
    }

    @Override
    public List<Map<String, Object>> selectData(String tableName, List<String> columns, int size) {

        List<Map<String, Object>> dataLs = Lists.newArrayList();
        Statement st = null;
        try {

            if (columns == null || columns.size() == 0) {
                return Lists.newArrayList();
            }

            st = getConn().createStatement();
            String sql = "select * from " + tableName + " limit " + size;

            ResultSet res = st.executeQuery(sql);
            while (res.next()) {

                Map<String, Object> objectMap = Maps.newHashMap();
                columns.forEach(column -> {
                    try {
                        objectMap.put(column, res.getObject(column));
                    } catch (Throwable e) {
                        throw new RuntimeException(e);
                    }
                });
                dataLs.add(objectMap);
            }

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }

        return dataLs;
    }

    @Override
    public List<Map<String, Object>> selectData(String tableName, int size) {
        List<Map<String, Object>> dataLs = Lists.newArrayList();
        Statement st = null;
        try {
            st = getConn().createStatement();
            String sql = "select * from " + tableName + " limit " + size;

            ResultSet res = st.executeQuery(sql);
            int columnCount = res.getMetaData().getColumnCount();

            while (res.next()) {
                Map<String, Object> objectMap = Maps.newHashMap();
                for (int i = 1; i <= columnCount; i++) {
                    objectMap.put(res.getMetaData().getColumnName(i), res.getObject(i));
                }
                dataLs.add(objectMap);
            }

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }

        return dataLs;
    }

    @Override
    public List<Map<String, Object>> selectData(String sql) {

        List<Map<String, Object>> dataLs = Lists.newArrayList();
        Statement st = null;

        try {
            st = getConn().createStatement();
            ResultSet res = st.executeQuery(sql);

            int columnCount = res.getMetaData().getColumnCount();
            while (res.next()) {

                Map<String, Object> objectMap = Maps.newHashMap();
                for (int i = 1; i <= columnCount; i++) {
                    objectMap.put(res.getMetaData().getColumnName(i), res.getObject(i));
                }
                dataLs.add(objectMap);
            }

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }

        return dataLs;
    }

    @Override
    public void loadData(String filepath, String tableName) {

        Statement st = null;
        try {
            String sql = "load data local inpath '" + filepath + "' into table " + tableName;

            st = getConn().createStatement();
            ResultSet res = st.executeQuery(sql);

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }
    }

    @Override
    public void loadData(String loadDataSql) {

        Statement st = null;
        try {
            st = getConn().createStatement();
            ResultSet res = st.executeQuery(loadDataSql);

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }
    }

    @Override
    public List<String> showTables(String tableName) {

        List<String> columns = Lists.newArrayList();
        Statement st = null;
        try {
            String sql = "show tables '" + tableName + "'";

            st = getConn().createStatement();
            ResultSet res = st.executeQuery(sql);

            while (res.next()) {
                columns.add(res.getString(1));
            }

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }

        return columns;
    }

    // 查看表结构
    public List<String> descTable(String tableName) {

        List<String> descs = Lists.newArrayList();
        Statement st = null;
        try {

            String sql = "desc " + tableName;
            st = getConn().createStatement();

            ResultSet res = st.executeQuery(sql);
            while (res.next()) {
                descs.add(res.getString(1) + "," + res.getString(2));
            }

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }
        return descs;
    }

    @Override
    public void createTable(String tableName) {

        Statement st = null;
        try {

            st = getConn().createStatement();
            String sql = "create table " + tableName
                    + " (key int, value string)  row format delimited fields terminated by '\t'";

            st.executeQuery(sql);

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }
    }


    @Override
    public void dropTable(String tableName) {

        Statement st = null;
        try {
            // 创建的表名
            String sql = "drop table " + tableName;

            st = getConn().createStatement();
            st.executeQuery(sql);

        } catch (Throwable e) {
            throw new RuntimeException(e);

        } finally {
            close(st, connection);
        }
    }

    private void close(Statement st, Connection connection) {
        try {
            if (st != null) {
                st.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (Throwable e) {
            LOG.error("close error", e);
        }
    }
}
