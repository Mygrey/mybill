package com.zcreator.bigdata.aggregation.metaconf.impl;

import com.zcreator.bigdata.aggregation.metaconf.MetaConfigService;
import org.springframework.stereotype.Service;

/**
 * Copyright (C) 20016-2066
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.metaconf.impl
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/2
 * http://www.yisutech.com
 **/
@Service
public class MetaConfigServiceImpl implements MetaConfigService {

}
