package com.zcreator.bigdata.aggregation.metaconf;

/**
 * Copyright (C) 20016-2066
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.metaconf
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/2
 * http://www.yisutech.com
 **/
public interface MetaService {
}
