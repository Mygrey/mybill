package com.zcreator.bigdata.aggregation.kafka.core;

import com.zcreator.bigdata.aggregation.kafka.core.model.MessageEntity;

import java.util.List;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 * http://www.yisutech.com
 **/
public interface IKafkaProducer {

    /**
     * 批量发送消息
     * <p>
     * desc:
     * 有一条发送失败，发送终止
     *
     * @param topic           发送消息topic
     * @param messageEntities 消息内容
     */
    void sendMessage(String topic, List<MessageEntity> messageEntities) throws Throwable;

    /**
     * 单发消息
     *
     * @param topic         发送消息topic
     * @param messageEntity 消息内容
     */
    void sendMessage(String topic, MessageEntity messageEntity);

    /**
     * 同步单发消息
     *
     * @param topic         发送消息topic
     * @param messageEntity 消息内容
     */
    void synSendMessage(String topic, MessageEntity messageEntity);

    /**
     * 销毁kafka生产者实例
     */
    void closeProducer();

}
