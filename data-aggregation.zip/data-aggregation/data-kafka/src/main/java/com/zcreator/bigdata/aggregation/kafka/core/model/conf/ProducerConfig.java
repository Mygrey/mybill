package com.zcreator.bigdata.aggregation.kafka.core.model.conf;

import lombok.Data;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core.model
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
@Data
public class ProducerConfig extends KafkaConfig {

    /**
     * 消息队列的名称，可以先行在kafka服务中进行创建。如果kafka中并未创建该topic，那么便会自动创建
     */
    public String topic;
    /**
     * 消息的确认机制，默认值是0
     * <p>
     * desc:
     * <p>
     * acks=0：如果设置为0，生产者不会等待kafka的响应。
     * acks=1：这个配置意味着kafka会把这条消息写到本地日志文件中，但是不会等待集群中其他机器的成功响应。
     * acks=all：这个配置意味着leader会等待所有的follower同步完成。这个确保消息不会丢失，除非kafka集群中所有机器挂掉。这是最强的可用性保证。
     */
    public String acks = "all";
    /**
     * 配置为大于0的值的话，客户端会在消息发送失败时重新发送
     */
    public int retries = 0;
    /**
     * 当多条消息需要发送到同一个分区时，生产者会尝试合并网络请求。这会提高client和生产者的效率
     */
    public int batch_size = 1000;
    /**
     * 键序列化，默认org.apache.kafka.common.serialization.StringSerializer
     */
    public String key_serializer = "org.apache.kafka.common.serialization.StringSerializer";
    /**
     * 值序列化，默认org.apache.kafka.common.serialization.StringSerializer
     */
    public String value_serializer = "org.apache.kafka.common.serialization.StringSerializer";
}
