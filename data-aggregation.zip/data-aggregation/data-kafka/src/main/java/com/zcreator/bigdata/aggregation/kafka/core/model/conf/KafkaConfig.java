package com.zcreator.bigdata.aggregation.kafka.core.model.conf;

import lombok.Data;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 * http://www.yisutech.com
 **/
@Data
public class KafkaConfig {

    /**
     * kafka的地址
     */
    public String bootstrap_Servers;

    public String security_protocol;
    public String ssl_truststore_location;
    public String ssl_truststore_password;

    public String ssl_key_password;
    public String ssl_keystore_location;
    public String ssl_keystore_password;
}
