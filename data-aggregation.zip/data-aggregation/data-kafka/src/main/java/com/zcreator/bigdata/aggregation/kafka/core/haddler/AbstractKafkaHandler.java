package com.zcreator.bigdata.aggregation.kafka.core.haddler;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.util.Assert;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core.haddler
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
public abstract class AbstractKafkaHandler implements IkafkaHandler {

    @Override
    public void handler(ConsumerRecord<String, String> consumerRecord) throws Throwable {
        Assert.notNull(consumerRecord, "consumerRecord is null");
        handlerSpecial(consumerRecord.topic(), consumerRecord.key(), consumerRecord.value());
    }

    protected abstract void handlerSpecial(String topic, String key, String value) throws Throwable;
}
