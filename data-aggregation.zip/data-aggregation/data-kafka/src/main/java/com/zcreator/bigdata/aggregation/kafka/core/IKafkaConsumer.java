package com.zcreator.bigdata.aggregation.kafka.core;

import com.zcreator.bigdata.aggregation.kafka.core.haddler.IkafkaHandler;

import java.util.List;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
public interface IKafkaConsumer {

    /**
     * 消费kafka消息
     *
     * @param topics  订阅的kafka topic
     * @param handler 处理消息类
     */
    void consumerMessage(List<String> topics, IkafkaHandler handler);

    /**
     * 销毁kafka消费者实例
     */
    void closeConsumer();

}
