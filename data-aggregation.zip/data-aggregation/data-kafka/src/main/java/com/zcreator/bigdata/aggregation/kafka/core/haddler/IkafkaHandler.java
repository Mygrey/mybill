package com.zcreator.bigdata.aggregation.kafka.core.haddler;

import org.apache.kafka.clients.consumer.ConsumerRecord;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
public interface IkafkaHandler {

    void handler(ConsumerRecord<String, String> consumerRecord) throws Throwable;
}
