package com.zcreator.bigdata.aggregation.kafka.core.model;

import lombok.Data;

import java.io.Serializable;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core.model
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
@Data
public class MessageEntity implements Serializable {
    String key;
    String value;
}
