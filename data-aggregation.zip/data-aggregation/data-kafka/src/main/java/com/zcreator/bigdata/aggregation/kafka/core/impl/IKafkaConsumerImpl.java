package com.zcreator.bigdata.aggregation.kafka.core.impl;

import com.zcreator.bigdata.aggregation.kafka.core.IKafkaConsumer;
import com.zcreator.bigdata.aggregation.kafka.core.haddler.IkafkaHandler;
import com.zcreator.bigdata.aggregation.kafka.core.model.conf.ConsumerConfig;
import org.apache.commons.lang.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core.impl
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
public class IKafkaConsumerImpl implements IKafkaConsumer {

    private KafkaConsumer consumer;
    private AtomicBoolean initOne = new AtomicBoolean();
    private static Logger LOG = LoggerFactory.getLogger("kafka_consumer");


    public IKafkaConsumerImpl() {
    }

    public IKafkaConsumerImpl(ConsumerConfig kafkaConfig) {
        if (initOne.compareAndSet(Boolean.FALSE, Boolean.TRUE)) {
            this.init(kafkaConfig);
        }
    }

    private void init(ConsumerConfig kafkaConfig) {

        try {
            // 参数检查
            Assert.notNull(kafkaConfig, "kafkaConfig is null");
            Assert.notNull(kafkaConfig.getBootstrap_Servers(), "servers is null");
            Assert.notNull(kafkaConfig.getGroup_id(), "group_id is null");

            // 生成 myProducer 对象
            Properties props = new Properties();

            props.put("bootstrap.servers", kafkaConfig.getBootstrap_Servers()); // cdh1:9092,cdh6:9092,cdh7:9092
            props.put("key.deserializer", kafkaConfig.getValue_deserializer());
            props.put("value.deserializer", kafkaConfig.getValue_deserializer());

            props.put("group.id", kafkaConfig.getGroup_id());

            if (StringUtils.isNotBlank(kafkaConfig.getEnable_auto_commit())) {
                props.put("enable.auto.commit", kafkaConfig.getEnable_auto_commit());
            }

            if (StringUtils.isNotBlank(kafkaConfig.getAuto_commit_interval_ms())) {
                props.put("auto.commit.interval.ms", kafkaConfig.getAuto_commit_interval_ms());
            }

            if (StringUtils.isNotBlank(kafkaConfig.getSession_timeout_ms())) {
                props.put("session.timeout.ms", kafkaConfig.getSession_timeout_ms());
            }

            if (StringUtils.isNotBlank(kafkaConfig.getSecurity_protocol())) {
                props.put("security.protocol", kafkaConfig.getSecurity_protocol());
            }

            if (StringUtils.isNotBlank(kafkaConfig.getSsl_key_password())) {
                props.put("ssl.key.password", kafkaConfig.getSsl_key_password());
            }

            if (StringUtils.isNotBlank(kafkaConfig.getSsl_keystore_location())) {
                props.put("ssl.keystore.location", kafkaConfig.getSsl_keystore_location());
            }

            if (StringUtils.isNotBlank(kafkaConfig.getSsl_keystore_password())) {
                props.put("ssl.keystore.password", kafkaConfig.getSsl_keystore_password());
            }

            if (StringUtils.isNotBlank(kafkaConfig.getSsl_truststore_location())) {
                props.put("ssl.truststore.location", kafkaConfig.getSsl_truststore_location());
            }

            if (StringUtils.isNotBlank(kafkaConfig.getSsl_truststore_password())) {
                props.put("ssl.truststore.password", kafkaConfig.getSsl_truststore_password());
            }

            if (StringUtils.isNotBlank(kafkaConfig.getAuto_offset_reset())) {
                props.put("auto.offset.reset", kafkaConfig.getAuto_offset_reset());
            }

            consumer = new KafkaConsumer<>(props);

        } catch (Throwable e) {
            // 重置初始化状态
            initOne.set(Boolean.FALSE);
            LOG.error("init_error", e);
        }
    }

    public void consumerMessage(List<String> topics, IkafkaHandler handler) {

        try {
            // 参数校验
            Assert.notNull(consumer, "consumer is null");

            // 消息发送
            consumer.subscribe(topics);

            // 处理消息
            while (true) {
                try {
                    ConsumerRecords<String, String> records = consumer.poll(2000);
                    for (ConsumerRecord<String, String> record : records) {

                        // 处理中没有抛出异常，默认提交消息
                        try {
                            // 消费消息
                            handler.handler(record);

                            // 提交消费确认
                            consumer.commitSync();

                        } catch (Throwable e) {

                        }
                    }
                } catch (Throwable e) {
                    LOG.error("consumerMessage handler failure", e);
                    Thread.currentThread().sleep(2000);
                }
            }

        } catch (Throwable e) {
            throw new RuntimeException(e.getCause());
        }
    }

    public void closeConsumer() {
        if (consumer != null) {
            consumer.close();
        }
    }

}
