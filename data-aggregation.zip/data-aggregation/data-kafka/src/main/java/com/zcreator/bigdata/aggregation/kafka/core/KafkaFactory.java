package com.zcreator.bigdata.aggregation.kafka.core;

import com.zcreator.bigdata.aggregation.kafka.core.impl.IKafkaConsumerImpl;
import com.zcreator.bigdata.aggregation.kafka.core.impl.IKafkaProducerImpl;
import com.zcreator.bigdata.aggregation.kafka.core.model.conf.ConsumerConfig;
import com.zcreator.bigdata.aggregation.kafka.core.model.conf.ProducerConfig;
import org.apache.commons.lang.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 * http://www.yisutech.com
 **/
public class KafkaFactory {

    private static ConcurrentHashMap<String, Object> consumerPools = new ConcurrentHashMap<>(32);
    private static ConcurrentHashMap<String, Object> producerPools = new ConcurrentHashMap<>(32);

    public synchronized static IKafkaConsumer createKafkaConsumer(ConsumerConfig config) {

        // 参数检查
        if (config == null) {
            throw new NullPointerException("KafkaConfig is null");
        }
        if (StringUtils.isBlank(config.getGroup_id())) {
            throw new NullPointerException("group_id is null");
        }
        if (StringUtils.isBlank(config.getBootstrap_Servers())) {
            throw new NullPointerException("servers is null");
        }

        // 先从对象池获取
        Object service;
        String groupId = config.getGroup_id();

        if ((service = consumerPools.get(groupId)) != null) {
            return (IKafkaConsumer) service;
        }

        // 初始化consumer, 放入对象池
        consumerPools.put(groupId, new IKafkaConsumerImpl(config));

        return (IKafkaConsumer) consumerPools.get(groupId);
    }


    public synchronized static IKafkaProducer createKafkaProducer(ProducerConfig config) {

        // 参数检查
        if (config == null) {
            throw new NullPointerException("KafkaConfig is null");
        }
        if (StringUtils.isBlank(config.getTopic())) {
            throw new NullPointerException("topic is null");
        }
        if (StringUtils.isBlank(config.getBootstrap_Servers())) {
            throw new NullPointerException("servers is null");
        }

        // 先从对象池获取
        Object service;
        String topic = config.getTopic();

        if ((service = producerPools.get(topic)) != null) {
            return (IKafkaProducer) service;
        }

        // 初始化consumer, 放入对象池
        producerPools.put(topic, new IKafkaProducerImpl(config));

        return (IKafkaProducer) producerPools.get(topic);
    }

    public static void destroy() {

        consumerPools.forEach((k, v) -> {
            IKafkaConsumer consumer = (IKafkaConsumer) v;
            consumer.closeConsumer();
        });
        consumerPools.clear();

        producerPools.forEach((k, v) -> {
            IKafkaProducer producer = (IKafkaProducer) v;
            producer.closeProducer();
        });
        producerPools.clear();
    }
}
