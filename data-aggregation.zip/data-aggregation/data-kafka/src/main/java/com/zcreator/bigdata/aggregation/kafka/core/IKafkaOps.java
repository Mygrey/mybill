package com.zcreator.bigdata.aggregation.kafka.core;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 * http://www.yisutech.com
 **/
public interface IKafkaOps {
}
