package com.zcreator.bigdata.aggregation.kafka.core.impl;

import com.zcreator.bigdata.aggregation.kafka.core.IKafkaProducer;
import com.zcreator.bigdata.aggregation.kafka.core.model.conf.KafkaConfig;
import com.zcreator.bigdata.aggregation.kafka.core.model.MessageEntity;
import com.zcreator.bigdata.aggregation.kafka.core.model.conf.ProducerConfig;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core.impl
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
public class IKafkaProducerImpl implements IKafkaProducer {


    private KafkaProducer producer;
    private AtomicBoolean initOne = new AtomicBoolean();
    private static Logger LOG = LoggerFactory.getLogger("kafka_producer");


    public IKafkaProducerImpl() {
    }

    public IKafkaProducerImpl(ProducerConfig kafkaConfig) {
        if (initOne.compareAndSet(Boolean.FALSE, Boolean.TRUE)) {
            this.init(kafkaConfig);
        }
    }

    private void init(ProducerConfig kafkaConfig) {

        try {
            // 参数检查
            Assert.notNull(kafkaConfig, "kafkaConfig is null");
            Assert.notNull(kafkaConfig.getBootstrap_Servers(), "servers is null");

            // 生成 myProducer 对象
            Properties props = new Properties();
            props.put("bootstrap.servers", kafkaConfig.getBootstrap_Servers()); // cdh1:9092,cdh6:9092,cdh7:9092
            props.put("key.serializer", kafkaConfig.getKey_serializer());       // org.apache.kafka.common.serialization.StringSerializer
            props.put("value.serializer", kafkaConfig.getValue_serializer());   // org.apache.kafka.common.serialization.StringSerializer

            producer = new KafkaProducer<>(props);

        } catch (Throwable e) {
            // 重置初始化状态
            initOne.set(Boolean.FALSE);
            LOG.error("init_error", e);
        }
    }

    public void sendMessage(String topic, MessageEntity messageEntity) {

        try {
            // 参数校验
            Assert.notNull(messageEntity, "messageEntity is null");
            Assert.notNull(messageEntity.getKey(), "messageEntity.key is null");
            Assert.notNull(messageEntity.getValue(), "messageEntity.value is null");

            // 消息发送
            producer.send(new ProducerRecord<>(topic, messageEntity.getKey(), messageEntity.getValue()));

        } catch (Throwable e) {
            throw e;
        }
    }

    @Override
    public void synSendMessage(String topic, MessageEntity messageEntity) {

        Future<RecordMetadata> synResult;

        try {
            // 参数校验
            Assert.notNull(messageEntity, "messageEntity is null");
            Assert.notNull(messageEntity.getKey(), "messageEntity.key is null");
            Assert.notNull(messageEntity.getValue(), "messageEntity.value is null");

            // 消息发送
            synResult = producer.send(new ProducerRecord<>(topic, messageEntity.getKey(), messageEntity.getValue()));

            if (synResult == null || synResult.get() == null) {
                throw new RuntimeException("synSendMessage error");
            }

        } catch (Throwable e) {
            throw new RuntimeException(e.getCause());
        }
    }

    public void sendMessage(String topic, List<MessageEntity> messageEntities) throws Throwable {

        try {
            // 参数校验
            Assert.notNull(messageEntities, "MessageEntity is null");

            if (messageEntities.size() == 0) {
                throw new NullPointerException("messageEntities is null");
            }

            // 发送消息
            messageEntities.forEach(messageEntity -> {
                producer.send(new ProducerRecord<>(topic, messageEntity.getKey(), messageEntity.getValue()));
            });

        } catch (Throwable e) {
            throw e;
        }
    }

    public void closeProducer() {
        try {
            if (producer != null) {
                producer.flush();
                producer.close();
            }
        } catch (Throwable e) {
            LOG.error("closeProducer error", e);
        }
    }

}
