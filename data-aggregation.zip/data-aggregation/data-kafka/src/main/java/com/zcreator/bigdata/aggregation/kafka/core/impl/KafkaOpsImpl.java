package com.zcreator.bigdata.aggregation.kafka.core.impl;

import com.zcreator.bigdata.aggregation.kafka.core.IKafkaOps;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core.impl
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 **/
public class KafkaOpsImpl implements IKafkaOps {

}
