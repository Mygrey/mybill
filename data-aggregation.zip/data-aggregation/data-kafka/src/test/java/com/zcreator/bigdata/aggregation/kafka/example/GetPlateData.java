package com.zcreator.bigdata.aggregation.kafka.example;

import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

/**
 * 
 * GetPlateData过车数据接入，格式化并定时写入HDFS
 * 
 * 已在服务器定时启动
 * 
 * @author 魏熙
 * 
 * */
public class GetPlateData implements Runnable {
	private static String topic = "";

	private static Properties properties = null;
	static {
		topic = "PLATE";//
		properties = new Properties();
		try {
			//加载jar包内的配置文件
			properties.load(GetPlateData.class.getClassLoader().getResourceAsStream("kafkaconsumer.properties"));
		} catch (IOException e) {
			throw new RuntimeException(e + ",加载kafkaconsumer.properties失败");
		}
	}

	public void run() {
		KafkaConsumer<String, String> consumer = new KafkaConsumer<>(properties);
		consumer.subscribe(Arrays.asList(topic));
		String message = "";
		while (true) {
			ConsumerRecords<String, String> records = consumer.poll(100);
			for (ConsumerRecord<String, String> record : records) {
				message = record.value();
				System.out.println("ok");
				System.out.println(message);
			}
		}
	}
}
