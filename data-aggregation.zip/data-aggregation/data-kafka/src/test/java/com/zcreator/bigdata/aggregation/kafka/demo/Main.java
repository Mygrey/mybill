package com.zcreator.bigdata.aggregation.kafka.demo;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main {

	private static Logger logger = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {

        if (args.length < 1) {
            throw  new RuntimeException("pleace input configuration file ...");
        }
        
    	Contants.load(args[0] + "/demo/environment.properties");
    	
    	ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(Contants.consumer_thread_num);
    	
    	for ( int i = 0; i < Contants.consumer_thread_num; i++ ) {
    		try {
    			newFixedThreadPool.submit(new ConsumerPalte(Contants.topic,
    					Contants.topicPartition,
    					Contants.offset,Contants.consumer_pattern));
            } catch (Throwable e) {
                e.printStackTrace();
            }
    	}
    	
    	newFixedThreadPool.shutdown();
    }
}
