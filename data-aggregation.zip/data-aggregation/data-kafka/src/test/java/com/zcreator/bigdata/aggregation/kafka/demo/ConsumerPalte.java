package com.zcreator.bigdata.aggregation.kafka.demo;

import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConsumerPalte extends Thread {
    private static Logger logger = LoggerFactory.getLogger(ConsumerPalte.class);

    private String topic;
    private TopicPartition topicPartition;
    private long offset;
    private int pattern;

    public ConsumerPalte(String topic, Integer partition, long offset, int pattern) {
        super();
        this.topic = topic;
        this.topicPartition = new TopicPartition(topic, partition);
        this.offset = offset;
        this.pattern = pattern;
    }

    @Override
    public void run() {
        KafkaConsumer<String, String> consumer = createConsumer();

        switch (pattern) {
            case 0:
                consumer.subscribe(Arrays.asList(topic));
                break;
            case 1:
                //ָ������topic���Ǹ�����
                consumer.assign(Arrays.asList(topicPartition));
                break;
            case 2:
                //ָ����topic�ķ�����ĳ��offset��ʼ����
                consumer.seek(topicPartition, offset);
                break;
            default:
                throw new RuntimeException("����ģʽ����");
        }

        while (true) {
            int appendNum = 0;
            ConsumerRecords<String, String> records = consumer.poll(100);
            for (ConsumerRecord<String, String> record : records) {
                if (null != record) {
                    try {
                        if (null != record.value()) {
                            //GetResultData.writePlateToHdfs(record.value());
                            appendNum++;
                        }
                    } catch (Exception e) {
                        logger.error("������¼record=[{}]�쳣", record.value(), e);
                    }
                }
            }
            logger.info("��� [{}] ����¼д�뵽hdfs", appendNum);
        }
    }

    private KafkaConsumer<String, String> createConsumer() {
        Properties props = new Properties();
        props.put("bootstrap.servers", Contants.bootstrap_Servers);
        props.put("group.id", Contants.group_id);
        props.put("enable.auto.commit", Contants.enable_auto_commit);
        props.put("auto.commit.interval.ms", Contants.auto_commit_interval_ms);
        props.put("session.timeout.ms", Contants.session_timeout_ms);
        props.put("key.deserializer", Contants.key_deserializer);
        props.put("value.deserializer", Contants.value_deserializer);
        props.put("security.protocol", Contants.security_protocol);
        props.put("ssl.key.password", Contants.ssl_key_password);
        props.put("ssl.keystore.location", Contants.ssl_keystore_location);
        props.put("ssl.keystore.password", Contants.ssl_keystore_password);
        props.put("ssl.truststore.location", Contants.ssl_truststore_location);
        props.put("ssl.truststore.password", Contants.ssl_truststore_password);
        props.put("auto.offset.reset", Contants.auto_offset_reset);
        return new KafkaConsumer<String, String>(props);
    }

}
