package com.zcreator.bigdata.aggregation.kafka;

/**
 * kafka配置
 *
 * @author wangguangzhong@zcreator.com.cn
 */
public final class KafkaConfig {

}
