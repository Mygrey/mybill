package com.zcreator.bigdata.aggregation.kafka.example;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class GetPlateDataManger {

	private static ExecutorService pool = Executors.newFixedThreadPool(4);

	public static AtomicBoolean DATA_ISOVER = new AtomicBoolean(false);
	
	public void runTask() {
		for (int i = 0; i < 1; i++) {
			pool.execute(new GetPlateData());
		}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GetPlateDataManger getplatedata = new GetPlateDataManger();
		getplatedata.runTask();
	}

}
