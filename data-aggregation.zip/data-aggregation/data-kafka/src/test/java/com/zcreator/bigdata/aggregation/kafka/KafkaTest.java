package com.zcreator.bigdata.aggregation.kafka;


import com.alibaba.fastjson.JSON;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.util.Assert;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutionException;

public class KafkaTest {

    private static final String NEW_TOPIC = "topic-wgz-test";
    private static final String brokerUrl = "10.1.80.4:9092,10.1.80.9:9092,10.1.80.10:9092";

    private static AdminClient adminClient;
    private static Properties properties = null;

    @BeforeClass
    public static void beforeClass() {
        properties = new Properties();
        properties.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, brokerUrl);
        adminClient = AdminClient.create(properties);

        properties = new Properties();
        try {
            //加载jar包内的配置文件
            properties.load(KafkaTest.class.getClassLoader().getResourceAsStream("kafkaconsumer.properties"));
        } catch (IOException e) {
            throw new RuntimeException(e + ",加载kafkaconsumer.properties失败");
        }
    }

    @AfterClass
    public static void afterClass() {
        adminClient.close();
    }

    @Test
    public void testCreateTopic() {

        //创建topic
        ArrayList<NewTopic> topics = new ArrayList<NewTopic>();
        NewTopic newTopic = new NewTopic("jianguang_topic_producer", 3, (short) 2);
        topics.add(newTopic);

        try {

            CreateTopicsResult result = adminClient.createTopics(topics);
            Object obj = result.all().get();

            System.out.println(JSON.toJSONString(obj));

        } catch (InterruptedException e) {
            e.printStackTrace();

        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testListTopics() {

        ListTopicsResult listTopicsResult = adminClient.listTopics();
        Assert.notNull(listTopicsResult, "listTopicsResult is null");

        try {

            Map<String, TopicListing> maps = listTopicsResult.namesToListings().get();

            maps.forEach((k, v) -> {
                System.out.println(String.format("%s, %s", k, v));
            });

        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testProducerMessage() {

        Properties props = new Properties();
        props.put("bootstrap.servers", "cdh1:9092,cdh6:9092,cdh7:9092");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

        KafkaProducer<String, String> myProducer = new KafkaProducer<>(props);
        try {
            for (int i = 0; i < 150; i++) {
                Thread.sleep(2000);
                myProducer.send(new ProducerRecord<String, String>(NEW_TOPIC, "key" + Integer.toString(i), "MyMessage: " + Integer.toString(i)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            System.out.println("program close");
            myProducer.close();
        }

        System.out.println("program end");
    }

    @Test
    public void testConsummerMessage() {

        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(properties);
        consumer.subscribe(Arrays.asList(NEW_TOPIC));
        String message = "";

        while (true) {
            ConsumerRecords<String, String> records = consumer.poll(1000);
            for (ConsumerRecord<String, String> record : records) {
                message = record.value();
                System.out.println("ok");
                System.out.println(message);
            }
        }
    }

    @Test
    public void createTopics() {
        NewTopic newTopic = new NewTopic(NEW_TOPIC, 4, (short) 1);
        Collection<NewTopic> newTopicList = new ArrayList<>();
        newTopicList.add(newTopic);
        adminClient.createTopics(newTopicList);
    }
}
