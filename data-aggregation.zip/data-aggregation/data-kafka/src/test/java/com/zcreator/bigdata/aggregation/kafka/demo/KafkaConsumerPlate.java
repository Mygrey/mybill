package com.zcreator.bigdata.aggregation.kafka.demo;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;

public class KafkaConsumerPlate {

    private static Logger logger = LoggerFactory.getLogger(KafkaConsumerPlate.class);

    private static String topic;
    private static Properties properties = null;

    static {
        properties = new Properties();
        try {
            properties.load(KafkaConsumerPlate.class.getResourceAsStream("/kafkaconsumer.properties"));
        } catch (IOException e) {
            throw new RuntimeException(e + ",����kafkaconsumer.propertiesʧ��");
        }
    }

    public KafkaConsumerPlate(String topic) {
        this.topic = topic;
    }

    public void consumeString() {
        long flag = 0;
        KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(properties);
        consumer.subscribe(Arrays.asList(topic));
        while (true) {
            ConsumerRecords<String, String> records = consumer.poll(2000);
            for (ConsumerRecord<String, String> record : records) {
                System.out.printf("offset = %d, key = %s, value = %s\n", record.offset(), record.key(), record.value());
                logger.info("CONSUMER [offset = {}, partition = {}, key = {}, value = {}]", record.offset(), record.partition(), record.key(), record.value());
            }
        }
    }

    public static void main(String[] args) {

        //PLATE:�������ݵ���Ϣ����
        KafkaConsumerPlate concumerKafka1 = new KafkaConsumerPlate("FOR_ILLEGAL");
        try {
            concumerKafka1.consumeString();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
