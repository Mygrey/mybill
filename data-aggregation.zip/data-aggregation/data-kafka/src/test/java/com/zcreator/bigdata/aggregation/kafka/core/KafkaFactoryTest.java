package com.zcreator.bigdata.aggregation.kafka.core;

import com.zcreator.bigdata.aggregation.kafka.core.haddler.AbstractKafkaHandler;
import com.zcreator.bigdata.aggregation.kafka.core.model.conf.ConsumerConfig;
import com.zcreator.bigdata.aggregation.kafka.core.model.conf.KafkaConfig;
import com.zcreator.bigdata.aggregation.kafka.core.model.MessageEntity;
import com.zcreator.bigdata.aggregation.kafka.core.model.conf.ProducerConfig;
import org.assertj.core.util.Lists;
import org.junit.Test;

/**
 * Copyright (C)
 * All rights reserved
 * <p>
 * 项目名称 ： data-aggregation
 * 项目描述：
 * <p>
 * com.zcreator.bigdata.aggregation.kafka.core
 * <p>
 * created by guangzhong.wgz
 * date time 2018/11/14
 * http://www.yisutech.com
 **/
public class KafkaFactoryTest {

    @Test
    public void createKafkaProducer() {

        ProducerConfig config = new ProducerConfig();
        config.setTopic("topic-wgz-test");
        config.setBootstrap_Servers("cdh1:9092,cdh6:9092,cdh7:9092");

        IKafkaProducer producer = KafkaFactory.createKafkaProducer(config);

        for (int i = 0; i < 30; i++) {
            MessageEntity messageEntity = new MessageEntity();
            messageEntity.setKey(i + "test" + i);
            messageEntity.setValue("测试信息" + i);
            producer.sendMessage(config.getTopic(), messageEntity);
        }

        KafkaFactory.destroy();
    }

    @Test
    public void createKafkaConsumer() {

        ConsumerConfig config = new ConsumerConfig();
        config.setGroup_id("topic-wgz-test-consumer");
        config.setBootstrap_Servers("cdh1:9092,cdh6:9092,cdh7:9092");

        IKafkaConsumer iKafkaConsumer = KafkaFactory.createKafkaConsumer(config);

        String topic = "topic-wgz-test";
        iKafkaConsumer.consumerMessage(Lists.newArrayList(topic), new myHandler());
    }

    class myHandler extends AbstractKafkaHandler {

        @Override
        protected void handlerSpecial(String topic, String key, String value) throws Throwable {
            System.out.println(System.currentTimeMillis() + " || " + topic + " || " + key + " || " + value);
        }
    }
}