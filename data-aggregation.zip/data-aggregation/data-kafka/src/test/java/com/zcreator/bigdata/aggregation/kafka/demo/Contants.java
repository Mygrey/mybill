package com.zcreator.bigdata.aggregation.kafka.demo;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Contants {

    public static  String bootstrap_Servers ;
    public static  String group_id ;
    public static String enable_auto_commit;
	public static String auto_commit_interval_ms;
	public static String session_timeout_ms;
	public static String key_deserializer;
    public static  String value_deserializer ;
    public static  String ssl_key_password ;
    public static String ssl_keystore_location;
	public static String ssl_keystore_password;
	public static String ssl_truststore_location;
	public static String ssl_truststore_password;
	public static String security_protocol;
	public static String auto_offset_reset;
	public static String topic;
	public static int consumer_thread_num = 1;
	public static int topicPartition = 0;
	public static int offset = 0 ;

	public static int consumer_pattern = 0;

	public static String fs_defaultFS = "";
	public static String hdfs_target_path = "" ;
	
	
    public static void load(String propertypath){
        Properties props = new Properties();  
        InputStream in;
        try {
            in = new BufferedInputStream(new FileInputStream(propertypath));
            props.load(in);  
            in.close(); 

            bootstrap_Servers = props.getProperty("jgj.bootstrap.servers");
            group_id=props.getProperty("jgj.group.id");
            enable_auto_commit = props.getProperty("jgj.enable.auto.commit");
            auto_commit_interval_ms = props.getProperty("jgj.auto.commit.interval.ms");
            session_timeout_ms = props.getProperty("jgj.session.timeout.ms");
            key_deserializer = props.getProperty("jgj.key.deserializer");
            value_deserializer = props.getProperty("jgj.value.deserializer");
            ssl_key_password=props.getProperty("jgj.ssl.key.password");
            ssl_keystore_location = props.getProperty("jgj.ssl.keystore.location");
            ssl_keystore_password = props.getProperty("jgj.ssl.keystore.password");
            ssl_truststore_location = props.getProperty("jgj.ssl.truststore.location");
            ssl_truststore_password = props.getProperty("jgj.ssl.truststore.password");
            auto_offset_reset = props.getProperty("jgj.auto.offset.reset");
            security_protocol = props.getProperty("jgj.security.protocol");
            topic = props.getProperty("jgj.topic");
            
            int consumer_thread_num_tmp = Integer.parseInt(props.getProperty("jgj.consumer.thread.num"));
            if ( 0 != consumer_thread_num_tmp) {
                consumer_thread_num = consumer_thread_num_tmp;
            }
            
            int topicPartition_tmp = Integer.parseInt(props.getProperty("jgj.topicPartition"));
            if ( 0 != topicPartition_tmp) {
            	topicPartition = topicPartition_tmp;
            }
            
            int offset_tmp = Integer.parseInt(props.getProperty("jgj.offset"));
            if (0 != offset_tmp) {
                offset = offset_tmp;
            }
            
            int consumer_pattern_tmp = Integer.parseInt(props.getProperty("consumer.pattern"));
            if (0 != consumer_pattern_tmp) {
            	consumer_pattern = consumer_pattern_tmp;
            }
            
            fs_defaultFS = props.getProperty("jgj.topic");
            hdfs_target_path = props.getProperty("hdfs.target.path");
            
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();
        }  
    }
}
